from __future__ import annotations

import os, sys, subprocess, time
from pathlib import Path

import lt_core as core


def now_ts() -> str:
    return time.strftime("%Y-%m-%d_%H%M%S")


def open_default(path: Path) -> None:
    try:
        if sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        elif os.name == "nt":
            os.startfile(str(path))  # type: ignore[attr-defined]
        else:
            subprocess.Popen(["xdg-open", str(path)])
    except Exception:
        pass


def open_smb_url() -> None:
    """Optional: open a site-specific SMB URL if configured."""
    if not getattr(core, "SMB_URL", ""):
        return
    try:
        if sys.platform == "darwin":
            subprocess.Popen(["open", core.SMB_URL])
        elif os.name == "nt":
            os.startfile(core.SMB_URL)  # type: ignore[attr-defined]
        else:
            subprocess.Popen(["xdg-open", core.SMB_URL])
    except Exception:
        pass


def guess_share_root() -> str:
    """Best-effort guess of a mounted share root.

    We do NOT hardcode any lab names. We look for a mounted folder that contains
    an 'LTTrainer' subfolder or already *is* 'LTTrainer'.

    This function is not required for Option A (path is entered manually),
    but is kept for developer convenience.
    """
    vol = Path("/Volumes")
    if vol.exists():
        for p in vol.iterdir():
            if not p.is_dir():
                continue
            if p.name.lower() == "lttrainer":
                return str(p.resolve())
            if (p / "LTTrainer").exists():
                return str((p / "LTTrainer").resolve())
    return ""


def is_nifti(p: Path) -> bool:
    n = p.name.lower()
    return n.endswith(".nii") or n.endswith(".nii.gz")


def norm_code(s: str) -> str:
    s = (s or "").strip().upper()
    return "".join([c for c in s if c.isalnum() or c in ("-", "_")])
