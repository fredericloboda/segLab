from __future__ import annotations

from pathlib import Path
from typing import Tuple

import lt_core as core


def build_3d_compare_labelmap(
    t1_path: Path,
    student_mask: Path,
    gold_mask: Path,
    case_id: str = "",
) -> Tuple[bool, str, Path]:
    """Build a multi-label segmentation for 3D compare.

    Labels:
      0 = background
      1 = gold only
      2 = student only
      3 = overlap

    Returned path is in USER_DATA so updates never wipe it.
    """

    try:
        import numpy as np
        import nibabel as nib

        t1_path = Path(t1_path)
        student_mask = Path(student_mask)
        gold_mask = Path(gold_mask)

        if not (t1_path.exists() and student_mask.exists() and gold_mask.exists()):
            return False, "Missing files", Path()

        gi = nib.load(str(gold_mask))
        si = nib.load(str(student_mask))

        g = gi.get_fdata() > 0.5
        s = si.get_fdata() > 0.5
        if g.shape[:3] != s.shape[:3]:
            return False, f"Shape mismatch: gold {g.shape} vs student {s.shape}", Path()

        out = np.zeros(g.shape[:3], dtype=np.uint8)
        out[g & (~s)] = 1
        out[s & (~g)] = 2
        out[g & s] = 3

        core.ensure_dirs()
        out_dir = core.USER_DATA / "compare3d" / (case_id or "case")
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / "compare_labels.nii.gz"
        nib.save(nib.Nifti1Image(out, gi.affine, gi.header), str(out_path))
        return True, "OK", out_path
    except Exception as e:
        return False, f"Could not build 3D compare labelmap: {e}", Path()
