# SegLab Auto-Update (how it works)

## Is it OK to have mac + win in the SAME latest.json?
Yes. The updater reads **one** feed and selects the correct block by platform:
- macOS -> uses the `mac` object
- Windows -> uses the `win` object

So you keep both in the same file.

## Your feed URL (default)
"https://raw.githubusercontent.com/fredericloboda/SegLab-EPFL/main/"
The app uses:
- `SEGLAB_UPDATE_FEED_URL` (if set), otherwise:
- `https://github.com/fredericloboda/SegLab-EPFL` raw GitHub URL in `lt_core.py`

## GitHub raw file vs "blob"
Your feed must be **raw** (text JSON), not a GitHub "blob" HTML page.

Example RAW:
https://raw.githubusercontent.com/fredericloboda/SegLab-EPFL/main/application/resources/update/latest.json

## Fix for the current 404 on mac
The GitHub feed currently pointed to a missing `SegLab-mac.zip`.
Use `SegLab_macOS.app.zip` in `mac.download_url` instead.

## Release workflow (minimal)
1. Build mac zip:
   - `cd dist && ditto -c -k --sequesterRsrc --keepParent SegLab.app SegLab_macOS.app.zip`
2. Upload the zip as a GitHub Release asset (tag vX.Y.Z)
3. Update `latest.json` with:
   - `latest_version`
   - `mac.download_url`, `mac.asset_name`
   - `win.download_url`, `win.asset_name`
