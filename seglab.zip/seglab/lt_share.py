from __future__ import annotations

import json
import uuid
import hashlib
import shutil
from pathlib import Path
from typing import Any, Dict, List, Optional

import lt_core as core
from lt_utils import norm_code
from lt_paths import (
    share_lttrainer_root,
    share_classroom_dir,
    share_class_cases_dir,
    share_class_materials_dir,
    workspace_class_cases_dir,
    workspace_class_materials_dir,
)


# -----------------------------
# Share layout
# -----------------------------

def resolve_share_root(selected_path: Path) -> Path:
    root = share_lttrainer_root(selected_path)
    root.mkdir(parents=True, exist_ok=True)
    ensure_layout(root)
    return root


def ensure_layout(root: Path) -> None:
    (root / "config").mkdir(parents=True, exist_ok=True)
    (root / "classrooms").mkdir(parents=True, exist_ok=True)
    (root / "updates").mkdir(parents=True, exist_ok=True)


# -----------------------------
# Teacher PIN
# -----------------------------

def pin_path(root: Path) -> Path:
    return root / "config" / "teacher_pin.json"


def _pin_hash(pin: str, salt: str) -> str:
    return hashlib.sha256((salt + "|" + pin).encode("utf-8")).hexdigest()


def pin_is_set(root: Path) -> bool:
    return pin_path(root).exists()


def pin_set(root: Path, pin: str) -> None:
    salt = uuid.uuid4().hex
    obj = {"salt": salt, "hash": _pin_hash(pin, salt)}
    pin_path(root).write_text(json.dumps(obj, indent=2), encoding="utf-8")


def pin_verify(root: Path, pin: str) -> bool:
    try:
        obj = json.loads(pin_path(root).read_text(encoding="utf-8"))
        salt = str(obj.get("salt") or "")
        h = str(obj.get("hash") or "")
        return bool(salt and h and _pin_hash(pin, salt) == h)
    except Exception:
        return False


# -----------------------------
# Classroom structure + policy
# -----------------------------

def class_dir(root: Path, code: str) -> Path:
    return share_classroom_dir(root, code)


def class_exists(root: Path, code: str) -> bool:
    return class_dir(root, code).exists()


def ensure_classroom(root: Path, code: str) -> Path:
    code = norm_code(code)
    cd = class_dir(root, code)
    (cd / "cases").mkdir(parents=True, exist_ok=True)
    (cd / "progress" / "attempts").mkdir(parents=True, exist_ok=True)
    (cd / "materials_protected" / "slides").mkdir(parents=True, exist_ok=True)
    (cd / "exports").mkdir(parents=True, exist_ok=True)
    pol = cd / "config.json"
    if not pol.exists():
        pol.write_text(
            json.dumps(
                {"min_voxels": core.DEFAULT_MIN_VOXELS, "tolerance": core.DEFAULT_TOLERANCE, "session": "practice"},
                indent=2,
            ),
            encoding="utf-8",
        )
    return cd


def policy_load(root: Path, code: str) -> Dict[str, Any]:
    try:
        p = class_dir(root, code) / "config.json"
        if p.exists():
            d = json.loads(p.read_text(encoding="utf-8"))
            return d if isinstance(d, dict) else {}
    except Exception:
        pass
    return {}


def policy_save(root: Path, code: str, d: Dict[str, Any]) -> None:
    p = class_dir(root, code) / "config.json"
    p.write_text(json.dumps(d, indent=2), encoding="utf-8")


def list_class_cases(root: Path, code: str) -> List[Path]:
    cd = share_class_cases_dir(root, code)
    if not cd.exists():
        return []
    return sorted([p for p in cd.iterdir() if p.is_dir()], key=lambda x: x.name.lower())


def _write_case_json(case_dir: Path, case_id: str, source: str) -> None:
    meta = {
        "case_id": case_id,
        "source": source,
        "t1_path": str((case_dir / "t1.nii.gz").resolve()),
        "gold_path": str((case_dir / "gold.nii.gz").resolve()),
    }
    (case_dir / "case.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")


def upload_case(root: Path, code: str, case_id: str, t1: Path, gold: Path) -> Path:
    """Teacher-side upload into the share classroom."""
    ensure_classroom(root, code)
    dest = share_class_cases_dir(root, code) / case_id
    dest.mkdir(parents=True, exist_ok=True)
    shutil.copy2(t1, dest / "t1.nii.gz")
    shutil.copy2(gold, dest / "gold.nii.gz")
    _write_case_json(dest, case_id=case_id, source="WORK")
    return dest


def upload_material(root: Path, code: str, rel_subdir: str, file_path: Path) -> Path:
    """Teacher-side upload of PPT/PPTX/PDF into materials_protected/slides/<rel_subdir>."""
    ensure_classroom(root, code)
    rel_subdir = (rel_subdir or "").strip().replace("..", "").strip("/\\")
    target_dir = share_class_materials_dir(root, code) / rel_subdir
    target_dir.mkdir(parents=True, exist_ok=True)
    dest = target_dir / file_path.name
    shutil.copy2(file_path, dest)
    return dest


def attempts_root(root: Path, code: str) -> Path:
    return class_dir(root, code) / "progress" / "attempts"


def submit_mask(root: Path, code: str, username: str, case_id: str, student_mask: Path) -> Path:
    u = (username or "student").strip() or "student"
    cid = case_id
    base = attempts_root(root, code) / u / cid
    base.mkdir(parents=True, exist_ok=True)
    existing = [p for p in base.iterdir() if p.is_dir() and p.name.startswith("attempt_")]
    n = 1
    if existing:
        try:
            n = max(int(p.name.split("_")[-1]) for p in existing if p.name.split("_")[-1].isdigit()) + 1
        except Exception:
            n = len(existing) + 1
    att = base / f"attempt_{n:03d}"
    att.mkdir(parents=True, exist_ok=True)
    shutil.copy2(student_mask, att / "submitted_mask.nii.gz")
    return att


# -----------------------------
# Sync (student-side)
# -----------------------------

def _copytree_overwrite(src: Path, dst: Path) -> None:
    dst.mkdir(parents=True, exist_ok=True)
    for p in src.rglob("*"):
        rel = p.relative_to(src)
        t = dst / rel
        if p.is_dir():
            t.mkdir(parents=True, exist_ok=True)
        else:
            t.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, t)


def sync_classroom_to_workspace(*args, **kwargs) -> Dict[str, Any]:
    """Sync classroom cases from share -> local workspace (core.WORKSPACE).

    Additionally, mirror the same cases into core.LOCAL_CASES.
    This makes Windows deployments robust when different UI/code paths look at
    different local roots ("cases_workspace" vs "cases_local").
    Supports both:
      - sync_classroom_to_workspace(share_root, class_code)
      - sync_classroom_to_workspace(share_root=..., class_code=..., workspace_dir=..., also_apply_policy=True)
    """
    try:
        core.ensure_dirs()
        share_root = kwargs.get("share_root")
        class_code = kwargs.get("class_code")
        workspace_dir = kwargs.get("workspace_dir")
        also_apply_policy = bool(kwargs.get("also_apply_policy", True))

        if share_root is None and len(args) >= 1:
            share_root = args[0]
        if class_code is None and len(args) >= 2:
            class_code = args[1]
        if workspace_dir is None and len(args) >= 3:
            workspace_dir = args[2]

        if share_root is None or class_code is None:
            return {"ok": False, "synced": 0, "skipped": 0, "msg": "Missing share_root/class_code"}

        share_root = Path(share_root).expanduser().resolve()
        class_code = norm_code(str(class_code))
        workspace_dir = Path(workspace_dir).expanduser().resolve() if workspace_dir else core.WORKSPACE

        src_cases = share_class_cases_dir(share_root, class_code)
        if not src_cases.exists():
            return {"ok": False, "synced": 0, "skipped": 0, "msg": f"No cases folder on share: {src_cases}"}

        dst_cases = workspace_class_cases_dir(class_code) if workspace_dir == core.WORKSPACE else (workspace_dir / "classrooms" / class_code / "cases")
        dst_cases.mkdir(parents=True, exist_ok=True)

        # Mirror destination (always): LOCAL_CASES
        dst_local_cases = core.LOCAL_CASES / "classrooms" / class_code / "cases"
        dst_local_cases.mkdir(parents=True, exist_ok=True)

        synced = 0
        skipped = 0
        for case_folder in sorted([p for p in src_cases.iterdir() if p.is_dir()], key=lambda x: x.name.lower()):
            dst = dst_cases / case_folder.name
            if dst.exists():
                skipped += 1
            _copytree_overwrite(case_folder, dst)
            # ensure case.json exists for lt_case.load_case()
            if not (dst / "case.json").exists():
                _write_case_json(dst, case_id=case_folder.name, source="WORK")

            # also mirror into LOCAL_CASES
            dst2 = dst_local_cases / case_folder.name
            _copytree_overwrite(case_folder, dst2)
            if not (dst2 / "case.json").exists():
                _write_case_json(dst2, case_id=case_folder.name, source="LOCAL")
            synced += 1

        if also_apply_policy:
            pol = policy_load(share_root, class_code)
            if isinstance(pol, dict) and pol:
                core.set_locked_policy(pol)

        return {
            "ok": True,
            "synced": synced,
            "skipped": skipped,
            "workspace": str(dst_cases),
            "local": str(dst_local_cases),
            "msg": f"Synced {synced} case(s) to {dst_cases} (and mirrored to {dst_local_cases}).",
        }
    except Exception as e:
        return {"ok": False, "synced": 0, "skipped": 0, "msg": f"Sync failed: {e}"}


def sync_classroom_materials_to_local(*args, **kwargs) -> Dict[str, Any]:
    """Sync classroom PPT/PPTX/PDF materials from share -> local workspace materials."""
    try:
        core.ensure_dirs()
        share_root = kwargs.get("share_root")
        class_code = kwargs.get("class_code")
        if share_root is None and len(args) >= 1:
            share_root = args[0]
        if class_code is None and len(args) >= 2:
            class_code = args[1]
        if share_root is None or class_code is None:
            return {"ok": False, "msg": "Missing share_root/class_code"}

        share_root = Path(share_root).expanduser().resolve()
        class_code = norm_code(str(class_code))

        src = share_class_materials_dir(share_root, class_code)
        if not src.exists():
            return {"ok": True, "msg": "No classroom materials found."}

        dst = workspace_class_materials_dir(class_code)
        _copytree_overwrite(src, dst)
        return {"ok": True, "msg": f"Synced classroom materials to {dst}."}
    except Exception as e:
        return {"ok": False, "msg": f"Materials sync failed: {e}"}
