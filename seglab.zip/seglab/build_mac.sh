#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

rm -rf .venv_build build dist
python3 -m venv .venv_build
source .venv_build/bin/activate

python -m pip install -U pip
python -m pip install PySide6 numpy nibabel pyinstaller certifi packaging
python -m pip uninstall -y PyQt5 PyQt6 || true

ICON="resources/icon.icns"
ARGS=()
if [ -f "$ICON" ]; then
  ARGS+=(--icon "$ICON")
fi

python -m PyInstaller --noconfirm --clean --windowed   --name "SegLab"   --exclude-module PyQt5 --exclude-module PyQt6   --add-data "resources:resources"   "${ARGS[@]}"   startt_trainer.py

APP="dist/SegLab.app"
ZIP="dist/SegLab_macOS.app.zip"

chmod -R u+rwX "$APP" || true
xattr -cr "$APP" || true
codesign --force --deep --sign - "$APP" || true
spctl --assess --verbose=4 "$APP" || true
rm -f "$ZIP"
ditto -c -k --sequesterRsrc --keepParent "$APP" "$ZIP"

echo "Built: $APP"
echo "Zipped: $ZIP"
echo "If macOS blocks the app after download, run: xattr -dr com.apple.quarantine "$APP""
