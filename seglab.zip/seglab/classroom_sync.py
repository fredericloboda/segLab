from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Callable, Dict, Any, List
import json, time

import lt_core as core
import lt_share as share
from lt_paths import workspace_class_cases_dir, workspace_class_materials_dir, share_class_cases_dir, share_class_materials_dir
from lt_utils import norm_code


ProgressCB = Callable[[int, int, str], None]  # done, total, message


@dataclass
class SyncResult:
    ok: bool
    class_code: str
    synced: int = 0
    skipped: int = 0
    msg: str = ""
    errors: List[str] | None = None


def _log(event: Dict[str, Any]) -> None:
    try:
        core.ensure_dirs()
        log_dir = core.USER_DATA / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        p = log_dir / "sync.log.jsonl"
        event = dict(event)
        event["ts"] = time.strftime("%Y-%m-%d %H:%M:%S")
        with p.open("a", encoding="utf-8") as f:
            f.write(json.dumps(event, ensure_ascii=False) + "\n")
    except Exception:
        pass


def sync_all(share_root: Path, class_code: str, *, apply_policy: bool = True) -> SyncResult:
    class_code = norm_code(class_code)
    res_cases = share.sync_classroom_to_workspace(share_root=share_root, class_code=class_code, workspace_dir=core.WORKSPACE, also_apply_policy=apply_policy)
    ok = bool(res_cases.get("ok"))
    synced = int(res_cases.get("synced", 0))
    skipped = int(res_cases.get("skipped", 0))
    msg = str(res_cases.get("msg", ""))

    res_mat = share.sync_classroom_materials_to_local(share_root=share_root, class_code=class_code)
    if res_mat.get("ok"):
        msg = (msg + " " + str(res_mat.get("msg",""))).strip()
    else:
        # materials sync failure shouldn't block cases
        pass

    _log({
        "ok": ok,
        "class_code": class_code,
        "synced": synced,
        "skipped": skipped,
        "msg": msg,
        "share_cases_dir": str(share_class_cases_dir(share_root, class_code)),
        "workspace_cases_dir": str(workspace_class_cases_dir(class_code)),
        "workspace_materials_dir": str(workspace_class_materials_dir(class_code)),
    })
    return SyncResult(ok=ok, class_code=class_code, synced=synced, skipped=skipped, msg=msg)


def list_workspace_cases(class_code: str):
    d = workspace_class_cases_dir(class_code)
    if not d.exists():
        return []
    return sorted([p for p in d.iterdir() if p.is_dir()], key=lambda x: x.name.lower())
