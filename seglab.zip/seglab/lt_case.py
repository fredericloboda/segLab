from __future__ import annotations
import json, os, shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional
import lt_core as core

@dataclass
class CaseRow:
    case_id: str
    source: str
    case_dir: Path
    t1: Path
    gold: Path
    student: Path
    meta: Dict[str, Any]

def set_readonly(p: Path) -> None:
    try:
        if p.exists():
            os.chmod(p, 0o444)
    except Exception:
        pass

def write_case(case_dir: Path, case_id: str, extra: Dict[str, Any]) -> None:
    meta = {"case_id": case_id, **(extra or {})}
    (case_dir / "case.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")

def load_case(case_dir: Path) -> Optional[CaseRow]:
    try:
        mp = case_dir / "case.json"
        if not mp.exists():
            return None
        meta = json.loads(mp.read_text(encoding="utf-8"))
        if not isinstance(meta, dict):
            meta = {}
        cid = str(meta.get("case_id") or case_dir.name)

        # Default in-folder layout (local cases)
        t1 = case_dir / "t1.nii.gz"
        gold = case_dir / "gold.nii.gz"
        student = case_dir / "student.nii.gz"

        # Support pointer-style cases (e.g., built-in resources)
        if not t1.exists():
            tp = meta.get("t1_path")
            if tp:
                t1 = Path(str(tp)).expanduser()
        if not gold.exists():
            gp = meta.get("gold_path")
            if gp:
                gold = Path(str(gp)).expanduser()

        if not t1.exists():
            return None

        # Source label
        src = str(meta.get("source") or "").strip().upper()
        if not src:
            src = "WORK" if str(case_dir).startswith(str(core.WORKSPACE)) else "LOCAL"

        return CaseRow(cid, src, case_dir, t1, gold, student, meta)
    except Exception:
        return None

def list_cases() -> List[CaseRow]:
    out: List[CaseRow] = []

    # 1) Direct cases in WORKSPACE (legacy layout)
    if core.WORKSPACE.exists():
        for d in sorted([p for p in core.WORKSPACE.iterdir() if p.is_dir()], key=lambda x: x.name.lower()):
            c = load_case(d)
            if c:
                out.append(c)

        # 2) Classroom workspace layout: WORKSPACE/classrooms/<code>/cases/<case_id>/...
        cls_root = core.WORKSPACE / "classrooms"
        if cls_root.exists():
            for code_dir in sorted([p for p in cls_root.iterdir() if p.is_dir()], key=lambda x: x.name.lower()):
                cases_dir = code_dir / "cases"
                if not cases_dir.exists():
                    continue
                for case_dir in sorted([p for p in cases_dir.iterdir() if p.is_dir()], key=lambda x: x.name.lower()):
                    c = load_case(case_dir)
                    if c:
                        out.append(c)

    # 3) Local cases
    if core.LOCAL_CASES.exists():
        for d in sorted([p for p in core.LOCAL_CASES.iterdir() if p.is_dir()], key=lambda x: x.name.lower()):
            c = load_case(d)
            if c:
                out.append(c)

    return out
