from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, Iterable

# =========================
# APP IDENTITY
# =========================
APP_NAME = "SegLab"
APP_VERSION = os.environ.get("SEGLAB_APP_VERSION", "1.0.12")

# =========================
# UPDATES (GitHub Releases)
# =========================
_DEFAULT_UPDATE_FEED_URL = (
    "https://raw.githubusercontent.com/fredericloboda/SegLab-EPFL/main/"
    "application/resources/update/latest.json"
)
UPDATE_FEED_URL = os.environ.get("SEGLAB_UPDATE_FEED_URL", _DEFAULT_UPDATE_FEED_URL)

# =========================
# BRAND / THEME
# =========================
ACCENT = "#19E5FF"
ACCENT_SOFT = "#86F1FF"
ACCENT_DARK = "#07181C"
BG0 = "#07080b"
PANEL = "#0f1218"
PANEL2 = "#0b0d12"
BG1 = PANEL
STROKE = "#1d2230"
TEXT = "#e7e9f1"
MUTED = "#9aa3b2"
BTN = "#141a24"
BTN_H = "#1a2130"


def runtime_root() -> Path:
    """Root that works in source mode and PyInstaller onedir/onefile."""
    if getattr(sys, "frozen", False):
        meipass = getattr(sys, "_MEIPASS", None)
        if meipass:
            return Path(meipass)
        try:
            return Path(sys.executable).resolve().parent
        except Exception:
            pass
    return Path(__file__).resolve().parent


def _first_existing(paths: Iterable[Path]) -> Path:
    items = [Path(p) for p in paths]
    for p in items:
        if p.exists():
            return p
    return items[0]


# =========================
# PATHS
# =========================
APP_ROOT = runtime_root()
RESOURCES = APP_ROOT / "resources"
PUBLIC_MATERIALS_DIR = RESOURCES / "materials_public"

# Built-in offline content. New canonical folders are bundled_* but legacy folders remain supported.
BUILTIN_CASES_DIR = _first_existing([
    RESOURCES / "bundled_cases",
    RESOURCES / "cases_builtin",
])
BUILTIN_CASES_LEGACY = RESOURCES / "cases_builtin"
BUILTIN_MANIFEST = _first_existing([
    BUILTIN_CASES_DIR / "manifest.json",
    BUILTIN_CASES_LEGACY / "manifest.json",
])
BUILTIN_MATERIALS_DIR = _first_existing([
    RESOURCES / "bundled_materials",
    RESOURCES / "materials_public",
])
BUILTIN_MATERIALS_LEGACY = RESOURCES / "materials_public"

ANATOMY_DIR = _first_existing([RESOURCES / "bundled_materials" / "anatomy", RESOURCES / "anatomy"])
INTRO_DIR = _first_existing([RESOURCES / "bundled_materials" / "intro", RESOURCES / "intro"])

USER_DATA = Path.home() / "SegLabEPFL_UserData"
CFG_PATH = USER_DATA / "config.json"

LOCAL_CASES = USER_DATA / "cases_local"
WORKSPACE = USER_DATA / "cases_workspace"
LOCAL_MATERIALS = USER_DATA / "materials_local"
LOCAL_PROGRESS = USER_DATA / "progress_local" / "attempts"
UPDATES_DIR = USER_DATA / "updates"

# Stable writable structure for student masks / exports
STUDENT_WORK = USER_DATA / "student_work"
BUNDLED_WORK = STUDENT_WORK / "bundled"
CLASSROOM_WORK = STUDENT_WORK / "classrooms"
EXPORTS_DIR = USER_DATA / "exports"

# =========================
# DEFAULTS
# =========================
DEFAULT_MIN_VOXELS = 10
DEFAULT_TOLERANCE = 150
SMB_URL = ""


def ensure_dirs() -> None:
    for p in (
        USER_DATA,
        LOCAL_CASES,
        WORKSPACE,
        LOCAL_MATERIALS,
        LOCAL_PROGRESS,
        UPDATES_DIR,
        STUDENT_WORK,
        BUNDLED_WORK,
        CLASSROOM_WORK,
        EXPORTS_DIR,
    ):
        p.mkdir(parents=True, exist_ok=True)

    try:
        (RESOURCES / "bundled_cases").mkdir(parents=True, exist_ok=True)
        (RESOURCES / "bundled_materials").mkdir(parents=True, exist_ok=True)
        BUILTIN_CASES_LEGACY.mkdir(parents=True, exist_ok=True)
        BUILTIN_MATERIALS_LEGACY.mkdir(parents=True, exist_ok=True)
        ANATOMY_DIR.mkdir(parents=True, exist_ok=True)
        INTRO_DIR.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

    # placeholder folders created automatically if missing
    _ensure_manifest()


def _ensure_text(path: Path, text: str) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        if not path.exists():
            path.write_text(text, encoding="utf-8")
    except Exception:
        pass


def _ensure_manifest() -> None:
    manifest = RESOURCES / "bundled_cases" / "manifest.json"
    if manifest.exists():
        return
    sample = {"cases": []}
    try:
        manifest.write_text(json.dumps(sample, indent=2), encoding="utf-8")
    except Exception:
        pass


# =========================
# CONFIG
# =========================

def cfg_load() -> Dict[str, Any]:
    try:
        if CFG_PATH.exists():
            d = json.loads(CFG_PATH.read_text(encoding="utf-8"))
            return d if isinstance(d, dict) else {}
    except Exception:
        pass
    return {}


def cfg_save(d: Dict[str, Any]) -> None:
    try:
        CFG_PATH.parent.mkdir(parents=True, exist_ok=True)
        CFG_PATH.write_text(json.dumps(d, indent=2), encoding="utf-8")
    except Exception:
        pass


def cfg_get(k: str, default=None):
    return cfg_load().get(k, default)


def cfg_set(k: str, v) -> None:
    d = cfg_load()
    d[k] = v
    cfg_save(d)


# =========================
# LOCKED POLICY (classroom)
# =========================
_LOCKED_POLICY: dict | None = None


def set_locked_policy(policy: dict | None) -> None:
    global _LOCKED_POLICY
    _LOCKED_POLICY = policy if isinstance(policy, dict) else None
    try:
        cfg_set("locked_policy", _LOCKED_POLICY)
    except Exception:
        pass


def get_locked_policy() -> dict | None:
    global _LOCKED_POLICY
    if isinstance(_LOCKED_POLICY, dict):
        return _LOCKED_POLICY
    try:
        p = cfg_get("locked_policy", None)
        if isinstance(p, dict):
            _LOCKED_POLICY = p
            return p
    except Exception:
        pass
    return None
