from __future__ import annotations

from pathlib import Path
from typing import Optional, Tuple, Dict
import numpy as np
import nibabel as nib


class ErrorAccumulator:
    def __init__(self, ref_img_path: Path):
        self.ref_img = nib.load(str(ref_img_path))
        shape = self.ref_img.shape[:3]
        self.fn = np.zeros(shape, dtype=np.float32)
        self.fp = np.zeros(shape, dtype=np.float32)
        self.n = 0

    def add(self, gold_path: Path, student_path: Path):
        gi = nib.load(str(gold_path))
        si = nib.load(str(student_path))
        g = (gi.get_fdata() > 0.5)
        s = (si.get_fdata() > 0.5)
        fn = (g & (~s)).astype(np.float32)
        fp = ((~g) & s).astype(np.float32)
        self.fn += fn
        self.fp += fp
        self.n += 1

    def save(self, out_dir: Path):
        out_dir.mkdir(parents=True, exist_ok=True)
        affine = self.ref_img.affine
        hdr = self.ref_img.header
        nib.Nifti1Image(self.fn, affine, hdr).to_filename(str(out_dir / "fn_count.nii.gz"))
        nib.Nifti1Image(self.fp, affine, hdr).to_filename(str(out_dir / "fp_count.nii.gz"))
        if self.n > 0:
            nib.Nifti1Image(self.fn / float(self.n), affine, hdr).to_filename(str(out_dir / "fn_rate.nii.gz"))
            nib.Nifti1Image(self.fp / float(self.n), affine, hdr).to_filename(str(out_dir / "fp_rate.nii.gz"))
