from __future__ import annotations

import os
import sys
import subprocess
import shutil
from pathlib import Path
from typing import Optional, Tuple

import lt_core as core


def _candidate_if_exists(p: Path) -> Optional[Path]:
    try:
        if p.exists():
            return p
    except Exception:
        pass
    return None


def itksnap_exec() -> Optional[Path]:
    """Best-effort ITK-SNAP discovery.

    Order:
    1) explicit user-configured path (cfg: itksnap_path)
    2) common platform-specific install locations
    3) PATH lookup
    """
    user = core.cfg_get("itksnap_path", "")
    if user:
        p = Path(str(user)).expanduser()
        if p.exists():
            return p

    if sys.platform == "darwin":
        for p in [
            Path("/Applications/ITK-SNAP.app/Contents/MacOS/ITK-SNAP"),
            Path("/Applications/ITK-SNAP.app/Contents/MacOS/itksnap"),
        ]:
            hit = _candidate_if_exists(p)
            if hit:
                return hit

    elif sys.platform.startswith("win"):
        program_roots = [
            os.environ.get("ProgramFiles", r"C:\Program Files"),
            os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
            os.environ.get("LOCALAPPDATA", r"C:\Users\%USERNAME%\AppData\Local"),
        ]
        for base in program_roots:
            if not base:
                continue
            base_path = Path(base)
            direct_candidates = [
                base_path / "ITK-SNAP" / "bin" / "itk-snap.exe",
                base_path / "ITK-SNAP" / "bin" / "ITK-SNAP.exe",
                base_path / "ITK-SNAP" / "itk-snap.exe",
                base_path / "ITK-SNAP" / "ITK-SNAP.exe",
                base_path / "itk-snap" / "bin" / "itk-snap.exe",
            ]
            for p in direct_candidates:
                hit = _candidate_if_exists(p)
                if hit:
                    return hit
            try:
                for folder in sorted(base_path.glob("ITK-SNAP*")):
                    for name in ["bin/ITK-SNAP.exe", "bin/itk-snap.exe", "ITK-SNAP.exe", "itk-snap.exe"]:
                        hit = _candidate_if_exists(folder / name)
                        if hit:
                            return hit
            except Exception:
                pass

    else:
        for p in [
            Path("/usr/bin/itksnap"),
            Path("/usr/local/bin/itksnap"),
            Path("/snap/bin/itk-snap"),
        ]:
            hit = _candidate_if_exists(p)
            if hit:
                return hit

    which = shutil.which("itk-snap") or shutil.which("itksnap") or shutil.which("ITK-SNAP")
    if which:
        return Path(which)
    return None


def launch(t1: Path, seg: Path) -> Tuple[bool, str]:
    exe = itksnap_exec()
    if exe is None:
        return False, (
            "ITK-SNAP was not found on this computer. "
            "Please install ITK-SNAP or set its executable path in the app config (itksnap_path)."
        )

    try:
        subprocess.Popen([str(exe), "-g", str(t1), "-s", str(seg)])
        return True, "Opened in ITK-SNAP"
    except Exception as e:
        return False, f"Could not start ITK-SNAP: {e}"
