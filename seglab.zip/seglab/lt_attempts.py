from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional


def _safe_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return float(default)


def _safe_int(x: Any, default: int = 0) -> int:
    try:
        return int(float(x))
    except Exception:
        return int(default)


def load_attempts_jsonl(out_dir: Path) -> List[Dict[str, Any]]:
    p = Path(out_dir) / "attempts.jsonl"
    out: List[Dict[str, Any]] = []
    if not p.exists():
        return out
    try:
        for line in p.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                if isinstance(obj, dict):
                    out.append(obj)
            except Exception:
                continue
    except Exception:
        return []
    return out


def load_attempts_csv(out_dir: Path) -> List[Dict[str, Any]]:
    p = Path(out_dir) / "attempts.csv"
    if not p.exists():
        return []
    out: List[Dict[str, Any]] = []
    try:
        with p.open("r", encoding="utf-8", newline="") as f:
            r = csv.DictReader(f)
            for row in r:
                if isinstance(row, dict):
                    out.append(dict(row))
    except Exception:
        return []
    return out


def load_attempts(out_dir: Path) -> List[Dict[str, Any]]:
    rows = load_attempts_jsonl(out_dir)
    if not rows:
        rows = load_attempts_csv(out_dir)
    rows.sort(key=lambda a: str(a.get("timestamp") or ""))
    return rows


def _attempt_key(row: Dict[str, Any]) -> str:
    uid = str(row.get("case_uid") or "").strip()
    if uid:
        return uid
    return str(row.get("case_id") or "").strip()


def attempts_for_case(rows: Iterable[Dict[str, Any]], case_key: str) -> List[Dict[str, Any]]:
    key = str(case_key or "")
    out = [dict(r) for r in rows if _attempt_key(r) == key or str(r.get("case_id") or "") == key]
    out.sort(key=lambda a: str(a.get("timestamp") or ""))
    return out


def next_attempt_no(rows: Iterable[Dict[str, Any]], case_key: str) -> int:
    items = attempts_for_case(rows, case_key)
    seen = [_safe_int(r.get("attempt_no"), 0) for r in items]
    seen = [n for n in seen if n > 0]
    return (max(seen) + 1) if seen else (len(items) + 1)


def case_summary(rows: Iterable[Dict[str, Any]], case_key: str) -> Dict[str, Any]:
    items = attempts_for_case(rows, case_key)
    if not items:
        return {
            "case_id": case_key,
            "case_uid": case_key,
            "attempts": 0,
            "first_dice": None,
            "latest_dice": None,
            "best_dice": None,
            "delta_dice": None,
            "latest_iou": None,
            "best_iou": None,
            "latest_precision": None,
            "latest_recall": None,
            "latest_vol_abs_err_ml": None,
            "latest_centroid_dist_mm": None,
            "last_timestamp": "",
        }

    first = items[0]
    latest = items[-1]
    first_d = _safe_float(first.get("dice"), 0.0)
    latest_d = _safe_float(latest.get("dice"), 0.0)
    dices = [_safe_float(r.get("dice"), 0.0) for r in items]
    ious = [_safe_float(r.get("jaccard"), 0.0) for r in items]
    best_d = max(dices) if dices else None
    best_i = max(ious) if ious else None
    return {
        "case_id": str(latest.get("case_id") or case_key),
        "case_uid": _attempt_key(latest),
        "attempts": len(items),
        "first_dice": first_d,
        "latest_dice": latest_d,
        "best_dice": best_d,
        "delta_dice": latest_d - first_d,
        "latest_iou": _safe_float(latest.get("jaccard"), 0.0),
        "best_iou": best_i,
        "latest_precision": _safe_float(latest.get("precision"), 0.0),
        "latest_recall": _safe_float(latest.get("recall"), 0.0),
        "latest_vol_abs_err_ml": _safe_float(latest.get("vol_abs_err_ml"), 0.0),
        "latest_centroid_dist_mm": _safe_float(latest.get("centroid_dist_mm"), 0.0),
        "last_timestamp": str(latest.get("timestamp") or ""),
    }


def summaries_by_case(rows: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    seen: Dict[str, bool] = {}
    out: List[Dict[str, Any]] = []
    for r in rows:
        cid = _attempt_key(r)
        if not cid or cid in seen:
            continue
        seen[cid] = True
        out.append(case_summary(rows, cid))
    out.sort(key=lambda x: str(x.get("case_id") or "").lower())
    return out


def overall_summary(rows: Iterable[Dict[str, Any]], available_case_ids: Optional[Iterable[str]] = None) -> Dict[str, Any]:
    rows_list = list(rows)
    sums = summaries_by_case(rows_list)
    attempted = len(sums)
    total_attempts = len(rows_list)
    latest_vals = [s["latest_dice"] for s in sums if s.get("latest_dice") is not None]
    best_vals = [s["best_dice"] for s in sums if s.get("best_dice") is not None]
    deltas = [s["delta_dice"] for s in sums if s.get("delta_dice") is not None]
    available = len(list(available_case_ids)) if available_case_ids is not None else attempted
    completion = (attempted / available) if available > 0 else 0.0
    biggest = max(sums, key=lambda s: float(s.get("delta_dice") or -1e9), default=None)
    weakest = min(sums, key=lambda s: float(s.get("latest_dice") or 1e9), default=None)
    return {
        "attempted_cases": attempted,
        "available_cases": available,
        "total_attempts": total_attempts,
        "mean_latest_dice": (sum(latest_vals) / len(latest_vals)) if latest_vals else None,
        "mean_best_dice": (sum(best_vals) / len(best_vals)) if best_vals else None,
        "mean_delta_dice": (sum(deltas) / len(deltas)) if deltas else None,
        "completion_rate": completion,
        "biggest_improvement_case": (biggest or {}).get("case_id", ""),
        "biggest_improvement_uid": (biggest or {}).get("case_uid", ""),
        "weakest_case": (weakest or {}).get("case_id", ""),
        "weakest_uid": (weakest or {}).get("case_uid", ""),
    }


def export_rows_csv(path: Path, rows: List[Dict[str, Any]]) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames: List[str] = []
    seen = set()
    for row in rows:
        for k in row.keys():
            if k not in seen:
                seen.add(k)
                fieldnames.append(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for row in rows:
            w.writerow({k: row.get(k, "") for k in fieldnames})
    return path
