from __future__ import annotations

import json
import shutil
import tempfile
import zipfile
from pathlib import Path
from typing import Iterable, Tuple

import lt_core as core

PACK_EXT = ".seglabpack"
MANIFEST_NAME = "manifest.json"


def _safe_name(s: str) -> str:
    out = ''.join(ch if ch.isalnum() or ch in ('-','_') else '_' for ch in (s or '').strip())
    return out.strip('_') or 'pack'


def _case_subdirs(cases_root: Path):
    return [p for p in sorted(cases_root.iterdir(), key=lambda x: x.name.lower()) if p.is_dir()]


def _is_case_dir(d: Path) -> bool:
    return (d/'t1.nii.gz').exists() and (d/'gold.nii.gz').exists()


def create_pack_from_roots(output_path: Path, cases_root: Path, materials_root: Path | None = None, title: str = '') -> Tuple[int, int, Path]:
    cases_root = Path(cases_root)
    materials_root = Path(materials_root) if materials_root else None
    if not cases_root.exists():
        raise FileNotFoundError(f'Cases folder not found: {cases_root}')
    case_dirs = [d for d in _case_subdirs(cases_root) if _is_case_dir(d)]
    if not case_dirs:
        raise RuntimeError('No valid case folders found. Each case needs t1.nii.gz and gold.nii.gz.')
    title = title.strip() or output_path.stem
    output_path = Path(output_path)
    if output_path.suffix.lower() != PACK_EXT:
        output_path = output_path.with_suffix(PACK_EXT)
    with tempfile.TemporaryDirectory() as td:
        stage = Path(td)
        pack_root = stage / 'pack'
        (pack_root/'cases').mkdir(parents=True, exist_ok=True)
        (pack_root/'materials').mkdir(parents=True, exist_ok=True)
        imported_cases = 0
        for d in case_dirs:
            target = pack_root/'cases'/d.name
            shutil.copytree(d, target, dirs_exist_ok=True)
            cj = target/'case.json'
            meta = {'case_id': d.name, 'label': d.name}
            if cj.exists():
                try:
                    meta.update(json.loads(cj.read_text(encoding='utf-8')) or {})
                except Exception:
                    pass
            meta['case_id'] = str(meta.get('case_id') or d.name)
            meta['label'] = str(meta.get('label') or meta['case_id'])
            cj.write_text(json.dumps(meta, indent=2), encoding='utf-8')
            imported_cases += 1
        mat_count = 0
        if materials_root and materials_root.exists():
            for p in materials_root.rglob('*'):
                if p.is_file():
                    rel = p.relative_to(materials_root)
                    dest = pack_root/'materials'/rel
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(p, dest)
                    mat_count += 1
        manifest = {
            'format': 1,
            'type': 'seglab_content_pack',
            'title': title,
            'pack_id': _safe_name(title),
            'case_count': imported_cases,
            'material_count': mat_count,
        }
        (pack_root/MANIFEST_NAME).write_text(json.dumps(manifest, indent=2), encoding='utf-8')
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(output_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
            for p in pack_root.rglob('*'):
                zf.write(p, p.relative_to(pack_root))
    return imported_cases, mat_count, output_path


def install_pack(pack_path: Path) -> Tuple[str, int, int]:
    core.ensure_dirs()
    pack_path = Path(pack_path)
    if not pack_path.exists():
        raise FileNotFoundError(str(pack_path))
    with tempfile.TemporaryDirectory() as td:
        stage = Path(td)
        with zipfile.ZipFile(pack_path, 'r') as zf:
            zf.extractall(stage)
        man_p = stage / MANIFEST_NAME
        manifest = {}
        if man_p.exists():
            try:
                manifest = json.loads(man_p.read_text(encoding='utf-8')) or {}
            except Exception:
                manifest = {}
        pack_id = _safe_name(str(manifest.get('pack_id') or manifest.get('title') or pack_path.stem))
        cases_root = stage/'cases'
        mats_root = stage/'materials'
        case_count = 0
        if cases_root.exists():
            for case_dir in sorted([p for p in cases_root.iterdir() if p.is_dir()], key=lambda x: x.name.lower()):
                if not _is_case_dir(case_dir):
                    continue
                src_meta = case_dir/'case.json'
                meta = {'case_id': case_dir.name, 'label': case_dir.name}
                if src_meta.exists():
                    try:
                        meta.update(json.loads(src_meta.read_text(encoding='utf-8')) or {})
                    except Exception:
                        pass
                orig_id = str(meta.get('case_id') or case_dir.name)
                new_id = f'{pack_id}__{orig_id}'
                dest = core.LOCAL_CASES/new_id
                if dest.exists():
                    shutil.rmtree(dest, ignore_errors=True)
                shutil.copytree(case_dir, dest)
                meta['case_id'] = new_id
                label = str(meta.get('label') or orig_id)
                meta['label'] = f'{label} [{pack_id}]'
                meta['source'] = 'LOCAL'
                (dest/'case.json').write_text(json.dumps(meta, indent=2), encoding='utf-8')
                case_count += 1
        mat_count = 0
        if mats_root.exists():
            dest_root = core.LOCAL_MATERIALS/pack_id
            if dest_root.exists():
                shutil.rmtree(dest_root, ignore_errors=True)
            for p in mats_root.rglob('*'):
                if p.is_file():
                    rel = p.relative_to(mats_root)
                    dest = dest_root/rel
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(p, dest)
                    mat_count += 1
    return pack_id, case_count, mat_count
