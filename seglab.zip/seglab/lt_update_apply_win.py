#!/usr/bin/env python3
"""
lt_update_apply_win.py
Windows update apply helper.

This runs as a separate process so it can replace the app files after the main
SegLab process quits (Windows cannot overwrite a running .exe).
"""

from __future__ import annotations

import os
import sys
import time
import zipfile
import shutil
from pathlib import Path


def _is_frozen() -> bool:
    return bool(getattr(sys, "frozen", False))


def _app_install_dir() -> Path:
    """
    If frozen: sys.executable is the installed SegLab.exe.
    If not frozen: treat the current project folder as the install dir.
    """
    if _is_frozen():
        return Path(sys.executable).resolve().parent
    # source run fallback: repo root is parent of this file
    return Path(__file__).resolve().parent


def _extract_zip(staged_zip: Path, out_dir: Path) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(staged_zip, "r") as z:
        z.extractall(out_dir)

    # Prefer a folder that contains SegLab.exe (one-folder distribution)
    candidates = []
    for p in out_dir.rglob("SegLab.exe"):
        candidates.append(p.parent)

    if candidates:
        # choose the closest (shortest path)
        candidates.sort(key=lambda p: len(str(p)))
        return candidates[0]

    # Fallback: single top-level directory
    tops = [p for p in out_dir.iterdir() if p.is_dir()]
    if len(tops) == 1:
        return tops[0]

    return out_dir


def _copy_overwrite(src_dir: Path, dst_dir: Path) -> None:
    dst_dir.mkdir(parents=True, exist_ok=True)

    # Copy file-by-file to avoid issues with existing folder
    for root, dirs, files in os.walk(src_dir):
        rel = Path(root).relative_to(src_dir)
        target_root = dst_dir / rel
        target_root.mkdir(parents=True, exist_ok=True)

        for d in dirs:
            (target_root / d).mkdir(parents=True, exist_ok=True)

        for f in files:
            s = Path(root) / f
            t = target_root / f
            try:
                if t.exists():
                    try:
                        t.unlink()
                    except Exception:
                        pass
                shutil.copy2(s, t)
            except PermissionError:
                raise
            except Exception:
                # keep going on non-critical failures
                pass


def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: lt_update_apply_win.py <staged_zip>")
        return 2

    staged_zip = Path(sys.argv[1]).expanduser().resolve()
    if not staged_zip.exists():
        print(f"Update zip not found: {staged_zip}")
        return 2

    install_dir = _app_install_dir()

    # staging extraction directory
    staging_root = Path(os.environ.get("TEMP", str(Path.home() / "AppData" / "Local" / "Temp"))) / "seglab_update_staging"
    if staging_root.exists():
        try:
            shutil.rmtree(staging_root)
        except Exception:
            pass
    staging_root.mkdir(parents=True, exist_ok=True)

    extracted_dir = _extract_zip(staged_zip, staging_root)

    # Give the main app time to quit so files unlock
    time.sleep(2.0)

    # Try overwrite with retries (Windows AV/file locks)
    last_err = None
    for _ in range(25):
        try:
            _copy_overwrite(extracted_dir, install_dir)
            last_err = None
            break
        except PermissionError as e:
            last_err = e
            time.sleep(0.4)

    if last_err is not None:
        print(f"Failed to apply update: {last_err}")
        return 1

    # Relaunch
    exe = install_dir / "SegLab.exe"
    if exe.exists():
        try:
            os.startfile(str(exe))  # type: ignore[attr-defined]
        except Exception:
            pass

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
