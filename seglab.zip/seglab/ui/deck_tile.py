from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont
from PySide6.QtWidgets import QVBoxLayout, QHBoxLayout, QLabel

from ui.widgets import Card


class DeckTile(Card):
    """Numbered icon-like tile for presentations (PDF/PPTX).

    Matches the app's tile/card language, but is more "launcher" than list.
    """

    clicked = Signal(Path)

    def __init__(self, idx: int, title: str, path: Path, kind: str = ""):
        super().__init__()
        self.setObjectName("Tile")
        self.setCursor(Qt.PointingHandCursor)
        self._path = Path(path)

        v = QVBoxLayout(self)
        v.setContentsMargins(16, 14, 16, 14)
        v.setSpacing(8)

        top = QHBoxLayout()
        top.setSpacing(10)
        v.addLayout(top)

        n = QLabel(f"{idx:02d}")
        n.setObjectName("NeonNumber")
        f = QFont(n.font())
        f.setPointSize(30)
        f.setWeight(QFont.Black)
        n.setFont(f)
        n.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        # No drop-shadow neon here — it looks like cyan frames.
        top.addWidget(n, 0)

        meta = QVBoxLayout(); meta.setSpacing(2)
        top.addLayout(meta, 1)

        t = QLabel(title)
        t.setObjectName("DeckTitle")
        t.setWordWrap(True)
        meta.addWidget(t)

        if kind:
            k = QLabel(kind.upper())
            k.setObjectName("DeckKind")
            meta.addWidget(k)

        self.setToolTip(str(self._path))

    def mousePressEvent(self, ev):
        if ev.button() == Qt.LeftButton:
            self.clicked.emit(self._path)
        return super().mousePressEvent(ev)
