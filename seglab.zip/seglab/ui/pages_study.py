from __future__ import annotations

import time
from pathlib import Path
from typing import Optional, Dict, Any, List

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QMessageBox, QLineEdit, QLabel, QComboBox

import lt_core as core
import lt_case as cases
import lt_eval as ev
from lt_difficulty import compute_difficulty, to_metadata
from lt_error_maps import ErrorAccumulator
from lt_session import StudyConfig, StudyState
from classroom_sync import sync_all as sync_all_classroom

from ui.widgets import h1, caption, btn


class StudyPage(QWidget):
    """Phase-1 Study runner: Train/Test with locked order + logging + metrics."""

    def __init__(self, app):
        super().__init__()
        self.app = app
        self._state: Optional[StudyState] = None
        self._erracc: Optional[ErrorAccumulator] = None

        v = QVBoxLayout(self); v.setContentsMargins(18, 18, 18, 18); v.setSpacing(10)

        v.addWidget(h1("Study (Train/Test)"))
        v.addWidget(caption("Locked evaluation runner + exports. Train mode may show feedback; Test mode is blind."))

        row = QHBoxLayout(); row.setSpacing(10)
        self.e_cohort = QLineEdit(); self.e_cohort.setPlaceholderText("cohort_id (e.g. HummelPilot_2026)")
        self.e_session = QLineEdit(); self.e_session.setPlaceholderText("session_id (auto if empty)")
        self.cb_group = QComboBox(); self.cb_group.addItems(["A","B"])
        self.cb_mode = QComboBox(); self.cb_mode.addItems(["test","train"])
        row.addWidget(QLabel("Cohort:")); row.addWidget(self.e_cohort, 2)
        row.addWidget(QLabel("Session:")); row.addWidget(self.e_session, 2)
        row.addWidget(QLabel("Group:")); row.addWidget(self.cb_group)
        row.addWidget(QLabel("Mode:")); row.addWidget(self.cb_mode)
        v.addLayout(row)

        row2 = QHBoxLayout(); row2.setSpacing(10)
        self.b_start = btn("Start", "primary")
        self.b_open = btn("Open current case", "ghost")
        self.b_submit = btn("Submit / Log", "primary")
        self.b_next = btn("Next case", "ghost")
        self.b_export = btn("Open results folder", "ghost")
        row2.addWidget(self.b_start)
        row2.addWidget(self.b_open)
        row2.addWidget(self.b_submit)
        row2.addWidget(self.b_next)
        row2.addWidget(self.b_export)
        row2.addStretch(1)
        v.addLayout(row2)

        self.l_status = QLabel(""); self.l_status.setObjectName("Muted")
        v.addWidget(self.l_status)

        self.b_start.clicked.connect(self._start)
        self.b_open.clicked.connect(self._open)
        self.b_submit.clicked.connect(self._submit)
        self.b_next.clicked.connect(self._next)
        self.b_export.clicked.connect(self._open_results_dir)

        self.refresh()

    def refresh(self):
        has = self._state is not None and not self._state.is_done()
        self.b_open.setEnabled(has)
        self.b_submit.setEnabled(has)
        self.b_next.setEnabled(has)
        if not has:
            self.l_status.setText("Ready. Start a study run.")
        else:
            cid = self._state.current_case_id()
            self.l_status.setText(f"Case {self._state.idx+1}/{len(self._state.ordered_case_ids)}: {cid}")

    def _pick_cases(self) -> List[cases.CaseRow]:
        rows = cases.list_cases()
        # If student + class_code => prefer classroom workspace cases only
        if self.app.mode == "student" and self.app.class_code:
            cc = self.app.class_code.lower()
            rows = [r for r in rows if (r.source or "").lower() == "work" or ("classrooms" in str(r.case_dir).lower())]
        return rows

    def _start(self):
        # auto-sync for students
        if self.app.mode == "student" and self.app.share_root and self.app.class_code:
            try:
                sync_all_classroom(Path(self.app.share_root), self.app.class_code)
            except Exception:
                pass

        rows = self._pick_cases()
        if not rows:
            QMessageBox.information(self, core.APP_NAME, "No cases found. Sync classroom or add local cases.")
            return

        cohort = (self.e_cohort.text() or "").strip()
        if not cohort:
            QMessageBox.information(self, core.APP_NAME, "Please enter a cohort_id.")
            return
        sess = (self.e_session.text() or "").strip() or time.strftime("%Y%m%d_%H%M%S")
        group = self.cb_group.currentText().strip()
        mode = self.cb_mode.currentText().strip()

        # locked order: alphabetical by case_id for reproducibility
        order = [r.case_id for r in sorted(rows, key=lambda x: x.case_id.lower())]

        cfg = StudyConfig(
            cohort_id=cohort,
            session_id=sess,
            group=group,
            mode=mode,
            class_code=self.app.class_code if self.app.mode == "student" else "",
            casepack_version="StrokeLesion_v1",
            user_id=self.app.username,
            app_version=core.APP_VERSION,
        )
        self._state = StudyState(cfg=cfg, ordered_case_ids=order, idx=0, case_start_ts=None)
        # error accumulator uses first case t1 as reference space (assumes same space within pack)
        first = next((r for r in rows if r.case_id == order[0]), None)
        self._erracc = ErrorAccumulator(first.t1) if first and first.t1 else None

        self._state.start_case()
        self.app.toast(f"Study started: {cohort} / {sess} ({mode}, group {group})")
        self.refresh()

    def _current_vm(self):
        if not self._state:
            return None
        cid = self._state.current_case_id()
        if not cid:
            return None
        # use PracticePage helper logic? easiest: load case row again
        rows = cases.list_cases()
        for r in rows:
            if r.case_id == cid:
                return r
        return None

    def _open(self):
        if not self._state:
            return
        r = self._current_vm()
        if not r or not r.t1:
            QMessageBox.information(self, core.APP_NAME, "Case not ready.")
            return
        # Ensure student mask exists
        r.case_dir.mkdir(parents=True, exist_ok=True)
        if not r.student.exists():
            ok, msg = ev.make_blank_student_mask(r.t1, r.student)
            if not ok:
                QMessageBox.critical(self, core.APP_NAME, msg)
                return

        # start timer if not started
        if self._state.case_start_ts is None:
            self._state.start_case()

        # open editor (reuse app default)
        import lt_editor as editor_external
        ok, msg = editor_external.open_case(r.t1, r.student)
        if not ok:
            QMessageBox.critical(self, core.APP_NAME, msg)
        else:
            self.app.toast("Opened in ITK‑SNAP")

    def _submit(self):
        if not self._state:
            return
        r = self._current_vm()
        if not r or not (r.t1 and r.student.exists()):
            QMessageBox.information(self, core.APP_NAME, "No student mask found. Open the case and save a mask first.")
            return

        dur = self._state.finish_case()

        metrics: Dict[str, Any] = {}
        ok = False
        msg = ""
        if r.gold and r.gold.exists():
            ok, msg, metrics = ev.evaluate_masks(r.gold, r.student)
        else:
            ok, msg, metrics = False, "Gold mask missing.", {}

        # difficulty (computed from gold)
        diff_meta = {}
        if r.gold and r.gold.exists():
            try:
                d = compute_difficulty(r.t1, r.gold, None)
                diff_meta = to_metadata(d)
            except Exception:
                diff_meta = {}

        # error topography
        if ok and self._erracc and r.gold and r.gold.exists():
            try:
                self._erracc.add(r.gold, r.student)
            except Exception:
                pass

        attempt: Dict[str, Any] = {
            "timestamp": ev.now_ts(),
            "user": self._state.cfg.user_id,
            "mode": self._state.cfg.mode,
            "group": self._state.cfg.group,
            "cohort_id": self._state.cfg.cohort_id,
            "session_id": self._state.cfg.session_id,
            "class_code": self._state.cfg.class_code,
            "casepack_version": self._state.cfg.casepack_version,
            "app_version": self._state.cfg.app_version,
            "case_id": r.case_id,
            "duration_sec": float(dur),
            "unseen": True,  # for phase-1 assume study cases are 'unseen' in test
        }
        attempt.update(metrics or {})
        attempt.update(diff_meta or {})

        # write attempt (JSON/JSONL/CSV) into per-user attempts dir
        ev.write_attempt(self.app.attempts_dir(), attempt)

        if self._state.cfg.mode == "train" and ok:
            QMessageBox.information(self, core.APP_NAME, f"Saved. Dice: {float(metrics.get('dice',0.0)):.3f}")
        else:
            QMessageBox.information(self, core.APP_NAME, "Saved.")

        self.refresh()

    def _next(self):
        if not self._state:
            return
        self._state.advance()
        if self._state.is_done():
            # save cohort maps
            try:
                if self._erracc:
                    out = core.USER_DATA / "exports" / "cohort_maps" / f"{self._state.cfg.cohort_id}_{self._state.cfg.session_id}"
                    self._erracc.save(out)
            except Exception:
                pass
            QMessageBox.information(self, core.APP_NAME, "Study run finished. Results saved." )
            self._state = None
            self._erracc = None
        else:
            self._state.start_case()
        self.refresh()

    def _open_results_dir(self):
        try:
            from lt_utils import open_default
            d = self.app.attempts_dir()
            open_default(d)
        except Exception:
            pass
