from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import shutil
import time
import uuid

import nibabel as nib
from typing import Any, Dict, List, Optional, Tuple

from PySide6.QtCore import Qt, QTimer, QSize
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QScrollArea,
    QLabel, QMessageBox, QSpinBox, QLineEdit, QDialog, QTableWidget,
    QTableWidgetItem, QHeaderView, QPushButton, QFileDialog, QBoxLayout, QSizePolicy, QComboBox, QProgressDialog
)

import lt_core as core
from classroom_sync import sync_all as classroom_sync_all
from lt_utils import now_ts, open_default
from lt_eval import make_blank_student_mask, evaluate_masks, write_attempt
from lt_case import CaseRow, list_cases
from lt_attempts import load_attempts, attempts_for_case, case_summary, next_attempt_no, export_rows_csv
from ui.widgets import btn, h1, h2, caption, Card, pill
from ui.compare_view import CompareDialog
from ui.tiles import Tile

import content_packs
from modules import cases_builtin
from modules import editor_external, editor_internal, ai_backends


@dataclass
class CaseVM:
    case_uid: str
    case_id: str
    label: str
    source_label: str
    source_kind: str  # bundled | classroom | local
    class_code: str
    t1: Optional[Path]
    gold: Optional[Path]
    student: Path
    case_dir: Path
    ready: bool
    has_gold: bool
    has_student: bool
    meta: Dict[str, Any]


class HistoryDialog(QDialog):
    def __init__(self, app, vm: CaseVM, attempts: List[Dict[str, Any]], parent=None):
        super().__init__(parent)
        self.app = app
        self.vm = vm
        self.attempts = attempts
        self.setWindowTitle(f"{core.APP_NAME} — {vm.label} history")
        self.resize(980, 520)

        v = QVBoxLayout(self)
        v.setContentsMargins(16, 16, 16, 16)
        v.setSpacing(10)

        v.addWidget(h2(vm.label))
        v.addWidget(caption(f"Source: {vm.source_label}  •  Attempts: {len(attempts)}"))

        self.table = QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels([
            "#", "Time", "Dice", "IoU", "Precision", "Recall", "|Δ| ml", "Centroid mm"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.verticalHeader().setVisible(False)
        v.addWidget(self.table, 1)

        actions = QHBoxLayout(); actions.setSpacing(10)
        self.b_export = btn("Export CSV", "ghost")
        self.b_folder = btn("Open attempts folder", "ghost")
        self.b_close = btn("Close", "primary")
        actions.addWidget(self.b_export)
        actions.addWidget(self.b_folder)
        actions.addStretch(1)
        actions.addWidget(self.b_close)
        v.addLayout(actions)

        self.b_export.clicked.connect(self._export)
        self.b_folder.clicked.connect(lambda: open_default(self.app.attempts_dir()))
        self.b_close.clicked.connect(self.accept)

        self._populate()

    def _populate(self):
        self.table.setRowCount(0)
        for i, a in enumerate(self.attempts, start=1):
            row = self.table.rowCount()
            self.table.insertRow(row)
            vals = [
                str(a.get("attempt_no") or i),
                str(a.get("timestamp") or ""),
                _fmt_float(a.get("dice")),
                _fmt_float(a.get("jaccard")),
                _fmt_float(a.get("precision")),
                _fmt_float(a.get("recall")),
                _fmt_float(a.get("vol_abs_err_ml")),
                _fmt_float(a.get("centroid_dist_mm"), 2),
            ]
            for col, val in enumerate(vals):
                self.table.setItem(row, col, QTableWidgetItem(val))

    def _export(self):
        out = core.EXPORTS_DIR / "practice_history" / f"{self.vm.case_uid.replace(':', '_')}.csv"
        export_rows_csv(out, self.attempts)
        QMessageBox.information(self, core.APP_NAME, f"Exported:\n{out}")


class PracticePage(QWidget):
    def __init__(self, app):
        super().__init__()
        self.app = app

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self._page_scroll = QScrollArea()
        self._page_scroll.setWidgetResizable(True)
        self._page_scroll.setFrameShape(QScrollArea.NoFrame)
        self._page_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        root.addWidget(self._page_scroll)

        host = QWidget()
        self._page_scroll.setWidget(host)

        v = QVBoxLayout(host)
        v.setContentsMargins(24, 20, 24, 20)
        v.setSpacing(12)

        v.addWidget(h1("Practice"))
        self.sub = caption("")
        v.addWidget(self.sub)

        self.card_join = Card(); jv = QVBoxLayout(self.card_join)
        jv.setContentsMargins(18, 16, 18, 16)
        jv.setSpacing(10)
        jv.addWidget(h2("Classroom"))
        self.lbl_join = caption("Join or update a classroom directly from Practice.")
        jv.addWidget(self.lbl_join)

        jr1 = QHBoxLayout(); jr1.setSpacing(10)
        self.ed_join_share = QLineEdit()
        self.ed_join_share.setPlaceholderText(r"Share folder / SMB path")
        self.b_join_browse = btn("Find folder…", "ghost")
        self.b_join_open = btn("Open", "ghost")
        jr1.addWidget(self.ed_join_share, 1)
        jr1.addWidget(self.b_join_browse)
        jr1.addWidget(self.b_join_open)
        jv.addLayout(jr1)

        jr2 = QHBoxLayout(); jr2.setSpacing(10)
        self.ed_join_code = QLineEdit()
        self.ed_join_code.setPlaceholderText("Classroom code")
        self.ed_join_user = QLineEdit()
        self.ed_join_user.setPlaceholderText("Username")
        self.b_join = btn("Join classroom", "primary")
        self.b_sync = btn("Sync", "ghost")
        self.b_data = btn("My data", "ghost")
        jr2.addWidget(self.ed_join_code, 1)
        jr2.addWidget(self.ed_join_user, 1)
        jr2.addWidget(self.b_join)
        jr2.addWidget(self.b_sync)
        jr2.addWidget(self.b_data)
        jv.addLayout(jr2)
        v.addWidget(self.card_join)

        tools = QHBoxLayout(); tools.setSpacing(10)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Filter cases")
        self.search.textChanged.connect(lambda *_: self.refresh())
        tools.addWidget(self.search, 1)
        tools.addStretch(1)
        v.addLayout(tools)

        src = QHBoxLayout(); src.setSpacing(10)
        self.b_builtin = btn("Built-in", "primary")
        self.b_uploaded = btn("Uploaded T1", "ghost")
        self.b_upload_t1 = btn("Upload T1…", "ghost")
        self.b_import_pack = btn("Import pack…", "ghost")
        self.b_classroom = btn("Classroom", "ghost")
        src.addWidget(self.b_builtin)
        src.addWidget(self.b_uploaded)
        src.addWidget(self.b_upload_t1)
        src.addWidget(self.b_import_pack)
        src.addWidget(self.b_classroom)
        src.addStretch(1)
        v.addLayout(src)

        self.row = QBoxLayout(QBoxLayout.LeftToRight); self.row.setSpacing(14)
        v.addLayout(self.row, 1)

        left = Card(); lv = QVBoxLayout(left)
        lv.setContentsMargins(16, 14, 16, 14)
        lv.setSpacing(10)
        lv.addWidget(h2("Choose case"))

        self._grid_host = QWidget()
        self.grid = QGridLayout(self._grid_host)
        self.grid.setContentsMargins(0, 0, 0, 0)
        self.grid.setHorizontalSpacing(12)
        self.grid.setVerticalSpacing(12)

        self.scroller = QScrollArea()
        self.scroller.setWidgetResizable(True)
        self.scroller.setFrameShape(QScrollArea.NoFrame)
        self.scroller.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroller.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.scroller.setWidget(self._grid_host)
        lv.addWidget(self.scroller, 1)
        left.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.row.addWidget(left, 3)

        self.right_wrap = QWidget()
        right_col = QVBoxLayout(self.right_wrap); right_col.setSpacing(14)
        self.right_wrap.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)

        self.card_case = Card(); cv = QVBoxLayout(self.card_case)
        cv.setContentsMargins(18, 16, 18, 16)
        cv.setSpacing(10)
        self.lbl_case = h2("Select a case")
        self.lbl_meta = caption("")
        cv.addWidget(self.lbl_case)
        cv.addWidget(self.lbl_meta)

        badge_row = QHBoxLayout(); badge_row.setSpacing(8)
        self.p_source = pill("SOURCE")
        self.p_attempts = pill("0 attempts")
        self.p_delta = pill("Δ —")
        badge_row.addWidget(self.p_source)
        badge_row.addWidget(self.p_attempts)
        badge_row.addWidget(self.p_delta)
        badge_row.addStretch(1)
        cv.addLayout(badge_row)

        metrics = QGridLayout(); metrics.setHorizontalSpacing(10); metrics.setVerticalSpacing(8)
        self.stat_latest = self._metric_label("Latest Dice")
        self.stat_best = self._metric_label("Best Dice")
        self.stat_first = self._metric_label("First Dice")
        self.stat_iou = self._metric_label("Latest IoU")
        self.stat_precision = self._metric_label("Precision")
        self.stat_recall = self._metric_label("Recall")
        for idx, widget in enumerate([
            self.stat_latest, self.stat_best, self.stat_first,
            self.stat_iou, self.stat_precision, self.stat_recall,
        ]):
            metrics.addWidget(widget, idx // 3, idx % 3)
        cv.addLayout(metrics)

        act = QHBoxLayout(); act.setSpacing(10)
        self.b_open = btn("Open", "primary")
        self.b_compare = btn("Compare", "ghost")
        self.b_eval = btn("Eval", "ghost")
        self.b_history = btn("History", "ghost")
        self.b_export = btn("Export CSV", "ghost")
        for b in [self.b_open, self.b_compare, self.b_eval, self.b_history, self.b_export]:
            act.addWidget(b)
        act.addStretch(1)
        cv.addLayout(act)

        self.card_ai = Card(); av = QVBoxLayout(self.card_ai)
        av.setContentsMargins(18, 16, 18, 16)
        av.setSpacing(10)
        av.addWidget(h2("AI draft"))
        self.lbl_ai = caption("Create a draft lesion mask from the selected case, then compare or correct it manually.")
        av.addWidget(self.lbl_ai)

        ai_row1 = QHBoxLayout(); ai_row1.setSpacing(10)
        self.ai_backend = QComboBox()
        for backend_id, label in ai_backends.backend_items():
            self.ai_backend.addItem(label, backend_id)
        self.ed_ai_custom = QLineEdit()
        self.ed_ai_custom.setPlaceholderText("Custom AI command (use {input} and {output})")
        ai_row1.addWidget(self.ai_backend, 1)
        ai_row1.addWidget(self.ed_ai_custom, 2)
        av.addLayout(ai_row1)

        self.lbl_ai_status = caption("AI draft: not created")
        av.addWidget(self.lbl_ai_status)

        ai_row2 = QHBoxLayout(); ai_row2.setSpacing(10)
        self.b_ai_run = btn("Run AI", "primary")
        self.b_ai_compare = btn("Compare AI", "ghost")
        self.b_ai_score = btn("Score AI", "ghost")
        for b in [self.b_ai_run, self.b_ai_compare, self.b_ai_score]:
            ai_row2.addWidget(b)
        ai_row2.addStretch(1)
        av.addLayout(ai_row2)

        self.card_policy = Card(); pv = QVBoxLayout(self.card_policy)
        pv.setContentsMargins(18, 16, 18, 16)
        pv.setSpacing(10)
        pv.addWidget(h2("Evaluation policy"))
        self.lbl_policy = caption("")
        pv.addWidget(self.lbl_policy)
        pol_row = QHBoxLayout(); pol_row.setSpacing(10)
        self.spin_min = QSpinBox(); self.spin_min.setRange(1, 100000); self.spin_min.setPrefix("Min voxels: ")
        self.spin_tol = QSpinBox(); self.spin_tol.setRange(0, 10000000); self.spin_tol.setPrefix("Tolerance Δvox: ")
        self.b_save_pol = btn("Save", "ghost")
        pol_row.addWidget(self.spin_min)
        pol_row.addWidget(self.spin_tol)
        pol_row.addWidget(self.b_save_pol)
        pol_row.addStretch(1)
        pv.addLayout(pol_row)

        right_col.addWidget(self.card_case, 0)
        right_col.addWidget(self.card_ai, 0)
        right_col.addWidget(self.card_policy, 0)
        right_col.addStretch(1)
        self.row.addWidget(self.right_wrap, 2)

        self.b_join_browse.clicked.connect(self._browse_join_share)
        self.b_join_open.clicked.connect(self._open_join_share)
        self.b_join.clicked.connect(self._join_from_practice)
        self.b_sync.clicked.connect(self._sync_cases)
        self.b_upload_t1.clicked.connect(self._upload_t1_case)
        self.b_import_pack.clicked.connect(self._import_content_pack)
        self.b_data.clicked.connect(lambda: open_default(core.USER_DATA))
        self.b_open.clicked.connect(self._open_selected_case)
        self.b_compare.clicked.connect(self._compare_selected)
        self.b_eval.clicked.connect(self._eval_selected)
        self.b_history.clicked.connect(self._show_history)
        self.b_export.clicked.connect(self._export_selected)
        self.b_ai_run.clicked.connect(self._run_ai_selected)
        self.b_ai_compare.clicked.connect(self._compare_ai_selected)
        self.b_ai_score.clicked.connect(self._score_ai_selected)
        self.ai_backend.currentIndexChanged.connect(self._save_ai_prefs)
        self.ed_ai_custom.editingFinished.connect(self._save_ai_prefs)
        self.b_save_pol.clicked.connect(self._save_policy)
        self.b_builtin.clicked.connect(lambda: self._set_source_filter("built_in"))
        self.b_uploaded.clicked.connect(lambda: self._set_source_filter("local"))
        self.b_classroom.clicked.connect(lambda: self._set_source_filter("classroom"))

        self._rows: List[CaseVM] = []
        self._attempt_rows: List[Dict[str, Any]] = []
        self._mtimes: Dict[str, float] = {}
        self._tiles: Dict[str, Tile] = {}
        self._selected: Optional[str] = None
        self._last_autosync: float = 0.0
        self._source_filter: str = "classroom" if self.app.mode == "student" else "built_in"
        self.ed_join_share.setText(str(getattr(self.app, "share_root", "") or core.cfg_get("share_root", "") or ""))
        self.ed_join_code.setText(str(getattr(self.app, "class_code", "") or core.cfg_get("class_code", "") or ""))
        self.ed_join_user.setText(str(getattr(self.app, "username", "student") or core.cfg_get("username", "student") or "student"))
        self.ai_backend.setCurrentIndex(max(0, self.ai_backend.findData(core.cfg_get("ai_backend", "off"))))
        self.ed_ai_custom.setText(str(core.cfg_get("ai_custom_command", "") or ""))
        self.ed_ai_custom.setVisible(self._current_ai_backend() == "custom_validated")

        self._timer = QTimer(self)
        self._timer.setInterval(1200)
        self._timer.timeout.connect(self._auto_eval_on_save)
        self._timer.start()

        self.refresh()


    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        try:
            self._apply_responsive_layout()
            self.refresh()
        except Exception:
            pass
    def _layout_width(self) -> int:
        try:
            return int(self._page_scroll.viewport().width())
        except Exception:
            return int(self.width())

    def _apply_responsive_layout(self):
        w = self._layout_width()
        try:
            self.row.setDirection(QBoxLayout.TopToBottom if w < 1180 else QBoxLayout.LeftToRight)
            self.row.setStretch(0, 3 if w >= 1180 else 1)
            self.row.setStretch(1, 2 if w >= 1180 else 1)
        except Exception:
            pass

    def _grid_columns(self) -> int:
        w = self._layout_width()
        if self.row.direction() == QBoxLayout.LeftToRight:
            w = max(320, int(w * 0.58))
        if w >= 1500:
            return 4
        if w >= 1100:
            return 3
        if w >= 720:
            return 2
        return 1

    def _metric_label(self, title: str) -> QWidget:
        card = Card(); v = QVBoxLayout(card)
        v.setContentsMargins(12, 10, 12, 10); v.setSpacing(4)
        l1 = QLabel(title); l1.setObjectName("Caption")
        l2 = QLabel("—"); l2.setObjectName("H2")
        l2.setProperty("metric_value", True)
        v.addWidget(l1)
        v.addWidget(l2)
        card.metric_value = l2
        return card

    def _set_metric(self, w: QWidget, value: str):
        try:
            w.metric_value.setText(value)
        except Exception:
            pass

    def _browse_join_share(self):
        start = str(Path(getattr(self.app, "share_root", Path.home()) or Path.home()))
        p = QFileDialog.getExistingDirectory(self, "Select classroom folder", start)
        if p:
            self.ed_join_share.setText(p)

    def _open_join_share(self):
        share_path = (self.ed_join_share.text() or "").strip()
        if share_path:
            open_default(Path(share_path))

    def _join_from_practice(self):
        share_path = (self.ed_join_share.text() or "").strip()
        class_code = (self.ed_join_code.text() or "").strip()
        username = (self.ed_join_user.text() or getattr(self.app, "username", "student") or "student").strip() or "student"
        if not share_path or not class_code:
            QMessageBox.information(self, core.APP_NAME, "Enter share folder and classroom code.")
            return
        self.app.join_classroom(share_path, class_code, username)
        self.ed_join_share.setText(str(self.app.share_root or share_path))
        self.ed_join_code.setText(str(self.app.class_code or class_code))
        self.ed_join_user.setText(str(self.app.username or username))
        self._source_filter = "classroom"
        self.refresh()

    # ---------- paths ----------
    def _class_code_from_case_dir(self, path: Path) -> str:
        try:
            parts = list(path.parts)
            idx = parts.index("classrooms")
            return str(parts[idx + 1])
        except Exception:
            return str(getattr(self.app, "class_code", "") or "")

    def _student_mask_path(self, source_kind: str, case_id: str, class_code: str = "") -> Path:
        if source_kind == "bundled":
            return core.BUNDLED_WORK / case_id / "student.nii.gz"
        if source_kind == "classroom":
            return core.CLASSROOM_WORK / (class_code or "NOCLASS") / case_id / "student.nii.gz"
        return core.STUDENT_WORK / "local" / case_id / "student.nii.gz"

    def _case_uid(self, source_kind: str, case_id: str, class_code: str = "") -> str:
        cc = str(class_code or "")
        return f"{source_kind}:{cc}:{case_id}" if cc else f"{source_kind}:{case_id}"

    # ---------- data ----------
    def _attempts(self) -> List[Dict[str, Any]]:
        return load_attempts(self.app.attempts_dir())

    def _attempt_summary(self, vm: CaseVM) -> Dict[str, Any]:
        return case_summary(self._attempt_rows, vm.case_uid)

    def _collect_builtin_rows(self) -> List[CaseVM]:
        out: List[CaseVM] = []
        for d in cases_builtin.list_cases():
            cid = str(d.get("case_id") or "").strip()
            if not cid:
                continue
            t1 = cases_builtin.resource_t1(cid)
            gold = cases_builtin.resource_gold(cid)
            student = self._student_mask_path("bundled", cid)
            out.append(CaseVM(
                case_uid=self._case_uid("bundled", cid),
                case_id=cid,
                label=str(d.get("label") or cid),
                source_label="BUILT-IN",
                source_kind="bundled",
                class_code="",
                t1=t1 if t1.exists() else None,
                gold=gold if gold.exists() else None,
                student=student,
                case_dir=cases_builtin.resource_case_dir(cid),
                ready=bool(t1.exists()),
                has_gold=bool(gold.exists()),
                has_student=bool(student.exists()),
                meta=dict(d),
            ))
        return out

    def _collect_other_rows(self) -> List[CaseVM]:
        rows = list_cases()
        chosen: Dict[Tuple[str, str], CaseRow] = {}
        wanted_class = str(getattr(self.app, "class_code", "") or "").strip().upper()
        for c in rows:
            class_code = self._class_code_from_case_dir(c.case_dir) if "classrooms" in str(c.case_dir) else ""
            source_kind = "classroom" if class_code else "local"
            if source_kind == "classroom" and wanted_class and class_code.upper() != wanted_class:
                continue
            key = (self._case_uid(source_kind, c.case_id, class_code), c.case_id)
            chosen[key] = c
        out: List[CaseVM] = []
        for (_, _), c in chosen.items():
            class_code = self._class_code_from_case_dir(c.case_dir) if "classrooms" in str(c.case_dir) else ""
            source_kind = "classroom" if class_code else "local"
            student = self._student_mask_path(source_kind, c.case_id, class_code)
            source_label = "CLASSROOM" if source_kind == "classroom" else "UPLOADED"
            out.append(CaseVM(
                case_uid=self._case_uid(source_kind, c.case_id, class_code),
                case_id=c.case_id,
                label=str((c.meta or {}).get("label") or c.case_id),
                source_label=source_label,
                source_kind=source_kind,
                class_code=class_code,
                t1=c.t1 if getattr(c, "t1", None) and c.t1.exists() else None,
                gold=c.gold if getattr(c, "gold", None) and c.gold.exists() else None,
                student=student,
                case_dir=c.case_dir,
                ready=bool(getattr(c, "t1", None) and c.t1.exists()),
                has_gold=bool(getattr(c, "gold", None) and c.gold.exists()),
                has_student=bool(student.exists()),
                meta=dict(c.meta or {}),
            ))
        out.sort(key=lambda x: (x.source_kind == "classroom", x.label.lower()))
        return out

    def _collect_rows(self) -> List[CaseVM]:
        out = self._collect_builtin_rows()
        extra = self._collect_other_rows()
        seen = {vm.case_uid for vm in out}
        for vm in extra:
            if vm.case_uid not in seen:
                seen.add(vm.case_uid)
                out.append(vm)
        return out

    def _vm(self, case_uid: str) -> Optional[CaseVM]:
        for r in self._rows:
            if r.case_uid == case_uid:
                return r
        return None

    def _set_button_kind(self, button: QPushButton, kind: str):
        button.setObjectName({"primary": "BtnPrimary", "ghost": "BtnGhost", "danger": "BtnDanger"}.get(kind, "BtnGhost"))
        button.style().unpolish(button)
        button.style().polish(button)
        button.update()

    def _set_source_filter(self, mode: str):
        self._source_filter = "classroom" if mode == "classroom" else "built_in"
        self.refresh()

    def _visible_rows(self, rows: List[CaseVM]) -> List[CaseVM]:
        if self._source_filter == "classroom":
            wanted_class = str(getattr(self.app, "class_code", "") or "").strip().upper()
            out = [r for r in rows if r.source_kind == "classroom"]
            if wanted_class:
                out = [r for r in out if (r.class_code or "").upper() == wanted_class]
            return out
        if self._source_filter == "local":
            return [r for r in rows if r.source_kind == "local"]
        return [r for r in rows if r.source_kind == "bundled"]

    # ---------- UI ----------
    def refresh(self):
        try:
            if self.app.mode == "student" and getattr(self.app, "share_root", None) and getattr(self.app, "class_code", None):
                import time
                if time.time() - getattr(self, "_last_autosync", 0.0) > 30.0:
                    classroom_sync_all(Path(self.app.share_root), self.app.class_code)
                    self._last_autosync = time.time()
        except Exception:
            pass

        core.ensure_dirs()
        try:
            cases_builtin.ensure_workspace_entries()
        except Exception:
            pass

        self._apply_responsive_layout()
        self._rows = self._collect_rows()
        self._attempt_rows = self._attempts()

        self.ed_join_share.setText(str(getattr(self.app, "share_root", "") or self.ed_join_share.text() or core.cfg_get("share_root", "") or ""))
        self.ed_join_code.setText(str(getattr(self.app, "class_code", "") or self.ed_join_code.text() or core.cfg_get("class_code", "") or ""))
        self.ed_join_user.setText(str(getattr(self.app, "username", "student") or self.ed_join_user.text() or core.cfg_get("username", "student") or "student"))

        classroom_exists = any(r.source_kind == "classroom" for r in self._rows)
        local_exists = any(r.source_kind == "local" for r in self._rows)
        if self.app.mode == "student" and classroom_exists:
            if self._source_filter not in ("classroom", "built_in"):
                self._source_filter = "classroom"
        elif self._source_filter == "classroom" and not classroom_exists:
            self._source_filter = "local" if local_exists else "built_in"
        elif self._source_filter == "local" and not local_exists:
            self._source_filter = "built_in"

        self.b_classroom.setVisible(self.app.mode in ("student", "teacher") or bool(self.ed_join_code.text().strip()))
        self._set_button_kind(self.b_builtin, "primary" if self._source_filter == "built_in" else "ghost")
        self._set_button_kind(self.b_uploaded, "primary" if self._source_filter == "local" else "ghost")
        self._set_button_kind(self.b_classroom, "primary" if self._source_filter == "classroom" else "ghost")

        q = (self.search.text() or "").strip().lower()
        rows = self._visible_rows(self._rows)
        rows = [r for r in rows if (not q) or (q in r.label.lower()) or (q in r.case_id.lower())]
        self.search.setVisible(len(rows) > 8)

        while self.grid.count():
            item = self.grid.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)
        self._tiles.clear()

        if not rows:
            msg = "No classroom cases synced yet." if self._source_filter == "classroom" else "No built-in cases found."
            empty = QLabel(msg)
            empty.setObjectName("Muted")
            empty.setAlignment(Qt.AlignCenter)
            self.grid.addWidget(empty, 0, 0)
        else:
            cols = self._grid_columns()
            for i, vm in enumerate(rows):
                summ = self._attempt_summary(vm)
                latest = summ.get("latest_dice")
                delta = summ.get("delta_dice")
                badge = f"Dice {_fmt_float(latest)}" if latest is not None else ("READY" if vm.ready else "COMING SOON")
                sub = f"{summ.get('attempts',0)} attempts"
                if delta is not None and summ.get("attempts", 0) >= 2:
                    sub += f"  •  Δ {_fmt_delta(delta)}"
                t = Tile(vm.label, sub, badge=badge, icon="●" if vm.ready else "○", min_h=62)
                t.lbl_title.setWordWrap(True)
                t.lbl_sub.setWordWrap(False)
                t.lbl_sub.setMaximumHeight(16)
                if vm.ready and latest is None:
                    t.lbl_badge.setStyleSheet("padding:4px 10px; border-radius:999px; background: rgba(70,210,120,0.14); border:1px solid rgba(70,210,120,0.45); color:#8CFFB3; font-weight:900; font-size:11px;")
                elif not vm.ready:
                    t.lbl_badge.setStyleSheet("padding:4px 10px; border-radius:999px; background: rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:#9aa3b2; font-weight:900; font-size:11px;")
                t.clicked.connect(lambda cid=vm.case_uid: self._select(cid))
                self._tiles[vm.case_uid] = t
                self.grid.addWidget(t, i // cols, i % cols)

        self.card_join.setVisible(self.app.mode != "teacher")
        self.right_wrap.setMaximumWidth(16777215 if self.row.direction() == QBoxLayout.TopToBottom else 520)
        self.b_join.setVisible(self.app.mode != "teacher")
        self.b_sync.setVisible(self.app.mode == "student")
        if self.app.mode == "student":
            pol = self.app.locked_policy or {}
            mv = int(pol.get("min_voxels", core.DEFAULT_MIN_VOXELS))
            tol = int(pol.get("tolerance", core.DEFAULT_TOLERANCE))
            self.lbl_policy.setText(f"Locked by classroom: min_voxels={mv}  •  tolerance Δvox={tol}")
            self.spin_min.setVisible(False); self.spin_tol.setVisible(False); self.b_save_pol.setVisible(False)
            self.sub.setText(f"Student mode • class {self.app.class_code or '—'}")
            self.lbl_join.setText("Classroom connected. Sync refreshes the visible classroom cases.")
        elif self.app.mode == "teacher":
            self.lbl_policy.setText("Solo thresholds (used for pass/fail + logging)")
            self.spin_min.setVisible(True); self.spin_tol.setVisible(True); self.b_save_pol.setVisible(True)
            self.spin_min.setValue(int(self.app.solo_min_voxels)); self.spin_tol.setValue(int(self.app.solo_tolerance))
            self.sub.setText("Teacher mode")
            self.lbl_join.setText("Teacher mode uses the Teacher page for classroom setup.")
        else:
            self.lbl_policy.setText("Solo thresholds (used for pass/fail + logging)")
            self.spin_min.setVisible(True); self.spin_tol.setVisible(True); self.b_save_pol.setVisible(True)
            self.spin_min.setValue(int(self.app.solo_min_voxels)); self.spin_tol.setValue(int(self.app.solo_tolerance))
            self.sub.setText("Offline mode")
            self.lbl_join.setText("Enter share folder, classroom code, and username here to join directly.")

        visible_ids = {r.case_uid for r in rows}
        if self._selected not in visible_ids:
            self._selected = None
        if self._selected is None:
            ready = next((r.case_uid for r in rows if r.ready), None)
            self._selected = ready or (rows[0].case_uid if rows else None)
        if self._selected and self._selected in self._tiles:
            self._tiles[self._selected].set_selected(True)
        self._on_selected()

    def _select(self, cid: str):
        self._selected = cid
        for k, t in self._tiles.items():
            t.set_selected(k == cid)
        self._on_selected()

    def _on_selected(self):
        cid = self._selected
        if not cid:
            self.lbl_case.setText("Select a case")
            self.lbl_meta.setText("")
            for w in [self.stat_latest, self.stat_best, self.stat_first, self.stat_iou, self.stat_precision, self.stat_recall]:
                self._set_metric(w, "—")
            for b in [self.b_open, self.b_compare, self.b_eval, self.b_history, self.b_export, self.b_ai_run, self.b_ai_compare, self.b_ai_score]:
                b.setEnabled(False)
            self.lbl_ai_status.setText("AI draft: not created")
            return

        vm = self._vm(cid)
        if not vm:
            return
        self.lbl_case.setText(vm.label)
        summ = self._attempt_summary(vm)

        meta = [
            f"Source: {vm.source_label}",
            ("Status: READY" if vm.ready else "Status: COMING SOON"),
            f"Gold: {'yes' if vm.has_gold else 'no'}",
            f"Your mask: {'yes' if vm.student.exists() else 'no'}",
        ]
        if summ.get("last_timestamp"):
            meta.append(f"Last: {summ.get('last_timestamp')}")
        self.lbl_meta.setText("  •  ".join(meta))

        self.p_source.setText(vm.source_label)
        self.p_attempts.setText(f"{summ.get('attempts', 0)} attempts")
        self.p_delta.setText(f"Δ {_fmt_delta(summ.get('delta_dice'))}" if summ.get('delta_dice') is not None else "Δ —")

        self._set_metric(self.stat_latest, _fmt_float(summ.get("latest_dice")))
        self._set_metric(self.stat_best, _fmt_float(summ.get("best_dice")))
        self._set_metric(self.stat_first, _fmt_float(summ.get("first_dice")))
        self._set_metric(self.stat_iou, _fmt_float(summ.get("latest_iou")))
        self._set_metric(self.stat_precision, _fmt_float(summ.get("latest_precision")))
        self._set_metric(self.stat_recall, _fmt_float(summ.get("latest_recall")))

        can_open = bool(vm.ready and vm.t1)
        ai_path = self._ai_draft_path(vm)
        has_ai = ai_path.exists()
        self.b_open.setEnabled(can_open)
        self.b_compare.setEnabled(bool(vm.ready and vm.has_gold and vm.student.exists()))
        self.b_eval.setEnabled(bool(vm.ready and vm.has_gold and vm.student.exists()))
        self.b_history.setEnabled(True)
        self.b_export.setEnabled(bool(summ.get("attempts", 0) > 0))
        self.b_ai_run.setEnabled(can_open and self._current_ai_backend() != "off")
        self.b_ai_compare.setEnabled(bool(can_open and has_ai and ((vm.has_gold) or vm.student.exists())))
        self.b_ai_score.setEnabled(bool(vm.ready and vm.has_gold and has_ai))
        self.lbl_ai_status.setText(f"AI draft: {ai_path.name}" if has_ai else "AI draft: not created")
        is_custom = self._current_ai_backend() == "custom_validated"
        self.ed_ai_custom.setVisible(is_custom)

    def _save_ai_prefs(self):
        try:
            core.cfg_set("ai_backend", self.ai_backend.currentData())
            core.cfg_set("ai_custom_command", self.ed_ai_custom.text().strip())
        except Exception:
            pass

    def _selected_vm(self) -> Optional[CaseVM]:
        return self._vm(self._selected or "")

    def _ai_draft_path(self, vm: CaseVM) -> Path:
        return ai_backends.ai_draft_path(vm.student)

    def _current_ai_backend(self) -> str:
        return str(self.ai_backend.currentData() or "off")

    def _current_ai_label(self) -> str:
        return ai_backends.backend_label(self._current_ai_backend())

    # ---------- policy ----------
    def _save_policy(self):
        try:
            self.app.solo_min_voxels = int(self.spin_min.value())
            self.app.solo_tolerance = int(self.spin_tol.value())
            core.cfg_set("solo_min_voxels", int(self.app.solo_min_voxels))
            core.cfg_set("solo_tolerance", int(self.app.solo_tolerance))
            self.app.toast("Saved thresholds")
        except Exception as e:
            QMessageBox.critical(self, core.APP_NAME, f"Could not save: {e}")

    def _upload_t1_case(self):
        start = str(Path.home())
        file_path, _ = QFileDialog.getOpenFileName(self, "Select T1 MRI", start, "NIfTI (*.nii *.nii.gz)")
        if not file_path:
            return
        src = Path(file_path)
        case_id = f"upload_{uuid.uuid4().hex[:8]}"
        case_dir = core.LOCAL_CASES / case_id
        try:
            case_dir.mkdir(parents=True, exist_ok=True)
            img = nib.load(str(src))
            nib.save(img, str(case_dir / 't1.nii.gz'))
            meta = {
                'case_id': case_id,
                'label': src.stem.replace('.nii', ''),
                'source': 'LOCAL',
            }
            (case_dir / 'case.json').write_text(__import__('json').dumps(meta, indent=2), encoding='utf-8')
        except Exception as e:
            QMessageBox.critical(self, core.APP_NAME, f"Could not import T1: {e}")
            try:
                shutil.rmtree(case_dir, ignore_errors=True)
            except Exception:
                pass
            return
        self._source_filter = 'local'
        self.refresh()
        for vm in self._rows:
            if vm.case_id == case_id and vm.source_kind == 'local':
                self._select(vm.case_uid)
                break
        self.app.toast('T1 imported')


    def _import_content_pack(self):
        path, _ = QFileDialog.getOpenFileName(self, "Import content pack", str(Path.home()), "SegLab pack (*.seglabpack)")
        if not path:
            return
        try:
            pack_id, case_count, mat_count = content_packs.install_pack(Path(path))
            self._source_filter = "local"
            self.refresh()
            QMessageBox.information(self, core.APP_NAME, f"Imported content pack: {pack_id}\n\nCases: {case_count}\nMaterials: {mat_count}")
        except Exception as e:
            QMessageBox.critical(self, core.APP_NAME, f"Could not import content pack: {e}")

    # ---------- classroom ----------
    def _sync_cases(self):
        if self.app.mode != "student" or not self.app.share_root or not self.app.class_code:
            QMessageBox.information(self, core.APP_NAME, "Join a classroom first.")
            return
        try:
            classroom_sync_all(Path(self.app.share_root), self.app.class_code)
            self._source_filter = "classroom"
            self.refresh()
            self.app.toast("Synced classroom cases")
        except Exception as e:
            QMessageBox.critical(self, core.APP_NAME, f"Sync failed: {e}")
        self.refresh()

    # ---------- actions ----------
    def _choose_editor(self) -> str:
        if editor_internal.available():
            from PySide6.QtWidgets import QInputDialog
            choice, ok = QInputDialog.getItem(
                self,
                core.APP_NAME,
                "Choose editor",
                ["Internal editor", "ITK‑SNAP (external)"],
                0,
                False,
            )
            if ok and "Internal" in choice:
                return "internal"
        return "itksnap"

    def _open_selected_case(self):
        vm = self._vm(self._selected or "")
        if not vm or not vm.ready or not vm.t1:
            QMessageBox.information(self, core.APP_NAME, "Case not ready.")
            return
        vm.student.parent.mkdir(parents=True, exist_ok=True)
        if not vm.student.exists():
            ai_path = self._ai_draft_path(vm)
            if ai_path.exists():
                import shutil
                try:
                    shutil.copy2(ai_path, vm.student)
                except Exception as e:
                    QMessageBox.critical(self, core.APP_NAME, f"Could not copy AI draft: {e}")
                    return
            else:
                ok, msg = make_blank_student_mask(vm.t1, vm.student)
                if not ok:
                    QMessageBox.critical(self, core.APP_NAME, msg)
                    return

        ed = self._choose_editor()
        self.app.editor = ed
        if ed == "internal":
            try:
                editor_internal.open_case(vm.t1, vm.student)
            except Exception as e:
                QMessageBox.critical(self, core.APP_NAME, f"Internal editor failed: {e}")
            return

        ok, msg = editor_external.open_case(vm.t1, vm.student)
        if not ok:
            QMessageBox.critical(self, core.APP_NAME, msg)
        else:
            self.app.toast("Opened in ITK‑SNAP")
        self.refresh()

    def _compare_selected(self):
        vm = self._vm(self._selected or "")
        if not vm or not (vm.t1 and vm.gold and vm.student.exists() and vm.gold.exists()):
            return
        dlg = CompareDialog(vm.t1, vm.student, vm.gold, parent=self)
        dlg.exec()

    def _eval_selected(self):
        vm = self._vm(self._selected or "")
        if not vm:
            return
        self._eval_case(vm.case_uid, forced=True)

    def _show_history(self):
        vm = self._vm(self._selected or "")
        if not vm:
            return
        attempts = attempts_for_case(self._attempt_rows, vm.case_uid)
        dlg = HistoryDialog(self.app, vm, attempts, parent=self)
        dlg.exec()

    def _export_selected(self):
        vm = self._vm(self._selected or "")
        if not vm:
            return
        attempts = attempts_for_case(self._attempt_rows, vm.case_uid)
        if not attempts:
            QMessageBox.information(self, core.APP_NAME, "No attempts yet for this case.")
            return
        out = core.EXPORTS_DIR / "practice_history" / f"{vm.case_uid.replace(':', '_')}.csv"
        export_rows_csv(out, attempts)
        QMessageBox.information(self, core.APP_NAME, f"Exported:\n{out}")

    def _run_ai_selected(self):
        vm = self._selected_vm()
        if not vm or not vm.ready or not vm.t1:
            QMessageBox.information(self, core.APP_NAME, "Case not ready.")
            return
        backend_id = self._current_ai_backend()
        if backend_id == 'off':
            QMessageBox.information(self, core.APP_NAME, "Choose an AI backend first.")
            return
        out_path = self._ai_draft_path(vm)
        self._save_ai_prefs()
        progress = QProgressDialog("Running AI…", None, 0, 0, self)
        progress.setWindowTitle(core.APP_NAME)
        progress.setCancelButton(None)
        progress.setMinimumDuration(0)
        progress.setWindowModality(Qt.ApplicationModal)
        progress.show()
        self.lbl_ai_status.setText("AI draft: running…")
        from PySide6.QtWidgets import QApplication
        QApplication.processEvents()
        ok, msg = ai_backends.run_ai_backend(backend_id, vm.t1, out_path, self.ed_ai_custom.text().strip())
        progress.close()
        if not ok or not out_path.exists():
            self.lbl_ai_status.setText("AI draft: failed")
            QMessageBox.information(self, core.APP_NAME, msg)
            self.refresh()
            return
        self.lbl_ai_status.setText(f"AI draft: {out_path.name}")
        self.app.toast("AI draft created")
        self.refresh()

    def _compare_ai_selected(self):
        vm = self._selected_vm()
        if not vm or not vm.t1:
            return
        ai_path = self._ai_draft_path(vm)
        if not ai_path.exists():
            QMessageBox.information(self, core.APP_NAME, "No AI draft for this case.")
            return
        ref = vm.gold if (vm.gold and vm.gold.exists()) else (vm.student if vm.student.exists() else None)
        if ref is None:
            QMessageBox.information(self, core.APP_NAME, "No gold or manual mask available for comparison.")
            return
        dlg = CompareDialog(vm.t1, ai_path, ref, parent=self)
        dlg.exec()

    def _score_ai_selected(self):
        vm = self._selected_vm()
        if not vm or not vm.t1 or not vm.gold or not vm.gold.exists():
            return
        ai_path = self._ai_draft_path(vm)
        if not ai_path.exists():
            QMessageBox.information(self, core.APP_NAME, "No AI draft for this case.")
            return
        ok, msg, metrics = evaluate_masks(vm.gold, ai_path)
        if not ok:
            QMessageBox.information(self, core.APP_NAME, msg)
            return
        attempt_no = next_attempt_no(self._attempt_rows, vm.case_uid)
        attempt = {
            "timestamp": now_ts(),
            "user": getattr(self.app, "username", ""),
            "mode": self.app.mode,
            "class_code": vm.class_code or (getattr(self.app, "class_code", "") or ""),
            "case_id": vm.case_id,
            "case_uid": vm.case_uid,
            "source_kind": vm.source_kind,
            "source_label": vm.source_label,
            "session": "practice",
            "attempt_no": attempt_no,
            "passed": False,
            "editor": "ai",
            "prediction_source": "ai",
            "model_name": self._current_ai_label(),
            "student_mask_path": str(ai_path),
            "gold_mask_path": str(vm.gold),
            "t1_path": str(vm.t1),
        }
        attempt.update(metrics or {})
        try:
            write_attempt(self.app.attempts_dir(), attempt)
        except Exception as e:
            QMessageBox.critical(self, core.APP_NAME, f"Could not write AI attempt: {e}")
            return
        self._attempt_rows = self._attempts()
        self.refresh()
        QMessageBox.information(self, core.APP_NAME, f"AI Dice: {float(metrics.get('dice', 0.0)):.3f}\nAI IoU: {float(metrics.get('jaccard', 0.0)):.3f}")

    # ---------- evaluation ----------
    def _eval_case(self, case_uid: str, forced: bool = False):
        vm = self._vm(case_uid)
        if not vm or not (vm.t1 and vm.student.exists()):
            return

        if self.app.mode == "student":
            pol = self.app.locked_policy or {}
            mv = int(pol.get("min_voxels", core.DEFAULT_MIN_VOXELS))
            tol = int(pol.get("tolerance", core.DEFAULT_TOLERANCE))
            session = str(pol.get("session", "practice"))
        else:
            mv = int(getattr(self.app, "solo_min_voxels", core.DEFAULT_MIN_VOXELS))
            tol = int(getattr(self.app, "solo_tolerance", core.DEFAULT_TOLERANCE))
            session = "practice"

        if not vm.gold or not vm.gold.exists():
            if forced:
                QMessageBox.information(self, core.APP_NAME, "Gold mask not available for this case.")
            return

        ok, msg, metrics = evaluate_masks(vm.gold, vm.student)
        if not ok:
            if forced:
                QMessageBox.information(self, core.APP_NAME, msg)
            return

        attempt_no = next_attempt_no(self._attempt_rows, vm.case_uid)
        mismatch = int(metrics.get("mismatch_voxels", 0) or 0)
        passed = bool(int(metrics.get("student_voxels", 0) or 0) >= mv and mismatch <= tol)

        attempt: Dict[str, Any] = {
            "timestamp": now_ts(),
            "user": getattr(self.app, "username", ""),
            "mode": self.app.mode,
            "class_code": vm.class_code or (getattr(self.app, "class_code", "") or ""),
            "case_id": vm.case_id,
            "case_uid": vm.case_uid,
            "source_kind": vm.source_kind,
            "source_label": vm.source_label,
            "session": session,
            "attempt_no": attempt_no,
            "min_voxels": mv,
            "tolerance": tol,
            "passed": passed,
            "editor": getattr(self.app, "editor", "itksnap"),
            "prediction_source": "human",
            "model_name": "",
            "student_mask_path": str(vm.student),
            "gold_mask_path": str(vm.gold),
            "t1_path": str(vm.t1),
        }
        attempt.update(metrics or {})

        try:
            write_attempt(self.app.attempts_dir(), attempt)
            self._attempt_rows = self._attempts()
            self.refresh()
        except Exception as e:
            if forced:
                QMessageBox.critical(self, core.APP_NAME, f"Could not write attempt: {e}")
            return

        if forced:
            QMessageBox.information(
                self,
                core.APP_NAME,
                f"Dice: {float(metrics.get('dice', 0.0)):.3f}\n"
                f"IoU: {float(metrics.get('jaccard', 0.0)):.3f}\n"
                f"Attempt: {attempt_no}",
            )

    def _auto_eval_on_save(self):
        for vm in self._rows:
            if not vm.student.exists():
                continue
            try:
                m = vm.student.stat().st_mtime
            except Exception:
                continue
            key = vm.case_uid
            if key not in self._mtimes:
                self._mtimes[key] = m
                continue
            if m > self._mtimes[key] + 0.5:
                self._mtimes[key] = m
                self._eval_case(vm.case_uid)


def _fmt_float(x: Any, nd: int = 3) -> str:
    try:
        return f"{float(x):.{nd}f}"
    except Exception:
        return "—"


def _fmt_delta(x: Any, nd: int = 3) -> str:
    try:
        v = float(x)
        return f"{v:+.{nd}f}"
    except Exception:
        return "—"
