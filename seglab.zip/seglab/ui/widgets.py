from __future__ import annotations

from PySide6.QtCore import Qt, QRect
from PySide6.QtGui import QColor, QPainter
from PySide6.QtWidgets import QLabel, QPushButton, QGraphicsDropShadowEffect


class NeonTextLabel(QLabel):
    """Neon-ish text glow *without* the ugly 'box glow'.

    QGraphicsDropShadowEffect glows the widget rect and looks like cyan frames.
    This draws a subtle halo by re-drawing the text a few times.
    """

    def __init__(self, text: str, glow: QColor | None = None, radius: int = 2, strength: int = 36):
        super().__init__(text)
        self._glow = glow or QColor(25, 229, 255, strength)
        self._radius = max(1, int(radius))
        self._strength = int(strength)

    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.TextAntialiasing, True)

        r: QRect = self.rect()
        flags = int(self.alignment())
        txt = self.text()

        if self._strength > 0:
            g = QColor(self._glow)
            # Keep it modern: small offsets only.
            for dx, dy, a in [
                (-self._radius, 0, self._strength),
                ( self._radius, 0, self._strength),
                (0, -self._radius, self._strength),
                (0,  self._radius, self._strength),
                (-1, -1, max(10, self._strength - 10)),
                ( 1, -1, max(10, self._strength - 10)),
                (-1,  1, max(10, self._strength - 10)),
                ( 1,  1, max(10, self._strength - 10)),
            ]:
                g.setAlpha(a)
                p.setPen(g)
                p.setFont(self.font())
                p.drawText(r.translated(dx, dy), flags, txt)

        # Main text (stylesheet color)
        p.setPen(self.palette().windowText().color())
        p.setFont(self.font())
        p.drawText(r, flags, txt)


def neon(widget, color: QColor | None = None, blur: int = 14, strength: int = 110) -> None:
    """Legacy helper (kept for non-text widgets only)."""
    try:
        c = color or QColor(25, 229, 255, strength)
        fx = QGraphicsDropShadowEffect(widget)
        fx.setBlurRadius(int(blur))
        fx.setXOffset(0)
        fx.setYOffset(0)
        fx.setColor(c)
        widget.setGraphicsEffect(fx)
    except Exception:
        pass

def btn(text: str, kind: str = "ghost") -> QPushButton:
    b = QPushButton(text)
    b.setCursor(Qt.PointingHandCursor)
    b.setMinimumHeight(36)
    b.setObjectName({"primary":"BtnPrimary","ghost":"BtnGhost","danger":"BtnDanger"}.get(kind,"BtnGhost"))
    return b

def h1(text: str) -> QLabel:
    l = NeonTextLabel(text, glow=QColor(25, 229, 255, 26), radius=2, strength=26)
    l.setObjectName("H1")
    return l

def h2(text: str) -> QLabel:
    l = NeonTextLabel(text, glow=QColor(25, 229, 255, 18), radius=1, strength=18)
    l.setObjectName("H2")
    return l


def section_title(text: str) -> QLabel:
    l = QLabel((text or "").upper())
    l.setObjectName("SectionTitle")
    return l

def caption(text: str) -> QLabel:
    l = QLabel(text); l.setObjectName("Caption"); l.setWordWrap(True); return l

def muted(text: str) -> QLabel:
    l = QLabel(text); l.setObjectName("Muted"); l.setWordWrap(True); return l

def pill(text: str) -> QLabel:
    l = QLabel(text)
    l.setObjectName("Pill")
    l.setAlignment(Qt.AlignCenter)
    return l


from PySide6.QtWidgets import QWidget


class Card(QWidget):
    """Simple panel container.

    Do NOT set a layout here; pages attach their own layout (QGridLayout/QVBoxLayout)
    to avoid the "already has a layout" warning.
    """

    def __init__(self):
        super().__init__()
        self.setObjectName("Card")

        # Subtle depth ("device" feel). QSS can't do box-shadow, so we add it here.
        fx = QGraphicsDropShadowEffect(self)
        fx.setBlurRadius(24)
        fx.setXOffset(0)
        fx.setYOffset(10)
        fx.setColor(QColor(0, 0, 0, 180))
        self.setGraphicsEffect(fx)
