from __future__ import annotations

from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QGridLayout

import lt_core as core
from ui.widgets import h1, caption, btn
from ui.tiles import Tile


class HomePage(QWidget):
    """Single landing page.

    Design goals:
    - looks like a serious workstation (not a button wall)
    - minimal copy
    - tiles are the primary navigation
    """

    def __init__(self, app):
        super().__init__()
        self.app = app

        v = QVBoxLayout(self)
        v.setContentsMargins(32, 26, 32, 26)
        v.setSpacing(14)

        v.addWidget(h1(core.APP_NAME))
        self.sub = caption("")
        v.addWidget(self.sub)

        grid = QGridLayout()
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(14)
        v.addLayout(grid, 1)

        self.t_offline = Tile(
            "Offline training",
            "Built-in cases",
            badge="LOCAL",
            icon="◎",
        )
        self.t_join = Tile(
            "Student",
            "Classroom cases",
            badge="SMB",
            icon="⟐",
        )
        self.t_teacher = Tile(
            "Teacher",
            "Classroom dashboard",
            badge="SMB",
            icon="⟠",
        )
        self.t_intro = Tile(
            "Introduction to lesion segmentation",
            "Reference material",
            badge="LEARN",
            icon="▦",
        )
        self.t_study = Tile(
            "Study (Train/Test)",
            "Locked evaluation",
            badge="RESEARCH",
            icon="▣",
        )

        grid.addWidget(self.t_offline, 0, 0)
        grid.addWidget(self.t_join, 0, 1)
        grid.addWidget(self.t_teacher, 1, 0)
        grid.addWidget(self.t_intro, 1, 1)
        grid.addWidget(self.t_study, 2, 0, 1, 2)

        # small strip
        row = QHBoxLayout(); row.setSpacing(10)
        self.b_practice = btn("Practice", "ghost")
        self.b_progress = btn("Progress", "ghost")
        self.b_updates = btn("Updates", "ghost")
        self.b_updates.setToolTip("Check for updates")
        row.addWidget(self.b_practice)
        row.addWidget(self.b_progress)
        row.addWidget(self.b_updates)
        row.addStretch(1)
        v.addLayout(row)

        self.t_offline.clicked.connect(self.app.enter_solo)
        self.t_join.clicked.connect(lambda: self.app.goto("Join"))
        self.t_teacher.clicked.connect(lambda: self.app.goto("Teacher"))
        self.t_intro.clicked.connect(lambda: self.app.goto("Introduction"))
        self.t_study.clicked.connect(lambda: self.app.goto("Study"))

        self.b_practice.clicked.connect(lambda: self.app.goto("Practice"))
        self.b_progress.clicked.connect(lambda: self.app.goto("Progress"))
        self.b_updates.clicked.connect(self._updates)

        self.refresh()

    def _updates(self):
        import lt_update as up
        up.install_update_with_progress(parent=self, on_quit=self.app.quit_for_update)

    def refresh(self):
        self.b_updates.setText("Updates")
        self.t_teacher.setVisible(self.app.mode != "student")
        if self.app.mode == "solo":
            self.sub.setText("Offline")
        elif self.app.mode == "student":
            self.sub.setText(f"Student • class {self.app.class_code or '—'}")
        elif self.app.mode == "teacher":
            self.sub.setText(f"Teacher • class {self.app.class_code or '—'}")
        else:
            self.sub.setText("Choose Student or Teacher")
