from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont
from PySide6.QtWidgets import QPushButton

from ui.widgets import neon


class DeckIconButton(QPushButton):
    """Minimal numbered "app icon" launcher for a deck (PDF/PPTX).

    Requirements:
    - icon buttons (not big boxed cards)
    - auto-generate from files present in the bundled folders
    - show only numbers (01/02/03/…); filename is tooltip
    """

    open_path = Signal(Path)

    def __init__(self, idx: int, path: Path):
        super().__init__(f"{idx:02d}")
        self._path = Path(path)

        self.setObjectName("DeckIcon")
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedSize(86, 86)
        self.setToolTip(self._path.name)

        f = QFont(self.font())
        f.setPointSize(26)
        f.setWeight(QFont.Black)
        self.setFont(f)

        self.setFocusPolicy(Qt.NoFocus)
        # Do NOT add drop-shadow glow here — it creates 'cyan boxes' around icons.

        self.clicked.connect(lambda: self.open_path.emit(self._path))
