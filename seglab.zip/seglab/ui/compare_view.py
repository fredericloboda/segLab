from __future__ import annotations

from pathlib import Path
from typing import Optional

import numpy as np

from PySide6.QtCore import Qt
from PySide6.QtGui import QImage, QPixmap
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QSlider, QPushButton, QMessageBox
)

import lt_core as core
import lt_editor as editor
from lt_compare3d import build_3d_compare_labelmap


def _render_slice(
    t1: np.ndarray,
    mask: Optional[np.ndarray],
    z: int,
    overlay_rgb=(220, 60, 60),
    alpha: float = 0.35,
) -> QImage:
    """Render axial slice z: grayscale T1 with optional binary mask overlay."""
    z = int(np.clip(z, 0, t1.shape[2] - 1))
    sl = t1[:, :, z].astype(np.float32)

    # robust normalization (ignore extremes)
    lo, hi = np.percentile(sl, [1, 99])
    if hi <= lo:
        hi = lo + 1.0
    sln = (np.clip(sl, lo, hi) - lo) / (hi - lo)
    base = (sln * 255.0).astype(np.uint8)

    rgb = np.stack([base, base, base], axis=-1).astype(np.float32)

    if mask is not None and mask.shape[:3] == t1.shape[:3]:
        m = mask[:, :, z] > 0
        if m.any():
            col = np.array(overlay_rgb, dtype=np.float32)[None, None, :]
            rgb[m] = (1.0 - alpha) * rgb[m] + alpha * col

    rgb_u8 = np.clip(rgb, 0, 255).astype(np.uint8)
    h, w, _ = rgb_u8.shape
    buf = np.ascontiguousarray(rgb_u8)
    return QImage(buf.data, w, h, w * 3, QImage.Format_RGB888).copy()


class CompareDialog(QDialog):
    """
    Side-by-side comparison:
      Left = Your mask overlay
      Right = Gold mask overlay
    """
    def __init__(self, t1_path: Path, student_mask: Path, gold_mask: Path, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"{core.APP_NAME} — Compare masks")
        self.resize(1320, 720)

        self.t1_path = Path(t1_path)
        self.student_path = Path(student_mask)
        self.gold_path = Path(gold_mask)

        self._t1 = None
        self._student = None
        self._gold = None
        self._z = 0

        v = QVBoxLayout(self)
        v.setContentsMargins(14, 14, 14, 14)
        v.setSpacing(10)

        top = QHBoxLayout()
        self.lbl_info = QLabel("")
        self.lbl_info.setWordWrap(True)
        top.addWidget(self.lbl_info, 1)

        self.btn_3d = QPushButton("3D Compare")
        self.btn_3d.setObjectName("BtnGhost")
        self.btn_3d.clicked.connect(self._open_3d)
        top.addWidget(self.btn_3d, 0)

        self.btn_close = QPushButton("Close")
        self.btn_close.clicked.connect(self.close)
        top.addWidget(self.btn_close, 0)
        v.addLayout(top)

        row = QHBoxLayout()
        row.setSpacing(10)

        self.left = QLabel("Loading…")
        self.left.setAlignment(Qt.AlignCenter)
        self.left.setMinimumHeight(520)
        self.left.setStyleSheet("border:1px solid rgba(255,255,255,0.12); border-radius:16px;")

        self.right = QLabel("Loading…")
        self.right.setAlignment(Qt.AlignCenter)
        self.right.setMinimumHeight(520)
        self.right.setStyleSheet("border:1px solid rgba(255,255,255,0.12); border-radius:16px;")

        row.addWidget(self.left, 1)
        row.addWidget(self.right, 1)
        v.addLayout(row, 1)

        bot = QHBoxLayout()
        bot.setSpacing(10)
        self.slider = QSlider(Qt.Horizontal)
        self.slider.setMinimum(0)
        self.slider.setMaximum(0)
        self.slider.valueChanged.connect(self._on_slider)

        bot.addWidget(QLabel("Slice"))
        bot.addWidget(self.slider, 1)
        v.addLayout(bot)

        self._load()

    def _open_3d(self):
        # This uses ITK-SNAP's 3D renderer (for now) by generating a multi-label map.
        ok, msg, out_path = build_3d_compare_labelmap(
            self.t1_path,
            self.student_path,
            self.gold_path,
            case_id=self.t1_path.stem,
        )
        if not ok:
            QMessageBox.information(self, core.APP_NAME, msg)
            return
        editor.launch(self.t1_path, out_path)

    def _load(self):
        try:
            import nibabel as nib
            self._t1 = nib.load(str(self.t1_path)).get_fdata()
            self._student = nib.load(str(self.student_path)).get_fdata()
            self._gold = nib.load(str(self.gold_path)).get_fdata()
        except Exception as e:
            QMessageBox.critical(self, core.APP_NAME, f"Could not load NIfTI files:\n{e}")
            self.close()
            return

        if self._t1 is None or getattr(self._t1, "ndim", 0) < 3:
            QMessageBox.critical(self, core.APP_NAME, "Invalid T1 volume.")
            self.close()
            return

        zmax = int(self._t1.shape[2] - 1)
        self.slider.setMaximum(max(0, zmax))
        self._z = zmax // 2
        self.slider.setValue(self._z)

        self.lbl_info.setText(
            f"T1: {self.t1_path.name}  •  Your mask: {self.student_path.name}  •  Gold: {self.gold_path.name}"
        )
        self._render()

    def _on_slider(self, val: int):
        self._z = int(val)
        self._render()

    def _render(self):
        if self._t1 is None:
            return
        try:
            im_left = _render_slice(self._t1, self._student, self._z, overlay_rgb=(230, 70, 70), alpha=0.35)
            im_right = _render_slice(self._t1, self._gold, self._z, overlay_rgb=(70, 210, 120), alpha=0.35)
            self.left.setPixmap(QPixmap.fromImage(im_left).scaled(self.left.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
            self.right.setPixmap(QPixmap.fromImage(im_right).scaled(self.right.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
        except Exception:
            pass

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._render()
