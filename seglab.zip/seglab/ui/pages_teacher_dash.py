from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Dict, List

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QTableWidget, QTableWidgetItem,
    QHeaderView, QAbstractItemView, QMessageBox
)

import lt_core as core
import lt_share as share
from lt_utils import open_default
from lt_eval import ATTEMPT_FIELDS
from ui.widgets import btn, h2, caption, pill, Card


class TeacherDashboardPage(QWidget):
    def __init__(self, app):
        super().__init__()
        self.app = app
        self._student_dirs: Dict[str, Path] = {}

        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(12)

        top = Card(); tv = QVBoxLayout(top)
        tv.setContentsMargins(18, 16, 18, 16); tv.setSpacing(10)
        tv.addWidget(h2("Teacher dashboard"))
        tv.addWidget(caption("Students are read directly from the share. Each student gets a subfolder under classroom/progress/attempts."))
        pills = QHBoxLayout(); pills.setSpacing(8)
        self.p_students = pill("0 students")
        self.p_attempts = pill("0 attempts")
        self.p_cases = pill("0 cases")
        pills.addWidget(self.p_students)
        pills.addWidget(self.p_attempts)
        pills.addWidget(self.p_cases)
        pills.addStretch(1)
        tv.addLayout(pills)
        v.addWidget(top)

        students = Card(); sv = QVBoxLayout(students)
        sv.setContentsMargins(18, 16, 18, 16); sv.setSpacing(10)
        sv.addWidget(h2("Students"))
        self.tbl_students = QTableWidget(0, 5)
        self.tbl_students.setHorizontalHeaderLabels(["Student", "Attempts", "Cases", "Latest Dice", "Best Dice"])
        self.tbl_students.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tbl_students.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tbl_students.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tbl_students.itemSelectionChanged.connect(self._on_student_selected)
        sv.addWidget(self.tbl_students, 1)
        row = QHBoxLayout(); row.setSpacing(10)
        self.b_open_student = btn("Open selected student folder", "ghost")
        self.b_open_attempts = btn("Open attempts root", "ghost")
        row.addWidget(self.b_open_student)
        row.addWidget(self.b_open_attempts)
        row.addStretch(1)
        sv.addLayout(row)
        v.addWidget(students, 1)

        details = Card(); dv = QVBoxLayout(details)
        dv.setContentsMargins(18, 16, 18, 16); dv.setSpacing(10)
        self.lbl_student = h2("Selected student")
        dv.addWidget(self.lbl_student)
        self.tbl_student_cases = QTableWidget(0, 4)
        self.tbl_student_cases.setHorizontalHeaderLabels(["Case", "Attempts", "Latest Dice", "Best Dice"])
        self.tbl_student_cases.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tbl_student_cases.setEditTriggers(QAbstractItemView.NoEditTriggers)
        dv.addWidget(self.tbl_student_cases, 1)
        v.addWidget(details, 1)

        cohort = Card(); cv = QVBoxLayout(cohort)
        cv.setContentsMargins(18, 16, 18, 16); cv.setSpacing(10)
        cv.addWidget(h2("Classroom summary"))
        self.tbl_cases = QTableWidget(0, 5)
        self.tbl_cases.setHorizontalHeaderLabels(["Case", "Attempts", "Students", "Avg Dice", "Best Dice"])
        self.tbl_cases.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tbl_cases.setEditTriggers(QAbstractItemView.NoEditTriggers)
        cv.addWidget(self.tbl_cases, 1)
        row2 = QHBoxLayout(); row2.setSpacing(10)
        self.b_refresh = btn("Refresh", "primary")
        self.b_export = btn("Export cohort CSV", "ghost")
        row2.addWidget(self.b_refresh)
        row2.addWidget(self.b_export)
        row2.addStretch(1)
        cv.addLayout(row2)
        v.addWidget(cohort, 1)

        self.b_refresh.clicked.connect(self.refresh)
        self.b_export.clicked.connect(self._export)
        self.b_open_attempts.clicked.connect(self._open_attempts_root)
        self.b_open_student.clicked.connect(self._open_selected_student)

    def _attempts_root(self) -> Path | None:
        if not self.app.share_root or not self.app.class_code:
            return None
        return share.attempts_root(self.app.share_root, self.app.class_code)

    def _exports_dir(self) -> Path | None:
        if not self.app.share_root or not self.app.class_code:
            return None
        d = self.app.share_root / "classrooms" / self.app.class_code / "exports"
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _open_attempts_root(self):
        p = self._attempts_root()
        if p and p.exists():
            open_default(p)

    def _open_selected_student(self):
        rows = self.tbl_students.selectionModel().selectedRows() if self.tbl_students.selectionModel() else []
        if not rows:
            return
        item = self.tbl_students.item(rows[0].row(), 0)
        if not item:
            return
        user = str(item.data(256) or item.text() or "")
        p = self._student_dirs.get(user)
        if p:
            open_default(p)

    def _load_attempts(self) -> List[Dict[str, Any]]:
        root = self._attempts_root()
        if not root or not root.exists():
            return []
        attempts: List[Dict[str, Any]] = []
        self._student_dirs = {}
        for user_dir in [p for p in root.iterdir() if p.is_dir()]:
            user = user_dir.name
            self._student_dirs[user] = user_dir
            jsonl = user_dir / "attempts.jsonl"
            if jsonl.exists():
                try:
                    for line in jsonl.read_text(encoding="utf-8", errors="ignore").splitlines():
                        line = line.strip()
                        if not line:
                            continue
                        obj = json.loads(line)
                        if isinstance(obj, dict):
                            attempts.append(obj)
                except Exception:
                    pass
        return attempts

    def _student_attempt_rows(self, user: str) -> List[Dict[str, Any]]:
        return [a for a in self._load_attempts() if str(a.get("user") or "") == user]

    def _on_student_selected(self):
        rows = self.tbl_students.selectionModel().selectedRows() if self.tbl_students.selectionModel() else []
        self.tbl_student_cases.setRowCount(0)
        if not rows:
            self.lbl_student.setText("Selected student")
            return
        item = self.tbl_students.item(rows[0].row(), 0)
        if not item:
            return
        user = str(item.data(256) or item.text() or "")
        self.lbl_student.setText(user)
        by_case: Dict[str, List[Dict[str, Any]]] = {}
        for a in self._student_attempt_rows(user):
            cid = str(a.get("case_id") or "")
            if cid:
                by_case.setdefault(cid, []).append(a)
        for cid, arr in sorted(by_case.items()):
            dices = [float(x.get("dice") or 0.0) for x in arr]
            latest = float((arr[-1] or {}).get("dice") or 0.0) if arr else 0.0
            r = self.tbl_student_cases.rowCount(); self.tbl_student_cases.insertRow(r)
            self.tbl_student_cases.setItem(r, 0, QTableWidgetItem(cid))
            self.tbl_student_cases.setItem(r, 1, QTableWidgetItem(str(len(arr))))
            self.tbl_student_cases.setItem(r, 2, QTableWidgetItem(f"{latest:.3f}"))
            self.tbl_student_cases.setItem(r, 3, QTableWidgetItem(f"{max(dices):.3f}" if dices else "0.000"))

    def _export(self):
        if self.app.mode != "teacher" or not self.app.share_root or not self.app.class_code:
            QMessageBox.information(self, core.APP_NAME, "Login as teacher and open a classroom first.")
            return
        attempts = self._load_attempts()
        if not attempts:
            QMessageBox.information(self, core.APP_NAME, "No attempts found yet.")
            return
        out_dir = self._exports_dir()
        if not out_dir:
            return
        csv_path = out_dir / "cohort_attempts.csv"
        with csv_path.open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=ATTEMPT_FIELDS)
            w.writeheader()
            for a in attempts:
                w.writerow({k: a.get(k, "") for k in ATTEMPT_FIELDS})
        QMessageBox.information(self, core.APP_NAME, f"Exported:\n{csv_path}")
        open_default(out_dir)

    def refresh(self):
        self.tbl_students.setRowCount(0)
        self.tbl_student_cases.setRowCount(0)
        self.tbl_cases.setRowCount(0)
        self.lbl_student.setText("Selected student")
        self.p_students.setText("0 students")
        self.p_attempts.setText("0 attempts")
        self.p_cases.setText("0 cases")

        if self.app.mode != "teacher" or not self.app.share_root or not self.app.class_code:
            return
        attempts = self._load_attempts()
        by_user: Dict[str, List[Dict[str, Any]]] = {}
        by_case: Dict[str, List[Dict[str, Any]]] = {}
        for a in attempts:
            u = str(a.get("user") or "unknown")
            c = str(a.get("case_id") or "")
            by_user.setdefault(u, []).append(a)
            if c:
                by_case.setdefault(c, []).append(a)

        self.p_students.setText(f"{len(self._student_dirs)} students")
        self.p_attempts.setText(f"{len(attempts)} attempts")
        self.p_cases.setText(f"{len(by_case)} cases")

        students = []
        for u, arr in by_user.items():
            dices = [float(x.get("dice") or 0.0) for x in arr]
            latest = arr[-1] if arr else {}
            students.append((u, len(arr), len({str(x.get('case_id') or '') for x in arr if x.get('case_id')}), float(latest.get("dice") or 0.0), max(dices) if dices else 0.0))
        students.sort(key=lambda x: (x[3], x[1]), reverse=True)
        for u, attempts_n, cases_n, latest_d, best_d in students:
            r = self.tbl_students.rowCount(); self.tbl_students.insertRow(r)
            it = QTableWidgetItem(u)
            it.setData(256, u)
            self.tbl_students.setItem(r, 0, it)
            self.tbl_students.setItem(r, 1, QTableWidgetItem(str(attempts_n)))
            self.tbl_students.setItem(r, 2, QTableWidgetItem(str(cases_n)))
            self.tbl_students.setItem(r, 3, QTableWidgetItem(f"{latest_d:.3f}"))
            self.tbl_students.setItem(r, 4, QTableWidgetItem(f"{best_d:.3f}"))
        if self.tbl_students.rowCount() > 0:
            self.tbl_students.selectRow(0)
            self._on_student_selected()

        cases = []
        for c, arr in by_case.items():
            dices = [float(x.get("dice") or 0.0) for x in arr]
            cases.append((c, len(arr), len({str(x.get('user') or '') for x in arr if x.get('user')}), (sum(dices) / len(dices)) if dices else 0.0, max(dices) if dices else 0.0))
        cases.sort(key=lambda x: (x[3], x[1]), reverse=True)
        for c, attempts_n, students_n, avg_d, best_d in cases:
            r = self.tbl_cases.rowCount(); self.tbl_cases.insertRow(r)
            self.tbl_cases.setItem(r, 0, QTableWidgetItem(c))
            self.tbl_cases.setItem(r, 1, QTableWidgetItem(str(attempts_n)))
            self.tbl_cases.setItem(r, 2, QTableWidgetItem(str(students_n)))
            self.tbl_cases.setItem(r, 3, QTableWidgetItem(f"{avg_d:.3f}"))
            self.tbl_cases.setItem(r, 4, QTableWidgetItem(f"{best_d:.3f}"))
