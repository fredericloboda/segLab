from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel

from ui.widgets import Card


class Tile(Card):
    """Clickable card tile used across the app.

    Design primitive to avoid "Qt demo" look:
    - consistent spacing
    - large title + short subtitle
    - optional badge
    - selected state via dynamic property (selected=true)
    """

    clicked = Signal()

    def __init__(
        self,
        title: str,
        subtitle: str = "",
        badge: str = "",
        icon: str = "",
        min_h: int = 72,
    ):
        super().__init__()
        self.setObjectName("Tile")
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(min_h)

        v = QVBoxLayout(self)
        v.setContentsMargins(14, 10, 14, 10)
        v.setSpacing(4)

        top = QHBoxLayout()
        top.setSpacing(10)
        v.addLayout(top)

        self.lbl_icon = QLabel(icon or "")
        self.lbl_icon.setObjectName("TileIcon")
        self.lbl_icon.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.lbl_icon.setVisible(bool(icon))
        top.addWidget(self.lbl_icon, 0)

        self.lbl_title = QLabel(title)
        self.lbl_title.setObjectName("TileTitle")
        f = QFont(self.lbl_title.font())
        f.setWeight(QFont.DemiBold)
        self.lbl_title.setFont(f)
        top.addWidget(self.lbl_title, 1)

        self.lbl_badge = QLabel(badge or "")
        self.lbl_badge.setObjectName("TileBadge")
        self.lbl_badge.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.lbl_badge.setVisible(bool(badge))
        top.addWidget(self.lbl_badge, 0)

        self.lbl_sub = QLabel(subtitle)
        self.lbl_sub.setObjectName("TileSub")
        self.lbl_sub.setWordWrap(True)
        self.lbl_sub.setVisible(bool(subtitle))
        v.addWidget(self.lbl_sub)

        self.set_selected(False)

    def set_selected(self, on: bool) -> None:
        self.setProperty("selected", bool(on))
        self.style().unpolish(self)
        self.style().polish(self)
        self.update()

    def set_badge(self, text: str) -> None:
        self.lbl_badge.setText(text or "")
        self.lbl_badge.setVisible(bool(text))

    def mousePressEvent(self, ev):
        if ev.button() == Qt.LeftButton:
            self.clicked.emit()
        return super().mousePressEvent(ev)
