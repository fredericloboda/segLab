from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Tuple

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QPainter, QPen, QFont
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QListWidget, QListWidgetItem, QMessageBox,
    QTableWidget, QTableWidgetItem, QHeaderView, QScrollArea, QBoxLayout, QSizePolicy
)

import lt_core as core
from lt_utils import open_default
from lt_attempts import load_attempts, summaries_by_case, overall_summary, attempts_for_case, export_rows_csv
from lt_case import list_cases
from modules import cases_builtin
from ui.widgets import btn, h1, h2, caption, Card, pill


def _safe_float(x, default=0.0) -> float:
    try:
        return float(x)
    except Exception:
        return float(default)


class TinyLinePlot(QWidget):
    def __init__(self):
        super().__init__()
        self._values: List[float] = []
        self.setMinimumHeight(150)

    def set_series(self, values: List[float]):
        self._values = [float(v) for v in (values or [])]
        self.update()

    def paintEvent(self, _ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        plot = self.rect().adjusted(16, 12, -16, -16)

        if not self._values:
            p.setPen(QPen(QColor(160, 160, 160, 170)))
            p.setFont(QFont(p.font().family(), 11))
            p.drawText(plot, Qt.AlignCenter, "No attempts yet")
            return

        vmin = min(self._values)
        vmax = max(self._values)
        if abs(vmax - vmin) < 1e-9:
            vmin = max(0.0, vmin - 0.1)
            vmax = min(1.0, vmax + 0.1)
            if abs(vmax - vmin) < 1e-9:
                vmax = vmin + 1.0

        def xy(i: int, v: float) -> Tuple[float, float]:
            if len(self._values) == 1:
                x = plot.center().x()
            else:
                x = plot.left() + plot.width() * (i / max(1, len(self._values) - 1))
            y = plot.bottom() - plot.height() * ((v - vmin) / (vmax - vmin))
            return x, y

        p.setPen(QPen(QColor(255, 255, 255, 10), 1))
        for k in range(1, 4):
            y = plot.top() + (plot.height() * k / 4.0)
            p.drawLine(plot.left(), int(y), plot.right(), int(y))

        if len(self._values) >= 2:
            p.setPen(QPen(QColor(core.ACCENT), 2))
            last = None
            for i, v in enumerate(self._values):
                x, y = xy(i, v)
                if last is not None:
                    p.drawLine(int(last[0]), int(last[1]), int(x), int(y))
                last = (x, y)

        p.setPen(QPen(QColor(255, 255, 255, 170), 1))
        p.setBrush(QColor(core.ACCENT))
        for i, v in enumerate(self._values):
            x, y = xy(i, v)
            p.drawEllipse(int(x) - 4, int(y) - 4, 8, 8)

        if len(self._values) == 1:
            p.setPen(QPen(QColor(220, 220, 220, 220), 1))
            p.setFont(QFont(p.font().family(), 10))
            p.drawText(plot.adjusted(0, 8, 0, 0), Qt.AlignTop | Qt.AlignHCenter, f"Attempt 1 • Dice {self._values[0]:.3f}")


class ProgressPage(QWidget):
    def __init__(self, app):
        super().__init__()
        self.app = app
        self._attempts: List[Dict[str, Any]] = []
        self._summaries: List[Dict[str, Any]] = []
        self._selected_case_uid: str = ""
        self._attempt_view_mode: str = "case"

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self._scroll = QScrollArea()
        self._scroll.setWidgetResizable(True)
        self._scroll.setFrameShape(QScrollArea.NoFrame)
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        root.addWidget(self._scroll)

        host = QWidget()
        self._scroll.setWidget(host)

        v = QVBoxLayout(host)
        v.setContentsMargins(32, 26, 32, 26)
        v.setSpacing(14)

        v.addWidget(h1("Progress"))
        v.addWidget(caption("Per-case improvement, overall improvement, and exportable evidence of training."))

        pills = QHBoxLayout(); pills.setSpacing(8)
        self.p_attempted = pill("0 attempted")
        self.p_total = pill("0 attempts")
        self.p_latest = pill("Mean latest —")
        self.p_best = pill("Mean best —")
        self.p_delta = pill("Mean Δ —")
        self.p_completion = pill("Completion —")
        for w in [self.p_attempted, self.p_total, self.p_latest, self.p_best, self.p_delta, self.p_completion]:
            pills.addWidget(w)
        pills.addStretch(1)
        v.addLayout(pills)

        self.plots = QBoxLayout(QBoxLayout.LeftToRight); self.plots.setSpacing(14)
        c1 = Card(); c1v = QVBoxLayout(c1)
        c1v.setContentsMargins(16, 14, 16, 14); c1v.setSpacing(10)
        c1v.addWidget(h2("Overall"))
        self.plot_overall = TinyLinePlot(); c1v.addWidget(self.plot_overall)
        c1.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self.plots.addWidget(c1, 1)

        c2 = Card(); c2v = QVBoxLayout(c2)
        c2v.setContentsMargins(16, 14, 16, 14); c2v.setSpacing(10)
        self.lbl_case_plot = h2("Selected case")
        c2v.addWidget(self.lbl_case_plot)
        self.plot_case = TinyLinePlot(); c2v.addWidget(self.plot_case)
        c2.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self.plots.addWidget(c2, 1)
        v.addLayout(self.plots)

        self.bottom = QBoxLayout(QBoxLayout.LeftToRight); self.bottom.setSpacing(14)
        v.addLayout(self.bottom)

        left = Card(); lv = QVBoxLayout(left)
        lv.setContentsMargins(16, 14, 16, 14); lv.setSpacing(10)
        lv.addWidget(h2("Cases"))
        self.table_cases = QTableWidget(0, 8)
        self.table_cases.setHorizontalHeaderLabels([
            "Case", "Attempts", "First", "Latest", "Best", "Δ", "Source", "Last time"
        ])
        self.table_cases.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table_cases.verticalHeader().setVisible(False)
        self.table_cases.setSelectionBehavior(QTableWidget.SelectRows)
        self.table_cases.setSelectionMode(QTableWidget.SingleSelection)
        self.table_cases.itemSelectionChanged.connect(self._on_case_selected)
        self.table_cases.setMinimumHeight(220)
        lv.addWidget(self.table_cases)

        cbtn = QHBoxLayout(); cbtn.setSpacing(10)
        self.btn_export_summary = btn("Export summary CSV", "ghost")
        self.btn_open_folder = btn("Open attempts folder", "ghost")
        self.btn_refresh = btn("Refresh", "ghost")
        cbtn.addWidget(self.btn_export_summary)
        cbtn.addWidget(self.btn_open_folder)
        cbtn.addWidget(self.btn_refresh)
        cbtn.addStretch(1)
        lv.addLayout(cbtn)
        left.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self.bottom.addWidget(left, 2)

        right = Card(); rv = QVBoxLayout(right)
        rv.setContentsMargins(16, 14, 16, 14); rv.setSpacing(10)
        rv.addWidget(h2("Attempt history"))

        mode_row = QHBoxLayout(); mode_row.setSpacing(8)
        self.btn_case_attempts = btn("Selected case", "ghost")
        self.btn_all_attempts = btn("All attempts", "ghost")
        mode_row.addWidget(self.btn_case_attempts)
        mode_row.addWidget(self.btn_all_attempts)
        mode_row.addStretch(1)
        rv.addLayout(mode_row)

        self.list_attempts = QListWidget()
        self.list_attempts.itemDoubleClicked.connect(self._open_attempt_json)
        self.list_attempts.setMinimumHeight(220)
        rv.addWidget(self.list_attempts)
        self.lbl_focus = caption("Select a case to inspect its attempt history and improvement curve.")
        rv.addWidget(self.lbl_focus)
        right.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self.bottom.addWidget(right, 1)

        self.btn_open_folder.clicked.connect(self._open_attempts_folder)
        self.btn_refresh.clicked.connect(self.refresh)
        self.btn_export_summary.clicked.connect(self._export_summary)
        self.btn_case_attempts.clicked.connect(lambda: self._set_attempt_view_mode("case"))
        self.btn_all_attempts.clicked.connect(lambda: self._set_attempt_view_mode("all"))
        self._sync_attempt_mode_buttons()
        self._apply_responsive_layout()

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        try:
            self._apply_responsive_layout()
        except Exception:
            pass

    def _layout_width(self) -> int:
        try:
            return int(self._scroll.viewport().width())
        except Exception:
            return int(self.width())

    def _apply_responsive_layout(self):
        w = self._layout_width()
        narrow = w < 1180
        try:
            self.plots.setDirection(QBoxLayout.TopToBottom if narrow else QBoxLayout.LeftToRight)
            self.bottom.setDirection(QBoxLayout.TopToBottom if narrow else QBoxLayout.LeftToRight)
        except Exception:
            pass

    def _attempts_dir(self) -> Path:
        try:
            return Path(self.app.attempts_dir())
        except Exception:
            uname = getattr(self.app, "username", None) or "student"
            return core.LOCAL_PROGRESS / uname

    def _available_case_keys(self) -> List[str]:
        vals: List[str] = []
        for d in cases_builtin.list_cases():
            cid = str(d.get("case_id") or "").strip()
            if cid:
                vals.append(f"bundled:{cid}")
        for c in list_cases():
            cc = ""
            try:
                parts = list(c.case_dir.parts)
                if "classrooms" in parts:
                    idx = parts.index("classrooms")
                    cc = str(parts[idx + 1])
            except Exception:
                cc = ""
            if cc:
                vals.append(f"classroom:{cc}:{c.case_id}")
            else:
                vals.append(f"local:{c.case_id}")
        return sorted(set(vals))

    def _case_series(self, case_uid: str) -> List[float]:
        items = attempts_for_case(self._attempts, case_uid)
        return [_safe_float(a.get("dice", 0.0)) for a in items]

    def refresh(self):
        self._attempts = load_attempts(self._attempts_dir())
        self._summaries = summaries_by_case(self._attempts)

        overall = [_safe_float(a.get("dice", 0.0)) for a in self._attempts]
        self.plot_overall.set_series(overall)

        ov = overall_summary(self._attempts, available_case_ids=self._available_case_keys())
        self.p_attempted.setText(f"{int(ov.get('attempted_cases', 0))} attempted")
        self.p_total.setText(f"{int(ov.get('total_attempts', 0))} attempts")
        self.p_latest.setText(f"Mean latest {_fmt_float(ov.get('mean_latest_dice'))}")
        self.p_best.setText(f"Mean best {_fmt_float(ov.get('mean_best_dice'))}")
        self.p_delta.setText(f"Mean Δ {_fmt_delta(ov.get('mean_delta_dice'))}")
        self.p_completion.setText(f"Completion {100.0 * float(ov.get('completion_rate', 0.0)):.0f}%")

        self.table_cases.setRowCount(0)
        for s in self._summaries:
            row = self.table_cases.rowCount()
            self.table_cases.insertRow(row)
            vals = [
                str(s.get("case_id") or ""),
                str(s.get("attempts") or 0),
                _fmt_float(s.get("first_dice")),
                _fmt_float(s.get("latest_dice")),
                _fmt_float(s.get("best_dice")),
                _fmt_delta(s.get("delta_dice")),
                _source_from_uid(str(s.get("case_uid") or "")),
                str(s.get("last_timestamp") or ""),
            ]
            for col, val in enumerate(vals):
                item = QTableWidgetItem(val)
                if col == 0:
                    item.setData(Qt.UserRole, str(s.get("case_uid") or s.get("case_id") or ""))
                self.table_cases.setItem(row, col, item)

        if self.table_cases.rowCount() > 0:
            selected = False
            for r in range(self.table_cases.rowCount()):
                uid = str(self.table_cases.item(r, 0).data(Qt.UserRole) or "")
                if uid == self._selected_case_uid and uid:
                    self.table_cases.selectRow(r)
                    selected = True
                    break
            if not selected:
                self.table_cases.selectRow(0)
                self._on_case_selected()
            else:
                self._refresh_attempt_list()
        else:
            self._selected_case_uid = ""
            self.plot_case.set_series([])
            self.lbl_case_plot.setText("Selected case")
            self.lbl_focus.setText("No attempts yet.")
            self._refresh_attempt_list()

    def _set_attempt_view_mode(self, mode: str):
        self._attempt_view_mode = "case" if mode == "case" else "all"
        self._sync_attempt_mode_buttons()
        self._apply_responsive_layout()
        self._refresh_attempt_list()

    def _sync_attempt_mode_buttons(self):
        active = f"background: {core.ACCENT}; color: #001018; font-weight: 700;"
        inactive = ""
        self.btn_case_attempts.setStyleSheet(active if self._attempt_view_mode == "case" else inactive)
        self.btn_all_attempts.setStyleSheet(active if self._attempt_view_mode == "all" else inactive)

    def _refresh_attempt_list(self):
        self.list_attempts.clear()
        if self._attempt_view_mode == "case" and self._selected_case_uid:
            rows = attempts_for_case(self._attempts, self._selected_case_uid)
        else:
            rows = list(self._attempts)

        for a in reversed(rows[-400:]):
            cid = str(a.get("case_id") or "unknown")
            ts = str(a.get("timestamp") or "")
            dice = _safe_float(a.get("dice", 0.0))
            attempt_no = str(a.get("attempt_no") or "")
            txt = f"{ts}   {cid}   attempt {attempt_no}   Dice {dice:.3f}"
            it = QListWidgetItem(txt)
            it.setData(Qt.UserRole, a)
            self.list_attempts.addItem(it)

    def _on_case_selected(self):
        rows = self.table_cases.selectionModel().selectedRows() if self.table_cases.selectionModel() else []
        if not rows:
            self.plot_case.set_series([])
            self.lbl_case_plot.setText("Selected case")
            self.lbl_focus.setText("Select a case to inspect its attempt history and improvement curve.")
            self._refresh_attempt_list()
            return
        row = rows[0].row()
        item = self.table_cases.item(row, 0)
        uid = str(item.data(Qt.UserRole) or "") if item else ""
        self._selected_case_uid = uid
        case_name = str(item.text() or "Selected case") if item else "Selected case"
        self.lbl_case_plot.setText(case_name)
        series = self._case_series(uid)
        self.plot_case.set_series(series)
        att = attempts_for_case(self._attempts, uid)
        if att:
            last = att[-1]
            self.lbl_focus.setText(
                f"Latest Dice {_fmt_float(last.get('dice'))}  •  "
                f"IoU {_fmt_float(last.get('jaccard'))}  •  "
                f"Precision {_fmt_float(last.get('precision'))}  •  "
                f"Recall {_fmt_float(last.get('recall'))}"
            )
        else:
            self.lbl_focus.setText("No attempts yet.")
        self._refresh_attempt_list()

    def _open_attempts_folder(self):
        open_default(self._attempts_dir())

    def _open_attempt_json(self, it: QListWidgetItem):
        a = it.data(Qt.UserRole)
        if not isinstance(a, dict):
            return
        try:
            text = json.dumps(a, indent=2)
        except Exception:
            text = str(a)
        QMessageBox.information(self, core.APP_NAME, text)

    def _export_summary(self):
        out = core.EXPORTS_DIR / "progress_summary" / "case_summary.csv"
        export_rows_csv(out, self._summaries)
        QMessageBox.information(self, core.APP_NAME, f"Exported:\n{out}")


def _fmt_float(x: Any, nd: int = 3) -> str:
    try:
        return f"{float(x):.{nd}f}"
    except Exception:
        return "—"


def _fmt_delta(x: Any, nd: int = 3) -> str:
    try:
        v = float(x)
        return f"{v:+.{nd}f}"
    except Exception:
        return "—"


def _source_from_uid(uid: str) -> str:
    if uid.startswith("bundled:"):
        return "BUILT-IN"
    if uid.startswith("classroom:"):
        parts = uid.split(":")
        return f"CLASS {parts[1]}" if len(parts) >= 3 else "CLASS"
    if uid.startswith("local:"):
        return "LOCAL"
    return "—"
