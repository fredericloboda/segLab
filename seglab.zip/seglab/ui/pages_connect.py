from __future__ import annotations

from pathlib import Path

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, QFileDialog, QMessageBox
)

import lt_core as core
from lt_utils import norm_code
from ui.widgets import btn, h1, h2, caption, Card


class ConnectPage(QWidget):
    """Student join (Option A): share path + class code."""

    def __init__(self, app):
        super().__init__()
        self.app = app

        v = QVBoxLayout(self)
        v.setContentsMargins(32, 26, 32, 26)
        v.setSpacing(12)

        v.addWidget(h1("Join classroom"))
        v.addWidget(caption("SMB mode (Option A). Mount the share in your OS, then enter share path + class code."))

        c = Card(); cv = QVBoxLayout(c); cv.setContentsMargins(18, 16, 18, 16); cv.setSpacing(12)

        cv.addWidget(h2("Connection"))

        r1 = QHBoxLayout(); r1.setSpacing(10)
        self.ed_share = QLineEdit()
        self.ed_share.setPlaceholderText("Mounted share path (e.g. /Volumes/Share/SegLab or X:\\SegLab)")
        self.ed_share.setText(str(core.cfg_get("share_root", "") or ""))
        b_browse = btn("Browse…", "ghost")
        r1.addWidget(self.ed_share, 1)
        r1.addWidget(b_browse, 0)
        cv.addLayout(r1)

        self.ed_code = QLineEdit()
        self.ed_code.setPlaceholderText("Class code")
        self.ed_code.setText(str(core.cfg_get("class_code", "") or ""))
        cv.addWidget(self.ed_code)

        self.ed_name = QLineEdit()
        self.ed_name.setPlaceholderText("Your name")
        self.ed_name.setText(str(core.cfg_get("username", "student") or "student"))
        cv.addWidget(self.ed_name)

        act = QHBoxLayout(); act.setSpacing(12)
        self.b_join = btn("Join", "primary")
        self.b_offline = btn("Continue offline", "ghost")
        act.addWidget(self.b_join)
        act.addWidget(self.b_offline)
        act.addStretch(1)
        cv.addLayout(act)

        v.addWidget(c)
        v.addStretch(1)

        b_browse.clicked.connect(self._browse)
        self.b_offline.clicked.connect(self.app.enter_solo)
        self.b_join.clicked.connect(self._join)

    def _browse(self):
        start = Path("/Volumes") if Path("/Volumes").exists() else Path.home()
        p = QFileDialog.getExistingDirectory(self, "Select mounted share folder", str(start))
        if p:
            self.ed_share.setText(p)

    def _join(self):
        sp = self.ed_share.text().strip()
        code = norm_code(self.ed_code.text().strip())
        uname = (self.ed_name.text().strip() or "student")
        if not sp:
            QMessageBox.critical(self, core.APP_NAME, "Share path is empty.")
            return
        if not code:
            QMessageBox.critical(self, core.APP_NAME, "Classroom code is empty/invalid.")
            return
        self.app.join_classroom(sp, code, uname)

    def refresh(self):
        pass
