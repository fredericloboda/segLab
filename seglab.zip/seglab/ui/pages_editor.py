from __future__ import annotations

from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QMessageBox

import lt_core as core
from ui.widgets import btn, h1, caption, Card, h2
from modules import editor_internal


class EditorPage(QWidget):
    """Internal editor entrypoint (future).

    IMPORTANT: This page must NOT launch ITK-SNAP or manage files.
    ITK-SNAP is launched only from Practice when opening a case.
    """

    def __init__(self, app):
        super().__init__()
        self.app = app

        v = QVBoxLayout(self)
        v.setContentsMargins(32, 26, 32, 26)
        v.setSpacing(12)

        v.addWidget(h1("Editor"))

        c = Card(); cv = QVBoxLayout(c)
        cv.setContentsMargins(18, 16, 18, 16)
        cv.setSpacing(10)
        cv.addWidget(h2("Internal editor (planned)"))
        cv.addWidget(caption(
            "This entry is reserved for your internal ITK‑SNAP‑like editor.\n"
            "Until it exists, cases are segmented via ITK‑SNAP launched from Practice."
        ))
        row = QHBoxLayout(); row.setSpacing(10)
        self.b_open = btn("Open", "primary")
        row.addWidget(self.b_open)
        row.addStretch(1)
        cv.addLayout(row)
        v.addWidget(c)
        v.addStretch(1)

        self.b_open.clicked.connect(self._open)
        self.refresh()

    def refresh(self):
        self.b_open.setEnabled(bool(editor_internal.available()))

    def _open(self):
        if not editor_internal.available():
            QMessageBox.information(self, core.APP_NAME, "Internal editor not available yet.")
            return
        try:
            editor_internal.launch()
        except AttributeError:
            # If you implement open/launch later, use that.
            QMessageBox.information(self, core.APP_NAME, "Internal editor integration is not wired yet.")
        except Exception as e:
            QMessageBox.critical(self, core.APP_NAME, f"Could not open internal editor: {e}")
