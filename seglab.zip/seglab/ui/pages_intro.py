from __future__ import annotations

from pathlib import Path
from typing import List

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QGridLayout, QScrollArea, QLabel
)

import lt_core as core
from lt_utils import open_default
from ui.widgets import h1, section_title, caption
from ui.deck_icon import DeckIconButton


ALLOWED = {".pdf", ".ppt", ".pptx"}


def _scan_dir(d: Path) -> List[Path]:
    if not d.exists():
        return []
    items = [p for p in d.rglob("*") if p.is_file() and p.suffix.lower() in ALLOWED]
    items.sort(key=lambda x: x.name.lower())
    return items


def _pretty_name(p: Path) -> str:
    # keep it clean: filename without extension, title-cased separators
    name = p.stem.replace("_", " ").replace("-", " ").strip()
    return name if name else p.name


class _IconGrid(QWidget):
    """A simple grid of numbered deck icons (no boxed cards)."""

    def __init__(self, cols: int = 8):
        super().__init__()
        self._cols = int(cols)
        self.grid = QGridLayout(self)
        self.grid.setContentsMargins(0, 0, 0, 0)
        self.grid.setHorizontalSpacing(12)
        self.grid.setVerticalSpacing(12)

    def set_files(self, files: List[Path]):
        while self.grid.count():
            it = self.grid.takeAt(0)
            w = it.widget()
            if w is not None:
                w.setParent(None)

        if not files:
            msg = QLabel("(no files found)")
            msg.setObjectName("Muted")
            msg.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
            self.grid.addWidget(msg, 0, 0)
            return

        cols = max(3, self._cols)
        for i, p in enumerate(files, start=1):
            b = DeckIconButton(i, p)
            b.open_path.connect(lambda fp, _=None: open_default(fp))
            self.grid.addWidget(b, (i - 1) // cols, (i - 1) % cols)


class IntroductionPage(QWidget):
    """Introduction to lesion segmentation

    Design goal: *launcher* feel.
    - presentations appear as numbered icon tiles
    - adding files later to resources/intro or resources/anatomy auto-populates
    - no "add material" (content is curated by you, not by students)
    """

    def __init__(self, app):
        super().__init__()
        self.app = app

        outer = QVBoxLayout(self)
        outer.setContentsMargins(32, 26, 32, 26)
        outer.setSpacing(10)

        outer.addWidget(h1("Introduction to lesion segmentation"))
        outer.addWidget(caption("Quickstart + anatomy. Add PPTX/PDF into the bundled folders → icons appear automatically."))

        # Scroll area (scrollbars hidden globally via QSS)
        sc = QScrollArea()
        sc.setWidgetResizable(True)
        sc.setFrameShape(QScrollArea.NoFrame)
        sc.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        sc.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        self._inner = QWidget()
        self._v = QVBoxLayout(self._inner)
        self._v.setContentsMargins(0, 0, 0, 0)
        self._v.setSpacing(12)

        self._v.addWidget(section_title("Quickstart"))
        self.grid_intro = _IconGrid(cols=10)
        self._v.addWidget(self.grid_intro)

        self._v.addSpacing(10)

        self._v.addWidget(section_title("Anatomy"))
        self.grid_anat = _IconGrid(cols=10)
        self._v.addWidget(self.grid_anat)

        self._v.addSpacing(10)

        self._v.addWidget(section_title("Local library"))
        self.grid_local = _IconGrid(cols=10)
        self._v.addWidget(self.grid_local)
        self._v.addWidget(caption("Drop PPTX/PDF into your user folder to add your own decks (persist across updates)."))

        self._v.addSpacing(10)

        self._v.addWidget(section_title("Classroom library"))
        self.grid_classroom = _IconGrid(cols=10)
        self._v.addWidget(self.grid_classroom)
        self._v.addWidget(caption("Materials synced from the teacher classroom share."))

        self._v.addStretch(1)

        sc.setWidget(self._inner)
        outer.addWidget(sc, 1)

        # (No "add material" in-app. Content is curated and shipped with the app.)

        self.refresh()

    def refresh(self):
        core.ensure_dirs()
        self.grid_intro.set_files(_scan_dir(core.INTRO_DIR))
        self.grid_anat.set_files(_scan_dir(core.ANATOMY_DIR))

        # Local/user library
        self.grid_local.set_files(_scan_dir(core.LOCAL_MATERIALS))

        # Classroom library (synced into workspace)
        class_code = getattr(self.app, 'class_code', '') or ''
        if getattr(self.app, 'mode', '') == 'student' and class_code:
            try:
                from lt_paths import workspace_class_materials_dir
                self.grid_classroom.set_files(_scan_dir(workspace_class_materials_dir(class_code)))
            except Exception:
                self.grid_classroom.set_files([])
        else:
            self.grid_classroom.set_files([])
