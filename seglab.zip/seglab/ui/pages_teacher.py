from __future__ import annotations

import json
import os
import shutil
import uuid
from pathlib import Path

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QFileDialog, QMessageBox, QInputDialog
)

import lt_core as core
import lt_share as share
import content_packs
from lt_utils import norm_code, now_ts, open_default
from lt_eval import validate_pair
from ui.widgets import btn, h1, h2, caption, muted, Card
from ui.pages_teacher_dash import TeacherDashboardPage


class TeacherPage(QWidget):
    """Simple teacher flow."""

    def __init__(self, app):
        super().__init__()
        self.app = app
        self._authed = False
        self._pack_cases_root: Path | None = None
        self._pack_materials_root: Path | None = None

        v = QVBoxLayout(self)
        v.setContentsMargins(32, 26, 32, 26)
        v.setSpacing(12)

        v.addWidget(h1("Teacher"))
        v.addWidget(caption("Create/import a local training package, or use the classroom tools below if needed."))

        c_share = Card(); sh = QVBoxLayout(c_share)
        sh.setContentsMargins(18, 16, 18, 16); sh.setSpacing(10)
        sh.addWidget(h2("Share folder"))
        self.ed_share = QLineEdit()
        self.ed_share.setPlaceholderText(r"Folder (e.g. X:\LTTrainer or C:\Temp\FakeShare\LTTrainer)")
        self.ed_share.setText(str(core.cfg_get("share_root", "") or ""))
        sh.addWidget(self.ed_share)
        r = QHBoxLayout(); r.setSpacing(10)
        self.b_browse = btn("Find folder…", "ghost")
        self.b_open_share = btn("Open folder", "ghost")
        r.addWidget(self.b_browse)
        r.addWidget(self.b_open_share)
        r.addStretch(1)
        sh.addLayout(r)
        self.lbl_share = caption("")
        sh.addWidget(self.lbl_share)
        v.addWidget(c_share)

        c_auth = Card(); au = QVBoxLayout(c_auth)
        au.setContentsMargins(18, 16, 18, 16); au.setSpacing(10)
        au.addWidget(h2("Teacher access"))
        self.ed_pin = QLineEdit()
        self.ed_pin.setPlaceholderText("Teacher PIN")
        self.ed_pin.setEchoMode(QLineEdit.Password)
        au.addWidget(self.ed_pin)
        ar = QHBoxLayout(); ar.setSpacing(10)
        self.b_setpin = btn("Set / change PIN", "primary")
        self.b_login = btn("Login", "ghost")
        ar.addWidget(self.b_setpin)
        ar.addWidget(self.b_login)
        ar.addStretch(1)
        au.addLayout(ar)
        self.info = caption("Choose the share folder first.")
        au.addWidget(self.info)
        v.addWidget(c_auth)

        self.card_pack = Card(); pk = QVBoxLayout(self.card_pack)
        pk.setContentsMargins(18, 16, 18, 16); pk.setSpacing(10)
        pk.addWidget(h2("Content pack"))
        pk.addWidget(muted("Pick a cases folder, optionally pick a materials folder, then create one .seglabpack file for students."))
        prow1 = QHBoxLayout(); prow1.setSpacing(10)
        self.b_pack_cases = btn("Add cases…", "primary")
        self.b_pack_materials = btn("Add materials…", "ghost")
        self.b_open_builtin = btn("Open built-in cases", "ghost")
        prow1.addWidget(self.b_pack_cases)
        prow1.addWidget(self.b_pack_materials)
        prow1.addWidget(self.b_open_builtin)
        prow1.addStretch(1)
        pk.addLayout(prow1)
        self.lbl_pack_cases = caption("Cases: none selected")
        self.lbl_pack_materials = caption("Materials: none selected")
        pk.addWidget(self.lbl_pack_cases)
        pk.addWidget(self.lbl_pack_materials)
        prow2 = QHBoxLayout(); prow2.setSpacing(10)
        self.b_preview_pack = btn("Preview package", "ghost")
        self.b_make_pack = btn("Create package", "primary")
        self.b_import_pack = btn("Import pack", "ghost")
        prow2.addWidget(self.b_preview_pack)
        prow2.addWidget(self.b_make_pack)
        prow2.addWidget(self.b_import_pack)
        prow2.addStretch(1)
        pk.addLayout(prow2)
        self.lbl_pack = caption("Case folders must contain t1.nii.gz, gold.nii.gz, and optionally case.json. Materials can be any files or folders.")
        pk.addWidget(self.lbl_pack)
        v.addWidget(self.card_pack)

        self.card_class = Card(); cl = QVBoxLayout(self.card_class)
        cl.setContentsMargins(18, 16, 18, 16); cl.setSpacing(10)
        cl.addWidget(h2("Classroom"))
        cl.addWidget(muted("Create the classroom once; its folder is then ready for unlimited case folders."))
        row = QHBoxLayout(); row.setSpacing(10)
        self.ed_code = QLineEdit()
        self.ed_code.setPlaceholderText("Classroom code (e.g. HUMMEL_BLS_2026)")
        self.ed_code.setText(str(core.cfg_get("class_code", "") or ""))
        self.b_open_class = btn("Create / open classroom", "primary")
        row.addWidget(self.ed_code, 1)
        row.addWidget(self.b_open_class)
        cl.addLayout(row)

        row2 = QHBoxLayout(); row2.setSpacing(10)
        self.b_policy = btn("Set policy", "ghost")
        self.b_import_cases = btn("Import case folder", "primary")
        self.b_add_case = btn("Add single case", "ghost")
        self.b_open_classroom = btn("Open classroom folder", "ghost")
        self.b_open_cases = btn("Open cases folder", "ghost")
        self.b_open_students = btn("Open student progress", "ghost")
        row2.addWidget(self.b_policy)
        row2.addWidget(self.b_import_cases)
        row2.addWidget(self.b_add_case)
        row2.addWidget(self.b_open_classroom)
        row2.addWidget(self.b_open_cases)
        row2.addWidget(self.b_open_students)
        row2.addStretch(1)
        cl.addLayout(row2)
        self.lbl_class = caption("No classroom selected.")
        cl.addWidget(self.lbl_class)
        self.lbl_layout = caption("Students enter the share root; the app resolves the classroom from the class code. Expected layout: classrooms/<CLASS_CODE>/cases/<CASE_ID>/t1.nii.gz + gold.nii.gz + case.json")
        cl.addWidget(self.lbl_layout)
        v.addWidget(self.card_class)

        self.dash = TeacherDashboardPage(app)
        v.addWidget(self.dash, 1)

        self.b_browse.clicked.connect(self._browse)
        self.b_open_share.clicked.connect(self._open_share)
        self.b_setpin.clicked.connect(self._set_pin)
        self.b_login.clicked.connect(self._login)
        self.b_open_class.clicked.connect(self._apply_class)
        self.b_policy.clicked.connect(self._policy)
        self.b_import_cases.clicked.connect(self._import_case_folder)
        self.b_add_case.clicked.connect(self._upload_case)
        self.b_open_classroom.clicked.connect(self._open_classroom_folder)
        self.b_open_cases.clicked.connect(self._open_cases_folder)
        self.b_open_students.clicked.connect(self._open_students_folder)
        self.b_open_builtin.clicked.connect(self._open_builtin_cases_folder)
        self.b_pack_cases.clicked.connect(self._select_pack_cases)
        self.b_pack_materials.clicked.connect(self._select_pack_materials)
        self.b_preview_pack.clicked.connect(self._preview_content_pack)
        self.b_make_pack.clicked.connect(self._create_content_pack)
        self.b_import_pack.clicked.connect(self._import_content_pack)

        self.refresh()

    def _set_button_kind(self, button, kind: str):
        button.setObjectName({"primary": "BtnPrimary", "ghost": "BtnGhost", "danger": "BtnDanger"}.get(kind, "BtnGhost"))
        button.style().unpolish(button)
        button.style().polish(button)
        button.update()

    def _browse(self):
        start = Path("/Volumes") if Path("/Volumes").exists() else Path.home()
        p = QFileDialog.getExistingDirectory(self, "Select share folder", str(start))
        if p:
            self.ed_share.setText(p)
            self.refresh()

    def _root(self, must_exist: bool = True):
        sp = self.ed_share.text().strip()
        if not sp:
            if must_exist:
                QMessageBox.critical(self, core.APP_NAME, "Share path is empty.")
            return None
        p = Path(sp).expanduser()
        if must_exist and not p.exists():
            QMessageBox.critical(self, core.APP_NAME, f"Share path does not exist:\n{p}")
            return None
        root = share.resolve_share_root(p)
        core.cfg_set("share_root", str(root))
        return root

    def _share_has_pin(self) -> bool:
        root = self._root(must_exist=False)
        return bool(root and share.pin_is_set(root))

    def _open_share(self):
        root = self._root(must_exist=False)
        if root:
            open_default(root)

    def _set_pin(self):
        root = self._root()
        if not root:
            return
        pin = (self.ed_pin.text() or "").strip()
        if len(pin) < 4:
            QMessageBox.critical(self, core.APP_NAME, "PIN too short.")
            return
        share.pin_set(root, pin)
        QMessageBox.information(self, core.APP_NAME, "Teacher PIN saved on share.")
        self.refresh()

    def _login(self):
        root = self._root()
        if not root:
            return
        if not share.pin_is_set(root):
            QMessageBox.information(self, core.APP_NAME, "No PIN set yet. Create the PIN first.")
            return
        pin = (self.ed_pin.text() or "").strip()
        if not share.pin_verify(root, pin):
            QMessageBox.critical(self, core.APP_NAME, "Wrong PIN.")
            return
        self.app.enter_teacher(root)
        self._authed = True
        self.refresh()
        QMessageBox.information(self, core.APP_NAME, "Teacher authenticated.")

    def _ensure_teacher_context(self) -> bool:
        root = self._root()
        if not root:
            return False
        if self.app.mode == "teacher" and self.app.share_root and Path(self.app.share_root) == root:
            return True
        if not share.pin_is_set(root):
            QMessageBox.information(self, core.APP_NAME, "Create the teacher PIN first.")
            return False
        pin = (self.ed_pin.text() or "").strip()
        if not share.pin_verify(root, pin):
            QMessageBox.critical(self, core.APP_NAME, "Wrong PIN.")
            return False
        self.app.enter_teacher(root)
        self._authed = True
        self.refresh()
        return True

    def _require_teacher(self) -> bool:
        return self._ensure_teacher_context()

    def _apply_class(self):
        if not self._ensure_teacher_context():
            return
        code = norm_code(self.ed_code.text().strip())
        if not code:
            QMessageBox.critical(self, core.APP_NAME, "Invalid classroom code.")
            return
        share.ensure_classroom(self.app.share_root, code)
        self.app.class_code = code
        core.cfg_set("class_code", code)
        self.app.locked_policy = share.policy_load(self.app.share_root, code)
        self.app.refresh_all()
        self.refresh()
        cd = share.class_dir(self.app.share_root, code)
        QMessageBox.information(
            self,
            core.APP_NAME,
            f"Classroom ready: {code}\n\nStudents should enter this share root:\n{self.app.share_root}\n\nDo not enter this cases folder:\n{cd / 'cases'}\n\nCase layout:\nclassrooms/{code}/cases/<CASE_ID>/t1.nii.gz\nclassrooms/{code}/cases/<CASE_ID>/gold.nii.gz\nclassrooms/{code}/cases/<CASE_ID>/case.json",
        )

    def _policy(self):
        if not self._require_teacher() or not self.app.class_code:
            QMessageBox.information(self, core.APP_NAME, "Create / open a classroom first.")
            return
        pol = share.policy_load(self.app.share_root, self.app.class_code)
        mv = int(pol.get("min_voxels", core.DEFAULT_MIN_VOXELS))
        tol = int(pol.get("tolerance", core.DEFAULT_TOLERANCE))
        mv2, ok = QInputDialog.getInt(self, "Classroom policy", "Minimum lesion voxels:", mv, 1, 100000, 1)
        if not ok:
            return
        tol2, ok = QInputDialog.getInt(self, "Classroom policy", "Tolerance (mismatch voxels):", tol, 0, 10000000, 10)
        if not ok:
            return
        pol["min_voxels"] = int(mv2)
        pol["tolerance"] = int(tol2)
        share.policy_save(self.app.share_root, self.app.class_code, pol)
        self.app.locked_policy = pol
        self.app.refresh_all()
        self.refresh()
        QMessageBox.information(self, core.APP_NAME, "Policy saved.")

    def _classroom_dir(self) -> Path | None:
        if not self._ensure_teacher_context() or not self.app.class_code:
            return None
        return share.class_dir(self.app.share_root, self.app.class_code)

    def _open_classroom_folder(self):
        cd = self._classroom_dir()
        if cd:
            open_default(cd)

    def _open_cases_folder(self):
        cd = self._classroom_dir()
        if cd:
            open_default(cd / "cases")

    def _detect_case_pair(self, folder: Path):
        t1 = None
        gold = None
        for name in ("t1.nii.gz", "t1.nii"):
            p = folder / name
            if p.exists():
                t1 = p
                break
        for name in ("gold.nii.gz", "gold.nii"):
            p = folder / name
            if p.exists():
                gold = p
                break
        return t1, gold

    def _safe_case_id(self, name: str) -> str:
        raw = (name or "").strip()
        safe = "".join(c if c.isalnum() or c in ("-", "_") else "_" for c in raw)
        safe = safe.strip("_")
        return safe or f"case_{now_ts()}"

    def _import_case_folder(self):
        if not self._require_teacher() or not self.app.class_code:
            QMessageBox.information(self, core.APP_NAME, "Create / open a classroom first.")
            return
        src_dir = QFileDialog.getExistingDirectory(self, "Select folder containing case folders", str(Path.home()))
        if not src_dir:
            return
        src = Path(src_dir)
        candidates = []
        t1, gold = self._detect_case_pair(src)
        if t1 and gold:
            candidates = [src]
        else:
            candidates = [p for p in sorted(src.iterdir(), key=lambda x: x.name.lower()) if p.is_dir() and all(self._detect_case_pair(p))]
        if not candidates:
            QMessageBox.information(self, core.APP_NAME, "No valid cases found. Each case folder must contain t1.nii(.gz) and gold.nii(.gz).")
            return
        imported = 0
        dest_root = share.class_dir(self.app.share_root, self.app.class_code) / "cases"
        dest_root.mkdir(parents=True, exist_ok=True)
        for folder in candidates:
            t1, gold = self._detect_case_pair(folder)
            if not (t1 and gold):
                continue
            ok, msg, meta = validate_pair(t1, gold)
            if not ok:
                continue
            case_id = self._safe_case_id(folder.name)
            dest = share.upload_case(self.app.share_root, self.app.class_code, case_id, t1, gold)
            src_meta = {}
            case_json = folder / "case.json"
            if case_json.exists():
                try:
                    src_meta = json.loads(case_json.read_text(encoding="utf-8"))
                    if not isinstance(src_meta, dict):
                        src_meta = {}
                except Exception:
                    src_meta = {}
            merged = dict(src_meta)
            merged.update(meta or {})
            merged["case_id"] = case_id
            merged.setdefault("label", folder.name)
            (dest / "case.json").write_text(json.dumps(merged, indent=2), encoding="utf-8")
            imported += 1
        self.app.refresh_all()
        self.refresh()
        QMessageBox.information(self, core.APP_NAME, f"Imported {imported} case(s) into classroom {self.app.class_code}.")

    def _open_students_folder(self):
        cd = self._classroom_dir()
        if cd:
            open_default(cd / "progress" / "attempts")

    def _upload_case(self):
        if not self._require_teacher() or not self.app.class_code:
            QMessageBox.information(self, core.APP_NAME, "Create / open a classroom first.")
            return
        t1_fp, _ = QFileDialog.getOpenFileName(self, "Select T1 (NIfTI)", str(Path.home()), "NIfTI (*.nii *.nii.gz)")
        if not t1_fp:
            return
        gold_fp, _ = QFileDialog.getOpenFileName(self, "Select gold mask (NIfTI)", str(Path.home()), "NIfTI (*.nii *.nii.gz)")
        if not gold_fp:
            return
        t1 = Path(t1_fp)
        gold = Path(gold_fp)
        ok, msg, meta = validate_pair(t1, gold)
        if not ok:
            QMessageBox.critical(self, core.APP_NAME, msg)
            return
        case_id = f"case_{now_ts()}_{uuid.uuid4().hex[:6]}"
        dest = share.upload_case(self.app.share_root, self.app.class_code, case_id, t1, gold)
        try:
            os.chmod(dest / "gold.nii.gz", 0o444)
        except Exception:
            pass
        (dest / "case.json").write_text(json.dumps({"case_id": case_id, **meta}, indent=2), encoding="utf-8")
        self.app.refresh_all()
        self.refresh()
        QMessageBox.information(self, core.APP_NAME, f"Uploaded: {case_id}")

    def _upload_material(self):
        if not self._require_teacher() or not self.app.class_code:
            QMessageBox.information(self, core.APP_NAME, "Create / open a classroom first.")
            return
        fp, _ = QFileDialog.getOpenFileName(self, "Select material", str(Path.home()), "Presentations (*.ppt *.pptx *.pdf)")
        if not fp:
            return
        rel, ok = QInputDialog.getText(self, "Optional subfolder", "Inside materials/slides/, use subfolder:", text="")
        if not ok:
            return
        dest = share.upload_material(self.app.share_root, self.app.class_code, rel or "", Path(fp))
        self.refresh()
        QMessageBox.information(self, core.APP_NAME, f"Uploaded:\n{dest}")



    def _detect_valid_case_dirs(self, root: Path):
        root = Path(root)
        if not root.exists():
            return []
        direct_t1, direct_gold = self._detect_case_pair(root)
        if direct_t1 and direct_gold:
            return [root]
        out = []
        for d in sorted([x for x in root.iterdir() if x.is_dir()], key=lambda x: x.name.lower()):
            t1, gold = self._detect_case_pair(d)
            if t1 and gold:
                out.append(d)
        return out

    def _pack_case_count(self) -> int:
        if not self._pack_cases_root or not Path(self._pack_cases_root).exists():
            return 0
        try:
            return len(self._detect_valid_case_dirs(Path(self._pack_cases_root)))
        except Exception:
            return 0

    def _select_pack_cases(self):
        start = str(self._pack_cases_root or core.BUILTIN_CASES_DIR or Path.home())
        folder = QFileDialog.getExistingDirectory(self, "Select cases folder", start)
        if not folder:
            return
        root = Path(folder)
        count = len(self._detect_valid_case_dirs(root))
        if count == 0:
            QMessageBox.information(self, core.APP_NAME, "No valid case folders found. Select one case folder or one folder containing many case folders with t1.nii.gz and gold.nii.gz.")
            return
        self._pack_cases_root = root
        self.refresh()

    def _select_pack_materials(self):
        start = str(self._pack_materials_root or core.BUILTIN_MATERIALS_DIR or Path.home())
        folder = QFileDialog.getExistingDirectory(self, "Select materials folder", start)
        if not folder:
            return
        self._pack_materials_root = Path(folder)
        self.refresh()

    def _preview_content_pack(self):
        if not self._pack_cases_root:
            QMessageBox.information(self, core.APP_NAME, "Select a cases folder first.")
            return
        case_dirs = self._detect_valid_case_dirs(Path(self._pack_cases_root))
        if not case_dirs:
            QMessageBox.information(self, core.APP_NAME, "No valid cases found in the selected folder.")
            return
        lines = [f"Cases folder: {self._pack_cases_root}", f"Valid cases: {len(case_dirs)}", "", "Included cases:"]
        lines.extend(f"- {d.name}" for d in case_dirs[:30])
        if len(case_dirs) > 30:
            lines.append(f"... and {len(case_dirs)-30} more")
        if self._pack_materials_root and Path(self._pack_materials_root).exists():
            mat_files = sum(1 for p in Path(self._pack_materials_root).rglob('*') if p.is_file())
            lines += ["", f"Materials folder: {self._pack_materials_root}", f"Material files: {mat_files}"]
        QMessageBox.information(self, core.APP_NAME, "\n".join(lines))

    def _create_content_pack(self):
        start_cases = str((self._classroom_dir() / "cases") if self._classroom_dir() else core.BUILTIN_CASES_DIR)
        cases_root = QFileDialog.getExistingDirectory(self, "Select cases folder", start_cases)
        if not cases_root:
            return
        materials_root = QFileDialog.getExistingDirectory(self, "Select materials folder (optional)", str(core.BUILTIN_MATERIALS_DIR))
        title, ok = QInputDialog.getText(self, "Content pack", "Pack title:", text=str(self.app.class_code or "SegLab_Pack"))
        if not ok:
            return
        suggested = f"{(title or 'SegLab_Pack').strip()}.seglabpack"
        out, _ = QFileDialog.getSaveFileName(self, "Save content pack", str(Path.home() / suggested), "SegLab pack (*.seglabpack)")
        if not out:
            return
        try:
            case_count, mat_count, out_path = content_packs.create_pack_from_roots(Path(out), Path(cases_root), Path(materials_root) if materials_root else None, title or "SegLab_Pack")
            QMessageBox.information(self, core.APP_NAME, f"Created content pack:\n{out_path}\n\nCases: {case_count}\nMaterials: {mat_count}")
        except Exception as e:
            QMessageBox.critical(self, core.APP_NAME, f"Could not create content pack: {e}")

    def _import_content_pack(self):
        path, _ = QFileDialog.getOpenFileName(self, "Import content pack", str(Path.home()), "SegLab pack (*.seglabpack)")
        if not path:
            return
        try:
            pack_id, case_count, mat_count = content_packs.install_pack(Path(path))
            self.app.refresh_all()
            QMessageBox.information(self, core.APP_NAME, f"Imported content pack: {pack_id}\n\nCases: {case_count}\nMaterials: {mat_count}")
        except Exception as e:
            QMessageBox.critical(self, core.APP_NAME, f"Could not import content pack: {e}")

    def _open_builtin_cases_folder(self):
        try:
            core.BUILTIN_CASES_DIR.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        open_default(core.BUILTIN_CASES_DIR)

    def refresh(self):
        root = self._root(must_exist=False)
        has_pin = bool(root and share.pin_is_set(root))
        authed = self.app.mode == "teacher" and bool(self.app.share_root)
        self._authed = authed
        self.lbl_share.setText(f"Current folder: {root if root else '—'}")
        if not root:
            self.info.setText("Choose the share folder first.")
        elif not has_pin:
            self.info.setText("Step 2: create the teacher PIN on this share. Login stays disabled until a PIN exists.")
        elif not authed:
            self.info.setText("PIN found. Enter it and click Login.")
        else:
            self.info.setText(f"Authenticated • Share: {self.app.share_root}")

        self.b_login.setEnabled(bool(root and has_pin))
        self._set_button_kind(self.b_setpin, "primary" if not has_pin else "ghost")
        self._set_button_kind(self.b_login, "primary" if has_pin and not authed else "ghost")

        for w in [self.card_class, self.dash]:
            w.setVisible(authed)
        for b in [self.b_policy, self.b_import_cases, self.b_add_case, self.b_open_classroom, self.b_open_cases, self.b_open_students]:
            b.setEnabled(authed and bool(self.app.class_code))
        self.b_pack_cases.setEnabled(True)
        self.b_pack_materials.setEnabled(True)
        self.b_preview_pack.setEnabled(True)
        self.b_make_pack.setEnabled(True)
        self.b_import_pack.setEnabled(True)
        self.b_open_builtin.setEnabled(True)

        case_txt = "none selected"
        if self._pack_cases_root and self._pack_cases_root.exists():
            case_txt = f"{self._pack_cases_root}  •  {self._pack_case_count()} valid case(s)"
        mat_txt = "none selected"
        if self._pack_materials_root and self._pack_materials_root.exists():
            mat_txt = str(self._pack_materials_root)
        self.lbl_pack_cases.setText(f"Cases: {case_txt}")
        self.lbl_pack_materials.setText(f"Materials: {mat_txt}")
        self.lbl_pack.setText("Select one folder containing all case folders. Materials are optional. Create package produces one .seglabpack for students to import.")
        if authed:
            current = self.app.class_code or '—'
            cases_dir = share.class_dir(self.app.share_root, current) / 'cases' if self.app.class_code else None
            self.lbl_class.setText(f"Current classroom: {current}" + (f"  •  Cases folder: {cases_dir}" if cases_dir else "") + f"  •  Students use share root: {self.app.share_root}")
        else:
            self.lbl_class.setText("No classroom selected.")
        try:
            self.dash.refresh()
        except Exception:
            pass
