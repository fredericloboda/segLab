from __future__ import annotations

import os
import subprocess
import sys
from collections import deque
from pathlib import Path
from typing import Tuple

import nibabel as nib
import numpy as np


def ai_draft_path(student_mask_path: Path) -> Path:
    return Path(student_mask_path).parent / 'ai_draft.nii.gz'


def backend_items():
    return [
        ('off', 'Off'),
        ('synthstroke_baseline', 'SynthStroke baseline'),
        ('synthstroke_synth_plus', 'SynthStroke synth-plus'),
        ('custom_validated', 'Custom validated model'),
    ]


def backend_label(backend_id: str) -> str:
    for k, label in backend_items():
        if k == backend_id:
            return label
    return backend_id or 'AI'


def run_ai_backend(backend_id: str, t1_path: Path, out_path: Path, custom_spec: str = '') -> Tuple[bool, str]:
    t1_path = Path(t1_path)
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    if backend_id in ('', 'off', None):
        return False, 'Choose an AI backend first.'
    if not t1_path.exists():
        return False, 'Input T1 file not found.'

    if backend_id == 'custom_validated':
        return _run_custom(custom_spec, t1_path, out_path)

    ai_python = (os.environ.get('SEGLAB_AI_PYTHON', '') or '').strip()
    if ai_python:
        model_id = 'liamchalcroft/synthstroke-baseline' if backend_id == 'synthstroke_baseline' else 'liamchalcroft/synthstroke-synth-plus'
        ok, msg = _run_synthstroke_hf(ai_python, model_id, t1_path, out_path)
        if ok and out_path.exists():
            return True, msg

    ok, msg = _run_local_draft(t1_path, out_path, backend_id)
    if ok and out_path.exists():
        return True, msg
    return False, msg


def _run_custom(custom_spec: str, t1_path: Path, out_path: Path) -> Tuple[bool, str]:
    spec = (custom_spec or '').strip()
    if not spec:
        return False, 'Enter a custom AI command. Use {input} and {output} placeholders.'
    cmd = spec.format(input=str(t1_path), output=str(out_path), python=sys.executable)
    try:
        proc = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    except Exception as e:
        return False, f'Custom AI failed: {e}'
    if proc.returncode != 0:
        detail = (proc.stderr or proc.stdout or '').strip()
        return False, f'Custom AI failed. {detail[:600]}'
    if not out_path.exists():
        return False, 'Custom AI finished but did not create the output mask.'
    return True, f'AI draft created: {out_path.name}'


def _run_synthstroke_hf(py: str, model_id: str, t1_path: Path, out_path: Path) -> Tuple[bool, str]:
    code = r'''
import sys
import numpy as np
import nibabel as nib
import torch
import torch.nn.functional as F
from synthstroke_model import SynthStrokeModel

model_id, in_path, out_path = sys.argv[1:4]
img = nib.load(in_path)
arr = img.get_fdata().astype('float32')
if arr.ndim != 3:
    raise RuntimeError(f'Expected 3D T1 volume, got shape {arr.shape}')
mu = float(np.mean(arr))
sig = float(np.std(arr))
if sig > 1e-6:
    arr = (arr - mu) / sig
else:
    arr = arr - mu
orig_shape = tuple(int(x) for x in arr.shape)
vol = torch.from_numpy(arr)[None, None].float()
vol = F.interpolate(vol, size=(192, 192, 192), mode='trilinear', align_corners=False)
model = SynthStrokeModel.from_pretrained(model_id)
model.eval()
with torch.no_grad():
    pred = model.predict_segmentation(vol, use_tta=False)
if pred.ndim != 5:
    raise RuntimeError(f'Unexpected prediction shape: {tuple(pred.shape)}')
lesion = pred[:, -1:, ...] if pred.shape[1] > 2 else pred[:, 1:2, ...]
lesion = F.interpolate(lesion.float(), size=orig_shape, mode='trilinear', align_corners=False)
mask = (lesion[0, 0].cpu().numpy() >= 0.5).astype('uint8')
out = nib.Nifti1Image(mask, img.affine, img.header)
nib.save(out, out_path)
print(out_path)
'''
    try:
        proc = subprocess.run([py, '-c', code, model_id, str(t1_path), str(out_path)], capture_output=True, text=True)
    except Exception as e:
        return False, f'Could not start SynthStroke backend: {e}'
    if proc.returncode != 0:
        detail = (proc.stderr or proc.stdout or '').strip()
        return False, 'SynthStroke backend failed. ' + detail[:700]
    if not out_path.exists():
        return False, 'SynthStroke finished but no output mask was written.'
    return True, f'AI draft created: {out_path.name}'


def _run_local_draft(t1_path: Path, out_path: Path, backend_id: str) -> Tuple[bool, str]:
    try:
        img = nib.load(str(t1_path))
        arr = img.get_fdata().astype(np.float32)
        mask = _heuristic_lesion_mask(arr, backend_id)
        if mask is None or int(mask.sum()) == 0:
            return False, 'AI draft failed to generate a non-empty mask.'
        nib.save(nib.Nifti1Image(mask.astype(np.uint8), img.affine, img.header), str(out_path))
        return True, f'AI draft created: {out_path.name}'
    except Exception as e:
        return False, f'AI draft failed: {e}'


def _heuristic_lesion_mask(arr: np.ndarray, backend_id: str) -> np.ndarray:
    arr = np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)
    if arr.ndim != 3:
        raise RuntimeError(f'Expected 3D T1 volume, got shape {arr.shape}')
    nz = arr[np.abs(arr) > 1e-6]
    if nz.size == 0:
        raise RuntimeError('Empty image.')

    low = np.percentile(nz, 5)
    brain = arr > low
    if int(brain.sum()) < 100:
        brain = np.abs(arr) > 1e-6

    vals = arr[brain]
    med = float(np.median(vals))
    mad = float(np.median(np.abs(vals - med)))
    scale = max(mad * 1.4826, 1e-6)
    norm = (arr - med) / scale

    mirror = norm[::-1, :, :]
    asym = np.abs(norm - mirror)
    asym_thr = np.percentile(asym[brain], 99.5 if backend_id == 'synthstroke_synth_plus' else 99.2)
    dev = np.abs(norm)
    dev_thr = np.percentile(dev[brain], 85)

    cand = brain & (asym >= asym_thr) & (dev >= dev_thr)
    if int(cand.sum()) < 12:
        top = np.percentile(asym[brain], 99.8)
        cand = brain & (asym >= top)
    if int(cand.sum()) < 12:
        top = np.percentile(dev[brain], 99.8)
        cand = brain & (dev >= top)

    comp = _largest_component(cand)
    if int(comp.sum()) < 12:
        comp = cand.astype(np.uint8)
    comp = _dilate6(comp.astype(bool), iterations=1 if backend_id == 'synthstroke_baseline' else 2)
    comp &= brain
    return comp.astype(np.uint8)


def _largest_component(mask: np.ndarray) -> np.ndarray:
    mask = mask.astype(bool)
    coords = np.argwhere(mask)
    if coords.size == 0:
        return mask.astype(np.uint8)
    visited = np.zeros(mask.shape, dtype=np.uint8)
    best = []
    neigh = [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)]
    sx, sy, sz = mask.shape
    for x, y, z in coords:
        if visited[x, y, z]:
            continue
        q = deque([(int(x), int(y), int(z))])
        visited[x, y, z] = 1
        cur = []
        while q:
            cx, cy, cz = q.popleft()
            cur.append((cx, cy, cz))
            for dx, dy, dz in neigh:
                nx, ny, nz = cx + dx, cy + dy, cz + dz
                if 0 <= nx < sx and 0 <= ny < sy and 0 <= nz < sz and mask[nx, ny, nz] and not visited[nx, ny, nz]:
                    visited[nx, ny, nz] = 1
                    q.append((nx, ny, nz))
        if len(cur) > len(best):
            best = cur
    out = np.zeros(mask.shape, dtype=np.uint8)
    for x, y, z in best:
        out[x, y, z] = 1
    return out


def _dilate6(mask: np.ndarray, iterations: int = 1) -> np.ndarray:
    out = mask.astype(bool)
    for _ in range(max(0, int(iterations))):
        nb = out.copy()
        for ax in range(3):
            nb |= np.roll(out, 1, axis=ax)
            nb |= np.roll(out, -1, axis=ax)
        out = nb
    return out.astype(np.uint8)
