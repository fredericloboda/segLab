from __future__ import annotations
from pathlib import Path
import lt_share as share

def resolve_share(mounted_path: Path) -> Path:
    return share.resolve_share_root(mounted_path)

def list_class_cases(share_root: Path, code: str) -> list[Path]:
    return share.list_class_cases(share_root, code)
