from __future__ import annotations

from pathlib import Path


def available() -> bool:
    # Internal editor is not implemented yet.
    return False


def launch() -> None:
    """Launch the internal editor app.

    Implement later (e.g., start your Qt editor executable).
    """
    raise NotImplementedError("Internal editor not implemented yet.")


def open_case(t1_path: Path, student_mask_path: Path) -> None:
    """Open a case in the internal editor.

    Implement later.
    """
    raise NotImplementedError("Internal editor not implemented yet. Use ITK-SNAP from Practice for now.")
