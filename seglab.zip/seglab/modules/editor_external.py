from __future__ import annotations

from pathlib import Path
from typing import Tuple

from lt_editor import launch as launch_itksnap


def open_case(t1_path: Path, student_mask_path: Path) -> Tuple[bool, str]:
    """Mandatory external editor for the demo build.

    Returns (ok, msg) so the caller can show a proper error instead of silently
    opening folders/files when ITK-SNAP is missing.
    """
    return launch_itksnap(t1_path, student_mask_path)
