from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

import lt_core as core


# Built-in offline cases live in resources/bundled_cases/<case_id>/ (canonical)
# Legacy resources/cases_builtin/<case_id>/ is still accepted.


def manifest() -> dict:
    """Primary manifest is the legacy offline built-ins list (builtin_01..10).

    Bundled cases dropped later into resources/bundled_cases are discovered from folders,
    so placeholder manifest entries there do not pollute the UI.
    """
    candidates = [core.RESOURCES / "cases_builtin" / "manifest.json"]
    for m in candidates:
        try:
            if m.exists():
                d = json.loads(m.read_text(encoding="utf-8"))
                return d if isinstance(d, dict) else {}
        except Exception:
            pass
    return {"cases": []}


def _candidate_dirs(case_id: str) -> List[Path]:
    cid = str(case_id)
    return [
        core.RESOURCES / "bundled_cases" / cid,
        core.RESOURCES / "cases_builtin" / cid,
    ]


def resource_case_dir(case_id: str) -> Path:
    for p in _candidate_dirs(case_id):
        if p.exists():
            return p
    return _candidate_dirs(case_id)[0]


def resource_t1(case_id: str) -> Path:
    return resource_case_dir(case_id) / "t1.nii.gz"


def resource_gold(case_id: str) -> Path:
    return resource_case_dir(case_id) / "gold.nii.gz"


def resource_meta(case_id: str) -> Path:
    d = resource_case_dir(case_id)
    for name in ("case.json", "meta.json"):
        p = d / name
        if p.exists():
            return p
    return d / "case.json"


def builtin_ready(case_id: str) -> bool:
    try:
        return resource_t1(case_id).exists() and resource_gold(case_id).exists()
    except Exception:
        return False


def _coerce_case_id(entry: Dict[str, Any]) -> str:
    return str(entry.get("case_id") or entry.get("id") or entry.get("slug") or "").strip()


def _meta_from_fs(case_id: str) -> Dict[str, Any]:
    p = resource_meta(case_id)
    if not p.exists():
        return {}
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _apply_fs_override(entry: Dict[str, Any]) -> Dict[str, Any]:
    cid = _coerce_case_id(entry)
    if not cid:
        return entry
    ready = builtin_ready(cid)
    e = dict(_meta_from_fs(cid))
    e.update(entry)
    e["case_id"] = cid
    e.setdefault("label", cid)
    e.setdefault("source", "bundled")
    e.setdefault("difficulty", "")
    e.setdefault("category", "")

    if ready:
        e["status"] = "READY"
        e["available"] = True
        e["coming_soon"] = False
    else:
        e.setdefault("status", "COMING_SOON")
        e.setdefault("available", False)
        e.setdefault("coming_soon", True)
    return e


def _discover_extra_cases(existing_ids: set[str]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    seen = set(existing_ids)
    for root in [core.RESOURCES / "bundled_cases", core.RESOURCES / "cases_builtin"]:
        try:
            if not root.exists():
                continue
            for d in sorted(root.iterdir()):
                if not d.is_dir():
                    continue
                cid = d.name
                if cid in seen:
                    continue
                seen.add(cid)
                meta = _meta_from_fs(cid)
                row = {
                    "case_id": cid,
                    "label": str(meta.get("label") or cid),
                    "status": "READY" if builtin_ready(cid) else "COMING_SOON",
                    "available": builtin_ready(cid),
                    "coming_soon": not builtin_ready(cid),
                    "source": "bundled",
                    "difficulty": str(meta.get("difficulty") or ""),
                    "category": str(meta.get("category") or ""),
                }
                out.append(row)
        except Exception:
            continue
    return out


def list_cases() -> List[Dict[str, Any]]:
    d = manifest()
    cases = d.get("cases", [])
    if not isinstance(cases, list):
        cases = []

    normalized: List[Dict[str, Any]] = []
    ids: set[str] = set()
    for c in cases:
        if not isinstance(c, dict):
            continue
        cid = _coerce_case_id(c)
        if not cid:
            continue
        ids.add(cid)
        normalized.append(_apply_fs_override(c))

    normalized.extend(_discover_extra_cases(ids))
    normalized.sort(key=lambda x: str(x.get("label") or x.get("case_id") or "").lower())
    return normalized


def ensure_workspace_entries() -> None:
    core.ensure_dirs()
    for c in list_cases():
        cid = str(c.get("case_id") or "").strip()
        if not cid:
            continue
        wdir = core.WORKSPACE / cid
        try:
            wdir.mkdir(parents=True, exist_ok=True)
        except Exception:
            continue
        meta = {
            "case_id": cid,
            "source": "bundled",
            "label": c.get("label") or cid,
            "status": c.get("status") or "",
            "difficulty": c.get("difficulty") or "",
            "category": c.get("category") or "",
            "t1_path": str(resource_t1(cid)),
            "gold_path": str(resource_gold(cid)),
        }
        try:
            (wdir / "case.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
        except Exception:
            pass
