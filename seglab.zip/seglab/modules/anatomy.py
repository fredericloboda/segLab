from __future__ import annotations
from pathlib import Path
import lt_core as core

def list_anatomy_materials() -> list[Path]:
    if not core.ANATOMY_DIR.exists():
        return []
    exts = {".pdf",".pptx",".ppt"}
    out = []
    for p in sorted(core.ANATOMY_DIR.rglob("*")):
        if p.is_file() and p.suffix.lower() in exts:
            out.append(p)
    return out
