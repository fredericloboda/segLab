from __future__ import annotations

from dataclasses import dataclass
from typing import List, Dict, Any, Optional


@dataclass
class CompetencyRule:
    dice_threshold: float = 0.65
    consecutive: int = 3
    min_tier: int = 2  # require unseen cases tier>=2


def evaluate_competency(rows: List[Dict[str, Any]], rule: CompetencyRule) -> Dict[str, Any]:
    """rows: list of attempt dicts ordered by time for a single user in TEST mode."""
    streak = 0
    best_streak = 0
    idx_reached: Optional[int] = None
    for i, r in enumerate(rows):
        tier = int(r.get("difficulty_tier", 0) or 0)
        dice = float(r.get("dice", 0.0) or 0.0)
        unseen = bool(r.get("unseen", True))
        ok = unseen and (tier >= rule.min_tier) and (dice >= rule.dice_threshold)
        if ok:
            streak += 1
            best_streak = max(best_streak, streak)
            if streak >= rule.consecutive and idx_reached is None:
                idx_reached = i
        else:
            streak = 0
    return {
        "competent": idx_reached is not None,
        "cases_to_competency": (idx_reached + 1) if idx_reached is not None else None,
        "best_streak": best_streak,
        "rule": {
            "dice_threshold": rule.dice_threshold,
            "consecutive": rule.consecutive,
            "min_tier": rule.min_tier,
        },
    }
