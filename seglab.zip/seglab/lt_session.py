from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
import time
from pathlib import Path


@dataclass
class StudyConfig:
    cohort_id: str = ""
    session_id: str = ""
    group: str = "A"  # A/B
    mode: str = "test"  # train/test
    class_code: str = ""
    casepack_version: str = ""
    user_id: str = ""
    app_version: str = ""


@dataclass
class StudyState:
    cfg: StudyConfig
    ordered_case_ids: List[str] = field(default_factory=list)
    idx: int = 0
    case_start_ts: Optional[float] = None

    def current_case_id(self) -> Optional[str]:
        if 0 <= self.idx < len(self.ordered_case_ids):
            return self.ordered_case_ids[self.idx]
        return None

    def start_case(self) -> None:
        self.case_start_ts = time.time()

    def finish_case(self) -> float:
        if self.case_start_ts is None:
            return 0.0
        dur = float(time.time() - self.case_start_ts)
        self.case_start_ts = None
        return dur

    def advance(self) -> None:
        self.idx += 1
        self.case_start_ts = None

    def is_done(self) -> bool:
        return self.idx >= len(self.ordered_case_ids)
