#!/bin/bash
cd "$(dirname "$0")"
bash ./build_mac.sh
