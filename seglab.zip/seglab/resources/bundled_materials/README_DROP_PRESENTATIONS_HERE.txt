Drop PPT/PPTX/PDF study materials here before building/zipping.
Recommended subfolders:
  intro/
  anatomy/
  slides/
