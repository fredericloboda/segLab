Drop files for anatomy here.
