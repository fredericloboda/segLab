Drop files for slides here.
