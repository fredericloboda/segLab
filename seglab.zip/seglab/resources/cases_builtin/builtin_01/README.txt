Placeholder dataset slot. Add t1.nii.gz and gold.nii.gz here.
