Place anatomy training PDFs/PPTX here.
