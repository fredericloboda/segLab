Drop built-in cases here before building/zipping.
One folder per case:
  <case_id>/
    t1.nii.gz
    gold.nii.gz
    case.json
