SegLab — lesion segmentation trainer (offline + SMB classroom)

Run (dev):
  cd seglab
  python3 -m venv .venv
  source .venv/bin/activate
  pip install -r requirements.txt
  python startt_trainer.py

User data (never inside the app folder):
  ~/SegLabEPFL_UserData/

Built-in cases (ship inside the app):
  seglab/resources/bundled_cases/

  One folder per case:
    <case_id>/
      t1.nii.gz
      gold.nii.gz
      case.json

Built-in study materials / presentations:
  seglab/resources/bundled_materials/
    intro/
    anatomy/
    slides/

Classroom mode (SMB):
  Mount your SMB share in the OS (Finder / Windows Explorer), then use the mounted path in the app:
    macOS: /Volumes/<ShareName>/...
    Windows: X:\\...

Build notes:
  build_win.ps1 and build_mac.sh now bundle the entire resources folder into the packaged app.

Progress / exports:
  Attempts are written to JSONL + CSV.
  Per-case and overall summary exports go to:
    ~/SegLabEPFL_UserData/exports/


macOS quick build:
- double-click build_mac.command or run: bash build_mac.sh
- output: dist/SegLab.app and dist/SegLab_macOS.app.zip
