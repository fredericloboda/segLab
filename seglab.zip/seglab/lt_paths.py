from __future__ import annotations

from pathlib import Path
import lt_core as core
from lt_utils import norm_code


def workspace_root() -> Path:
    return core.WORKSPACE


def workspace_classroom_root(class_code: str) -> Path:
    return core.WORKSPACE / "classrooms" / norm_code(class_code)


def workspace_class_cases_dir(class_code: str) -> Path:
    return workspace_classroom_root(class_code) / "cases"


def workspace_class_materials_dir(class_code: str) -> Path:
    return workspace_classroom_root(class_code) / "materials" / "slides"


def share_lttrainer_root(selected_path: Path) -> Path:
    """Resolve the LTTrainer share root from flexible user-selected paths.

    Accepted inputs:
    - .../LTTrainer
    - parent folder that contains LTTrainer
    - a share root that already contains classrooms/config
    - .../LTTrainer/classrooms/<CLASS>
    - .../LTTrainer/classrooms/<CLASS>/cases
    - .../LTTrainer/config
    """
    p = Path(selected_path).expanduser().resolve()

    for cand in [p, *p.parents]:
        name = cand.name.lower()
        if name == 'lttrainer':
            return cand
        if (cand / 'classrooms').exists() and (cand / 'config').exists():
            return cand

    parts = list(p.parts)
    lower = [str(x).lower() for x in parts]
    if 'lttrainer' in lower:
        idx = lower.index('lttrainer')
        return Path(*parts[: idx + 1]).resolve()

    if p.name.lower() in {'classrooms', 'config', 'updates'} and p.parent.exists():
        return p.parent.resolve()

    if (p / 'LTTrainer').exists():
        return (p / 'LTTrainer').resolve()

    return (p / 'LTTrainer').resolve()


def share_classroom_dir(share_root: Path, class_code: str) -> Path:
    return Path(share_root) / "classrooms" / norm_code(class_code)


def share_class_cases_dir(share_root: Path, class_code: str) -> Path:
    return share_classroom_dir(share_root, class_code) / "cases"


def share_class_materials_dir(share_root: Path, class_code: str) -> Path:
    return share_classroom_dir(share_root, class_code) / "materials_protected" / "slides"
