from __future__ import annotations
import csv, math
from pathlib import Path
import numpy as np

def fit_power(n, y):
    # y = a*n^b + c (simple linearization with c=0 baseline)
    n = np.array(n, dtype=float)
    y = np.array(y, dtype=float)
    y = np.clip(y, 1e-6, None)
    X = np.vstack([np.log(n), np.ones_like(n)]).T
    b, loga = np.linalg.lstsq(X, np.log(y), rcond=None)[0]
    a = float(np.exp(loga))
    return a, float(b)

def fit_exponential(n, y):
    # y = c - a*exp(-b*n); approximate by setting c=max(y)
    n = np.array(n, dtype=float)
    y = np.array(y, dtype=float)
    c = float(np.max(y))
    z = np.clip(c - y, 1e-6, None)
    X = np.vstack([n, np.ones_like(n)]).T
    bneg, loga = np.linalg.lstsq(X, np.log(z), rcond=None)[0]
    a = float(np.exp(loga))
    b = float(-bneg)
    return a, b, c

def main(path: str):
    p = Path(path)
    rows = []
    with p.open(newline="", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            if row.get("mode","") != "test":
                continue
            try:
                rows.append((row["user"], float(row.get("dice",0.0)), row.get("timestamp","")))
            except Exception:
                pass
    users = sorted(set(u for u,_,_ in rows))
    for u in users:
        ys = [d for uu,d,_ in rows if uu==u]
        ns = list(range(1,len(ys)+1))
        if len(ys) < 3:
            continue
        a,b = fit_power(ns, ys)
        ea,eb,ec = fit_exponential(ns, ys)
        print(u, "power(a,b)=", (a,b), "exp(a,b,c)=", (ea,eb,ec))

if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python fit_learning_curves.py <results.csv>")
        raise SystemExit(2)
    main(sys.argv[1])
