#!/usr/bin/env python3
# startt_trainer.py — SegLab Trainer (offline built-ins + SMB classroom)

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any, Dict, Optional

# ---- macOS Qt stability (MUST be set before importing PySide6) ----
if sys.platform == "darwin":
    os.environ.setdefault("QT_MAC_WANTS_LAYER", "1")
    os.environ.setdefault("OBJC_DISABLE_INITIALIZE_FORK_SAFETY", "YES")

from PySide6.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QStackedWidget,
    QMessageBox,
    QToolButton,
    QButtonGroup,
)
from PySide6.QtCore import Qt

import lt_core as core
import lt_style as style
import lt_share as share

from ui.widgets import pill
from ui.pages_home import HomePage
from ui.pages_intro import IntroductionPage
from ui.pages_editor import EditorPage
from ui.pages_connect import ConnectPage
from ui.pages_practice import PracticePage
from ui.pages_progress import ProgressPage
from ui.pages_teacher import TeacherPage
from ui.pages_study import StudyPage

NAV_VISIBLE = [
    ("Home", "⌂  Home"),
    ("Introduction", "⟐  Intro to segmentation"),
    ("Editor", "⬡  Editor"),
    ("Practice", "◎  Practice"),
    ("Study", "▣  Study"),
    ("Progress", "⟰  Progress"),
    ("Teacher", "⟠  Teacher"),
]

NAV_ALL = [k for k, _ in NAV_VISIBLE] + ["Join"]  # hidden (reachable from Home)


class AppWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        core.ensure_dirs()

        self.setWindowTitle(f"{core.APP_NAME} — v{core.APP_VERSION}")
        self.resize(1440, 840)

        # gate|solo|student|teacher
        self.mode: str = "gate"
        self.username: str = str(core.cfg_get("username", "student") or "student")
        self.share_root: Optional[Path] = None
        self.class_code: str = str(core.cfg_get("class_code", "") or "")
        self.locked_policy: Optional[Dict[str, Any]] = None

        # Solo evaluation policy
        self.solo_min_voxels = int(core.cfg_get("solo_min_voxels", core.DEFAULT_MIN_VOXELS))
        self.solo_tolerance = int(core.cfg_get("solo_tolerance", core.DEFAULT_TOLERANCE))

        root = QWidget()
        self.setCentralWidget(root)
        outer = QVBoxLayout(root)
        outer.setContentsMargins(14, 14, 14, 14)
        outer.setSpacing(12)

        # --- top bar ---
        self.top = QWidget()
        self.top.setObjectName("TopBar")
        tb = QHBoxLayout(self.top)
        tb.setContentsMargins(16, 10, 16, 10)
        tb.setSpacing(12)

        self.lbl_title = QLabel(core.APP_NAME)
        self.lbl_title.setObjectName("AppTitle")
        tb.addWidget(self.lbl_title)
        tb.addStretch(1)

        self.p_mode = pill("GATE")
        self.p_class = pill("NO CLASS")
        self.p_user = pill("USER")
        tb.addWidget(self.p_mode)
        tb.addWidget(self.p_class)
        tb.addWidget(self.p_user)

        outer.addWidget(self.top)

        main = QHBoxLayout()
        main.setSpacing(12)
        outer.addLayout(main, 1)

        # --- sidebar ---
        self.sidebar = QWidget()
        self.sidebar.setObjectName("Sidebar")
        sb = QVBoxLayout(self.sidebar)
        sb.setContentsMargins(10, 12, 10, 12)
        sb.setSpacing(8)

        # Icon+label nav (no scrollbars, no long labels)
        self._nav_group = QButtonGroup(self)
        self._nav_group.setExclusive(True)
        self._nav_buttons: Dict[str, QToolButton] = {}

        for key, label in NAV_VISIBLE:
            b = QToolButton()
            b.setText(label)
            b.setCheckable(True)
            b.setAutoRaise(True)
            b.setCursor(Qt.PointingHandCursor)
            b.setObjectName("NavBtn")
            b.clicked.connect(lambda _=False, k=key: self.goto(k))
            sb.addWidget(b)
            self._nav_group.addButton(b)
            self._nav_buttons[key] = b

        sb.addStretch(1)
        main.addWidget(self.sidebar, 0)

        # --- stack ---
        self.stack = QStackedWidget()
        main.addWidget(self.stack, 1)

        self.pages = {
            "Home": HomePage(self),
            "Introduction": IntroductionPage(self),
            "Editor": EditorPage(self),
            "Practice": PracticePage(self),
            "Study": StudyPage(self),
            "Progress": ProgressPage(self),
            "Teacher": TeacherPage(self),
            "Join": ConnectPage(self),
        }
        for name in NAV_ALL:
            self.stack.addWidget(self.pages[name])

        style.apply_qss(QApplication.instance())

        self.goto("Home")
        self.refresh_all()

    # -------- system / helpers --------
    def toast(self, msg: str):
        try:
            self.statusBar().showMessage(str(msg or ""), 4500)
        except Exception:
            pass

    def quit_for_update(self):
        # Close window; updater helper will relaunch
        try:
            self.close()
        except Exception:
            pass
        try:
            QApplication.instance().quit()
        except Exception:
            pass

    def attempts_dir(self) -> Path:
        uname = self.username or "student"
        if self.mode == "student" and self.share_root and self.class_code:
            return share.attempts_root(self.share_root, self.class_code) / uname
        return core.LOCAL_PROGRESS / uname

    # -------- UI refresh --------
    def _sync_nav_visibility(self):
        allowed = {"Home", "Introduction", "Editor", "Practice", "Study", "Progress"}
        if self.mode == "teacher":
            allowed.add("Teacher")
        elif self.mode == "gate":
            allowed.add("Teacher")
        for key, btn in self._nav_buttons.items():
            btn.setVisible(key in allowed)
        if self.mode == "student" and self.stack.currentWidget() is self.pages.get("Teacher"):
            self.goto("Practice")

    def refresh_chrome(self):
        self.p_mode.setText((self.mode or "gate").upper())
        self.p_user.setText((self.username or "user").upper())
        self.p_class.setText(self.class_code if self.class_code else "NO CLASS")
        self._sync_nav_visibility()

    def refresh_all(self):
        self.refresh_chrome()
        # refresh current page
        try:
            name = NAV_ALL[self.stack.currentIndex()]
            p = self.pages.get(name)
            if p and hasattr(p, "refresh"):
                p.refresh()
        except Exception:
            pass

    # -------- navigation --------
    def goto(self, name: str):
        if name not in NAV_ALL:
            return
        if self.mode == "student" and name == "Teacher":
            name = "Practice"
        self.stack.setCurrentIndex(NAV_ALL.index(name))
        if hasattr(self, "_nav_buttons") and name in self._nav_buttons:
            self._nav_buttons[name].setChecked(True)
        self.refresh_all()

    # -------- mode transitions --------
    def enter_solo(self):
        self.mode = "solo"
        self.class_code = ""
        self.locked_policy = None
        self.share_root = None
        core.cfg_set("username", self.username)
        self.refresh_all()
        self.goto("Practice")

    def enter_teacher(self, share_root: Path):
        self.mode = "teacher"
        self.share_root = share_root
        core.cfg_set("share_root", str(share_root))
        cc = str(core.cfg_get("class_code", "") or "")
        if cc and share.class_exists(share_root, cc):
            self.class_code = cc
            self.locked_policy = share.policy_load(share_root, cc)
        else:
            self.class_code = ""
            self.locked_policy = None
        self.refresh_all()
        self.goto("Teacher")

    def join_classroom(self, share_path: str, class_code: str, username: str):
        p = Path(share_path).expanduser()
        if not p.exists():
            QMessageBox.critical(self, core.APP_NAME, f"Mounted share path does not exist:\n{p}")
            return

        root = share.resolve_share_root(p)
        code = class_code
        if not share.class_exists(root, code):
            expected = share.class_dir(root, code)
            QMessageBox.critical(
                self,
                core.APP_NAME,
                f"Classroom not found: {code}\n\nUse the share root, not the cases folder.\nExpected classroom path:\n{expected}",
            )
            return

        self.share_root = root
        self.username = (username or "student").strip() or "student"
        self.mode = "student"
        self.class_code = code
        core.cfg_set("username", self.username)
        core.cfg_set("share_root", str(root))
        core.cfg_set("class_code", code)

        self.locked_policy = share.policy_load(root, code) or {
            "min_voxels": core.DEFAULT_MIN_VOXELS,
            "tolerance": core.DEFAULT_TOLERANCE,
            "session": "practice",
        }

        self.refresh_all()
        self.goto("Practice")
        QMessageBox.information(self, core.APP_NAME, f"Joined classroom: {code}\n\nShare root:\n{root}\n\nNow click Sync in Practice.")


def main():
    app = QApplication(sys.argv)
    w = AppWindow()
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
