from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Any, Optional, Tuple

import numpy as np
import nibabel as nib


@dataclass
class Difficulty:
    lesion_voxels: int
    lesion_ml: float
    edge_complexity: float
    contrast_ratio: float
    ventricle_proximity_mm: Optional[float]
    score: float
    tier: int


def _voxel_mm3(img) -> float:
    try:
        z = img.header.get_zooms()[:3]
        return float(z[0]*z[1]*z[2])
    except Exception:
        return 1.0


def _boundary_voxels(mask: np.ndarray) -> int:
    # 6-neighborhood boundary count without scipy
    m = mask.astype(bool)
    if m.ndim != 3:
        m = np.squeeze(m)
    # neighbors via shifts
    neigh = (
        np.roll(m, 1, 0) & m
    ) + 0  # force bool op
    # compute erosion approx: voxel is interior if all 6 neighbors are also lesion
    interior = m.copy()
    for ax in range(3):
        interior &= np.roll(m, 1, ax)
        interior &= np.roll(m, -1, ax)
    boundary = m & (~interior)
    return int(boundary.sum())


def _ring_shell(mask: np.ndarray) -> np.ndarray:
    m = mask.astype(bool)
    shell = np.zeros_like(m, dtype=bool)
    for ax in range(3):
        shell |= np.roll(m, 1, ax)
        shell |= np.roll(m, -1, ax)
    shell = shell & (~m)
    return shell


def compute_difficulty(image_path: Path, gold_path: Path, ventricle_mask_path: Optional[Path] = None) -> Difficulty:
    img = nib.load(str(image_path))
    gimg = nib.load(str(gold_path))
    x = img.get_fdata().astype(np.float32)
    g = gimg.get_fdata()
    gb = (g > 0.5)

    lesion_vox = int(gb.sum())
    vox_mm3 = _voxel_mm3(gimg)
    lesion_ml = float(lesion_vox * vox_mm3 / 1000.0)

    # edge complexity: boundary/volume (higher = harder)
    b = _boundary_voxels(gb)
    edge_complexity = float(b / max(lesion_vox, 1))

    # contrast ratio: mean lesion vs surrounding 1-voxel shell
    shell = _ring_shell(gb)
    lesion_mean = float(x[gb].mean()) if lesion_vox > 0 else 0.0
    shell_mean = float(x[shell].mean()) if int(shell.sum()) > 0 else max(lesion_mean, 1e-6)
    contrast_ratio = float((lesion_mean + 1e-6) / (shell_mean + 1e-6))

    vent_prox = None
    if ventricle_mask_path and Path(ventricle_mask_path).exists():
        vimg = nib.load(str(ventricle_mask_path))
        vb = (vimg.get_fdata() > 0.5)
        # crude min distance by sampling boundary voxels and vent voxels (subsample for speed)
        gb_idx = np.argwhere(gb)
        vb_idx = np.argwhere(vb)
        if gb_idx.size and vb_idx.size:
            gb_s = gb_idx[::max(len(gb_idx)//2000,1)]
            vb_s = vb_idx[::max(len(vb_idx)//2000,1)]
            # compute squared distances
            d2_min = None
            for p in gb_s:
                d2 = ((vb_s - p)**2).sum(axis=1)
                md = float(d2.min())
                d2_min = md if d2_min is None else min(d2_min, md)
            # convert voxel distance to mm (approx isotropic using mean zoom)
            try:
                z = gimg.header.get_zooms()[:3]
                mm = float(np.sqrt(d2_min) * float(np.mean(z)))
            except Exception:
                mm = float(np.sqrt(d2_min))
            vent_prox = mm

    # score: scaled combination (higher = harder)
    # normalize lesion_ml with log, edge_complexity direct, contrast inverse, vent proximity inverse
    v_term = 0.0 if vent_prox is None else 1.0 / (1.0 + vent_prox/10.0)
    score = (
        0.35 * float(np.log1p(lesion_ml)) +
        0.35 * edge_complexity +
        0.20 * (1.0 / max(contrast_ratio, 1e-3)) +
        0.10 * v_term
    )
    # tier by score bands (simple; can be replaced by quantiles per pack)
    tier = 1 if score < 0.35 else (2 if score < 0.75 else 3)

    return Difficulty(
        lesion_voxels=lesion_vox,
        lesion_ml=lesion_ml,
        edge_complexity=edge_complexity,
        contrast_ratio=contrast_ratio,
        ventricle_proximity_mm=vent_prox,
        score=float(score),
        tier=int(tier),
    )


def to_metadata(d: Difficulty) -> Dict[str, Any]:
    return {
        "lesion_voxels": d.lesion_voxels,
        "lesion_ml": d.lesion_ml,
        "edge_complexity": d.edge_complexity,
        "contrast_ratio": d.contrast_ratio,
        "ventricle_proximity_mm": d.ventricle_proximity_mm,
        "difficulty_score": d.score,
        "difficulty_tier": d.tier,
    }
