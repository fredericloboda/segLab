from __future__ import annotations

from PySide6.QtWidgets import QApplication

import lt_core as core


def apply_qss(app: QApplication) -> None:
    """Modern, high-end "medical device" dark UI (neutral branding)."""

    qss = f"""
    /* ===== Base ===== */
    QWidget {{
        background-color: {core.BG0};
        color: {core.TEXT};
        font-size: 13px;
        font-family: "SF Pro Display","SF Pro Text","Inter","Helvetica Neue","Segoe UI","Arial";
        font-weight: 500;
    }}

    QMainWindow {{
        background: qradialgradient(cx:0.2, cy:0.0, radius:1.2,
            stop:0 rgba(25,229,255,0.06),
            stop:0.35 rgba(15,18,24,0.00),
            stop:1 rgba(7,8,11,1.0));
    }}

    QLabel#AppTitle {{
        font-size: 16px;
        font-weight: 900;
        letter-spacing: 0.4px;
        color: {core.TEXT};
    }}

    QLabel#H1 {{
        font-size: 30px;
        font-weight: 900;
        letter-spacing: 0px;
        color: {core.TEXT};
    }}

    QLabel#H2 {{
        font-size: 16px;
        font-weight: 900;
        letter-spacing: 0px;
        color: {core.TEXT};
    }}

    QLabel#SectionTitle {{
        font-size: 13px;
        font-weight: 900;
        letter-spacing: 0.6px;
        color: rgba(231,233,241,0.88);
        padding-top: 6px;
        padding-bottom: 2px;
    }}

    QLabel#Caption {{
        color: rgba(231,233,241,0.72);
        font-size: 12px;
    }}

    QLabel#Muted {{
        color: {core.MUTED};
        font-size: 12px;
    }}

    /* ===== Chrome ===== */
    QWidget#TopBar {{
        background: rgba(10,12,18,0.88);
        border: 1px solid rgba(255,255,255,0.04);
        border-radius: 16px;
    }}

    QWidget#Sidebar {{
        background: rgba(9,11,16,0.92);
        border: 1px solid rgba(255,255,255,0.04);
        border-radius: 16px;
        min-width: 220px;
        max-width: 220px;
    }}

    QWidget#Card {{
        background: rgba(255,255,255,0.018);
        border: none;
        border-radius: 16px;
    }}

    /* ===== Tiles (clickable cards) ===== */
    QWidget#Tile {{
        background: rgba(255,255,255,0.018);
        border: none;
        border-radius: 18px;
    }}
    QWidget#Tile:hover {{
        background: rgba(25,229,255,0.035);
        border: none;
    }}
    QWidget#Tile[selected="true"] {{
        background: rgba(25,229,255,0.075);
        border: none;
    }}
    QLabel#TileIcon {{
        font-size: 16px;
        color: rgba(231,233,241,0.88);
        min-width: 24px;
    }}
    QLabel#TileTitle {{
        font-size: 15px;
        font-weight: 900;
        color: {core.TEXT};
    }}
    QLabel#TileSub {{
        color: rgba(231,233,241,0.72);
        font-size: 12px;
        line-height: 1.2;
    }}
    QLabel#TileBadge {{
        padding: 4px 10px;
        border-radius: 999px;
        background: rgba(255,255,255,0.04);
        border: 1px solid rgba(255,255,255,0.08);
        color: {core.MUTED};
        font-weight: 900;
        font-size: 11px;
    }}

    /* ===== Presentation launcher tiles ===== */
    QLabel#NeonNumber {{
        color: rgba(25,229,255,0.95);
        letter-spacing: 1.0px;
    }}
    QLabel#DeckTitle {{
        font-size: 13px;
        font-weight: 900;
        color: rgba(231,233,241,0.95);
        letter-spacing: 0.2px;
    }}
    QLabel#DeckKind {{
        font-size: 11px;
        font-weight: 900;
        color: rgba(154,163,178,0.95);
        letter-spacing: 0.5px;
    }}

    /* ===== Deck icon buttons (numbered launchers) ===== */
    QPushButton#DeckIcon {{
        background: rgba(255,255,255,0.018);
        border: 1px solid rgba(255,255,255,0.06);
        border-radius: 22px;
        padding: 0px;
        color: rgba(231,233,241,0.94);
        font-weight: 900;
        letter-spacing: 0.8px;
    }}
    QPushButton#DeckIcon:hover {{
        background: rgba(255,255,255,0.028);
        border: 1px solid rgba(25,229,255,0.22);
        color: rgba(25,229,255,0.95);
    }}
    QPushButton#DeckIcon:pressed {{
        background: rgba(25,229,255,0.06);
        border: 1px solid rgba(25,229,255,0.30);
    }}

    /* ===== Navigation (icon-label buttons) ===== */
    QToolButton#NavBtn {{
        background: transparent;
        border: 1px solid transparent;
        border-radius: 12px;
        padding: 10px 12px;
        text-align: left;
        color: {core.MUTED};
        font-weight: 900;
        letter-spacing: 0.2px;
    }}

    QToolButton#NavBtn:hover {{
        background: rgba(255,255,255,0.03);
        border: 1px solid rgba(255,255,255,0.06);
        color: {core.TEXT};
    }}

    QToolButton#NavBtn:checked {{
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
            stop:0 rgba(25,229,255,0.16),
            stop:1 rgba(25,229,255,0.05));
        border: 1px solid rgba(25,229,255,0.28);
        color: {core.TEXT};
    }}

    /* ===== Pills ===== */
    QLabel#Pill {{
        padding: 6px 10px;
        border-radius: 999px;
        background: rgba(255,255,255,0.03);
        border: 1px solid rgba(255,255,255,0.07);
        color: {core.MUTED};
        font-weight: 800;
    }}

    /* ===== Buttons ===== */
    QPushButton {{
        border-radius: 12px;
        padding: 8px 12px;
        font-weight: 800;
    }}

    QPushButton#BtnPrimary {{
        padding: 9px 14px;
        font-weight: 900;
        letter-spacing: 0.25px;
    }}

    QPushButton#BtnGhost {{
        background: rgba(255,255,255,0.03);
        border: 1px solid rgba(255,255,255,0.09);
        color: {core.TEXT};
    }}

    QPushButton#BtnGhost:hover {{
        background: rgba(25,229,255,0.06);
        border: 1px solid rgba(25,229,255,0.18);
    }}

    QPushButton#BtnGhost:pressed {{
        background: rgba(25,229,255,0.10);
        border: 1px solid rgba(25,229,255,0.24);
    }}

    QPushButton#BtnPrimary {{
        background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
            stop:0 {core.ACCENT_SOFT},
            stop:1 {core.ACCENT});
        border: 1px solid rgba(25,229,255,0.40);
        color: {core.ACCENT_DARK};
    }}

    QPushButton#BtnPrimary:hover {{
        background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
            stop:0 rgba(180,248,255,1.0),
            stop:1 rgba(25,229,255,1.0));
        border: 1px solid rgba(25,229,255,0.60);
    }}

    QPushButton:disabled {{
        background: rgba(255,255,255,0.02);
        border: 1px solid rgba(255,255,255,0.05);
        color: rgba(231,233,241,0.35);
    }}

    /* ===== Inputs ===== */
    QLineEdit {{
        background: rgba(255,255,255,0.03);
        border: 1px solid rgba(255,255,255,0.10);
        border-radius: 12px;
        padding: 10px 12px;
        color: {core.TEXT};
        selection-background-color: rgba(25,229,255,0.28);
    }}

    QLineEdit:focus {{
        border: 1px solid rgba(25,229,255,0.55);
        background: rgba(255,255,255,0.04);
    }}

    /* ===== Tabs ===== */
    QTabWidget::pane {{
        border: 1px solid rgba(255,255,255,0.06);
        border-radius: 14px;
        top: -1px;
        background: rgba(255,255,255,0.02);
    }}

    QTabBar::tab {{
        background: rgba(255,255,255,0.02);
        border: 1px solid rgba(255,255,255,0.06);
        border-bottom: none;
        padding: 10px 14px;
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
        margin-right: 6px;
        color: {core.MUTED};
        font-weight: 800;
    }}

    QTabBar::tab:selected {{
        background: rgba(25,229,255,0.06);
        color: {core.TEXT};
        border: 1px solid rgba(25,229,255,0.22);
        border-bottom: none;
    }}

    /* ===== Tables ===== */
    QTableWidget {{
        background: rgba(255,255,255,0.02);
        border: 1px solid rgba(255,255,255,0.06);
        border-radius: 14px;
        gridline-color: rgba(255,255,255,0.06);
        selection-background-color: rgba(25,229,255,0.10);
    }}

    QHeaderView::section {{
        background: rgba(255,255,255,0.02);
        border: none;
        padding: 8px 10px;
        color: {core.MUTED};
        font-weight: 900;
    }}

    /* ===== Scrollbars (hidden — scroll via wheel/trackpad) ===== */
    QScrollBar:vertical {{
        background: transparent;
        width: 0px;
        margin: 0px;
    }}
    QScrollBar::handle:vertical {{
        background: transparent;
        min-height: 0px;
    }}
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
        height: 0px;
    }}
    QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{
        background: transparent;
    }}
    QScrollBar:horizontal {{
        background: transparent;
        height: 0px;
        margin: 0px;
    }}
    QScrollBar::handle:horizontal {{
        background: transparent;
        min-width: 0px;
    }}
    """

    app.setStyleSheet(qss)
