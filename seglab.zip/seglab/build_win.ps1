# build_win.ps1 (run in PowerShell)
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

cd $PSScriptRoot

if (Test-Path ".venv_build") { Remove-Item -Recurse -Force ".venv_build" }
python -m venv .venv_build
$py = ".\.venv_build\Scripts\python.exe"

& $py -m pip install -U pip
& $py -m pip install PySide6 numpy nibabel pyinstaller requests packaging certifi pillow
& $py -m pip uninstall -y PyQt5 PyQt6

if (!(Test-Path ".\resources\icon.ico") -and (Test-Path ".\resources\icon.png")) {
  & $py -c "from PIL import Image; img=Image.open(r'resources\icon.png').convert('RGBA'); img.save(r'resources\icon.ico', sizes=[(16,16),(32,32),(48,48),(64,64),(128,128),(256,256)]); print('Wrote resources/icon.ico')"
}

$iconArgs = @()
if (Test-Path ".\resources\icon.ico") { $iconArgs = @("--icon", ".\resources\icon.ico") }

Remove-Item -Recurse -Force build, dist -ErrorAction SilentlyContinue
Remove-Item -Force *.spec -ErrorAction SilentlyContinue

& $py -m PyInstaller --noconfirm --clean --windowed `
  --name "SegLab" `
  --exclude-module PyQt5 --exclude-module PyQt6 `
  --add-data "resources;resources" `
  @iconArgs `
  startt_trainer.py

Compress-Archive -Path ".\dist\SegLab\*" -DestinationPath ".\dist\SegLab_windows_x64.zip" -Force
Write-Host "Built: dist\SegLab\SegLab.exe"
Write-Host "Zip:   dist\SegLab_windows_x64.zip"
