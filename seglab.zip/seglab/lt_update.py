from __future__ import annotations

import json
import os
import platform
import subprocess
import sys
import tempfile
import urllib.error
import urllib.request
import ssl
import certifi
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional, Tuple

from packaging.version import Version, InvalidVersion

import lt_core as core

ProgressCB = Callable[[int, int], None]  # (downloaded_bytes, total_bytes)


@dataclass
class UpdateInfo:
    version: str
    notes: str
    download_url: str
    asset_name: str
    sha256: str = ""
    size_bytes: int = 0


def _platform_key() -> str:
    sysname = platform.system().lower()
    if "darwin" in sysname or "mac" in sysname:
        return "mac"
    if "windows" in sysname:
        return "win"
    return "mac"



def _ssl_context():
    # Use certifi CA bundle to avoid conda/mac certificate issues
    try:
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def fetch_latest(url: str) -> dict:
    ctx = ssl.create_default_context(cafile=certifi.where())
    with urllib.request.urlopen(url, timeout=10, context=ctx) as r:
        raw = r.read().decode("utf-8")
    d = json.loads(raw)
    if not isinstance(d, dict):
        raise ValueError("latest.json is not a JSON object")
    return d



def check_for_update(feed_url: str, current_version: str) -> Optional[UpdateInfo]:
    """
    Return UpdateInfo if an update is available, else None.

    Supports the repo schema:
      { latest_version, notes?, mac:{download_url, asset_name,...}, win:{...} }
    """
    d = fetch_latest(feed_url)

    latest = str(d.get("latest_version", "") or "").strip()
    if not latest:
        raise RuntimeError("latest.json missing latest_version")

    plat = _platform_key()
    block = d.get(plat)
    if not isinstance(block, dict):
        raise RuntimeError(f"latest.json missing platform block '{plat}'. Present keys: {list(d.keys())}")

    dl = str(block.get("download_url", "") or "").strip()
    asset = str(block.get("asset_name", "") or "").strip() or "update.zip"
    sha256 = str(block.get("sha256", "") or "").strip()
    size_bytes = int(block.get("size_bytes") or 0)

    if not dl:
        raise RuntimeError(f"latest.json missing download_url for platform '{plat}'")

    # Semver-aware compare; fallback to string inequality.
    try:
        if Version(latest) <= Version(str(current_version).strip()):
            return None
    except InvalidVersion:
        if latest == str(current_version).strip():
            return None

    notes = str(d.get("notes", "") or "").strip() or "(no release notes)"
    return UpdateInfo(version=latest, notes=notes, download_url=dl, asset_name=asset, sha256=sha256, size_bytes=size_bytes)


def __sha256(p: Path) -> str:
    import hashlib
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def download_update_with_progress(info: UpdateInfo, cb: Optional[ProgressCB] = None) -> Path:
    """Download update zip with progress callback."""
    core.ensure_dirs()
    dest = core.UPDATES_DIR / info.asset_name

    try:
        req = urllib.request.Request(info.download_url, headers={"User-Agent": "SegLab-Updater"})
        with urllib.request.urlopen(req, timeout=180) as r:
            total = int(r.headers.get("Content-Length") or 0)
            done = 0
            CHUNK = 1024 * 256
            dest.parent.mkdir(parents=True, exist_ok=True)
            with dest.open("wb") as f:
                while True:
                    b = r.read(CHUNK)
                    if not b:
                        break
                    f.write(b)
                    done += len(b)
                    if cb:
                        cb(done, total)
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"HTTP {e.code} while downloading: {info.download_url}") from e
    except Exception as e:
        raise RuntimeError(f"Download failed: {info.download_url} ({e})") from e

    if info.sha256:
        got = __sha256(dest)
        if got.lower() != info.sha256.lower():
            try:
                dest.unlink(missing_ok=True)  # type: ignore[arg-type]
            except Exception:
                pass
            raise RuntimeError("SHA256 mismatch: downloaded ZIP does not match latest.json")

    return dest


def _is_frozen() -> bool:
    if bool(getattr(sys, "frozen", False)) or hasattr(sys, "_MEIPASS"):
        return True
    exe = str(getattr(sys, "executable", ""))
    return ".app/Contents/MacOS" in exe or exe.lower().endswith(".exe")


def apply_update_zip(staged_zip: Path) -> Tuple[bool, str]:
    """Apply update by spawning an OS-native helper (cmd/bash).

    In a frozen PyInstaller app, sys.executable points to the app binary
    (SegLab.exe / SegLab.app/.../SegLab), not a Python interpreter.
    Running a .py helper via sys.executable therefore fails (app quits, nothing happens).
    This implementation writes a tiny OS-native helper that:
      1) waits for the current process to exit
      2) unzips the update
      3) replaces the installed app folder/bundle
      4) relaunches SegLab
    """
    try:
        plat = _platform_key()

        if plat == "win":
            import tempfile, os
            app_dir = Path(sys.executable).resolve().parent          # ...\dist\SegLab
            exe_path = Path(sys.executable).resolve()               # ...\dist\SegLab\SegLab.exe

            helper = Path(tempfile.gettempdir()) / f"seglab_apply_{os.getpid()}.cmd"
            helper.write_text(rf"""@echo off
setlocal enabledelayedexpansion
set "ZIP={staged_zip}"
set "APPDIR={app_dir}"
set "EXE={exe_path}"
set "PID={os.getpid()}"

:wait
tasklist /FI "PID eq %PID%" | find "%PID%" >nul
if %errorlevel%==0 (
  timeout /t 1 /nobreak >nul
  goto wait
)

set "TMP=%TEMP%\seglab_update_%PID%"
if exist "%TMP%" rmdir /s /q "%TMP%"
mkdir "%TMP%"

powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ZIP%' '%TMP%'" || exit /b 2

set "NEWROOT=%TMP%"
for /d %%D in ("%TMP%\*") do (
  if /i "%%~nxD"=="SegLab" set "NEWROOT=%%D"
)

set "BACKUP=%APPDIR%.bak.%RANDOM%"
if exist "%APPDIR%" move "%APPDIR%" "%BACKUP%" >nul

mkdir "%APPDIR%" >nul 2>&1
xcopy /E /I /Y "%NEWROOT%\*" "%APPDIR%\" >nul

start "" "%EXE%"

rmdir /s /q "%TMP%" >nul 2>&1
rmdir /s /q "%BACKUP%" >nul 2>&1
del "%~f0" >nul 2>&1
exit /b 0
""", encoding="utf-8")

            subprocess.Popen(["cmd.exe", "/c", str(helper)], creationflags=0x08000000)  # DETACHED_PROCESS
            return True, "OK"

        # macOS (and default)
        import tempfile, os
        app_path = Path(sys.executable).resolve().parents[2]  # .../SegLab.app
        helper = Path(tempfile.gettempdir()) / f"seglab_apply_{os.getpid()}.sh"
        helper.write_text(f"""#!/bin/bash
set -e
ZIP=\"{staged_zip}\"
APP=\"{app_path}\"
PID=\"{os.getpid()}\"

TMP=\"$(mktemp -d)\"
/usr/bin/ditto -x -k \"$ZIP\" \"$TMP\"
NEWAPP=\"$(find \"$TMP\" -maxdepth 4 -name '*.app' -print -quit)\"
if [ -z \"$NEWAPP\" ]; then
  echo \"No .app found in zip\"
  exit 2
fi

while kill -0 \"$PID\" 2>/dev/null; do
  sleep 0.2
done

BACKUP=\"${APP}.bak.$(date +%s)\"
if [ -e \"$APP\" ]; then
  mv \"$APP\" \"$BACKUP\" || rm -rf \"$APP\"
fi

/usr/bin/ditto \"$NEWAPP\" \"$APP\"
xattr -dr com.apple.quarantine \"$APP\" 2>/dev/null || true
open \"$APP\" || true

rm -rf \"$TMP\"
rm -rf \"$BACKUP\" 2>/dev/null || true
rm -f \"$0\" 2>/dev/null || true
""", encoding="utf-8")
        helper.chmod(0o755)
        subprocess.Popen(["/bin/bash", str(helper)])
        return True, "OK"

    except Exception as e:
        return False, str(e)

def _apply_macos_frozen(staged_zip: Path) -> Tuple[bool, str]:
    app_bin = Path(sys.executable).resolve()
    # Find enclosing .app
    p = app_bin
    app_path = None
    while p != p.parent:
        if p.suffix == ".app":
            app_path = p
            break
        p = p.parent
    if app_path is None:
        return False, f"Could not locate .app bundle from {sys.executable}"

    pid = os.getpid()
    helper = Path(tempfile.gettempdir()) / f"seglab_apply_update_{pid}.sh"
    helper.write_text(f"""#!/bin/bash
set -e
ZIP="{staged_zip}"
APP="{app_path}"
PID="{pid}"

TMP="$(mktemp -d)"
/usr/bin/ditto -x -k "$ZIP" "$TMP"

NEWAPP="$(find "$TMP" -maxdepth 4 -name '*.app' -print -quit)"
if [ -z "$NEWAPP" ]; then
  echo "No .app found in zip"
  exit 2
fi

while kill -0 "$PID" 2>/dev/null; do
  sleep 0.2
done

BACKUP="${{APP}}.bak.$(date +%s)"
if [ -e "$APP" ]; then
  mv "$APP" "$BACKUP" || rm -rf "$APP"
fi

/usr/bin/ditto "$NEWAPP" "$APP"
xattr -dr com.apple.quarantine "$APP" 2>/dev/null || true

open "$APP" || true

rm -rf "$TMP"
rm -rf "$BACKUP" 2>/dev/null || true
exit 0
""", encoding="utf-8")
    helper.chmod(0o755)
    subprocess.Popen(["/bin/bash", str(helper)])
    return True, "OK"


def _apply_win_frozen(staged_zip: Path) -> Tuple[bool, str]:
    pid = os.getpid()
    app_dir = Path(sys.executable).resolve().parent
    helper = Path(tempfile.gettempdir()) / f"seglab_apply_update_{pid}.cmd"
    helper.write_text(rf"""@echo off
setlocal enabledelayedexpansion
set "ZIP={staged_zip}"
set "APPDIR={app_dir}"
set "PID={pid}"

:wait
tasklist /FI "PID eq %PID%" | find "%PID%" >nul
if %errorlevel%==0 (
  timeout /t 1 /nobreak >nul
  goto wait
)

set "TMP=%TEMP%\seglab_update_%PID%"
if exist "%TMP%" rmdir /s /q "%TMP%"
mkdir "%TMP%"

powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ZIP%' '%TMP%'" || exit /b 2

set "NEWROOT=%TMP%"
for /d %%D in ("%TMP%\*") do (
  if /i "%%~nxD"=="SegLab" set "NEWROOT=%%D"
)

set "BACKUP=%APPDIR%.bak.%RANDOM%"
if exist "%APPDIR%" move "%APPDIR%" "%BACKUP%" >nul

mkdir "%APPDIR%" >nul 2>&1
xcopy /E /I /Y "%NEWROOT%\*" "%APPDIR%" >nul

for %%F in ("%APPDIR%\*.exe") do (
  start "" "%%F"
  goto done
)

:done
rmdir /s /q "%TMP%"
rmdir /s /q "%BACKUP%" >nul 2>&1
exit /b 0
""", encoding="utf-8")
    subprocess.Popen(["cmd.exe", "/c", str(helper)])
    return True, "OK"


def install_update_with_progress(parent, on_quit) -> None:
    """
    Updates UX:
    - Shows Current + Latest
    - If update available: user must click "Update now"
    - Shows % progress during download
    - Applies update (self-replace) and relaunches (frozen app)
    """
    from PySide6.QtWidgets import QProgressDialog, QMessageBox

    try:
        latest = "?"
        try:
            d = fetch_latest(core.UPDATE_FEED_URL)
            latest = str(d.get("latest_version", "") or "").strip() or "?"
        except Exception:
            pass

        info = check_for_update(core.UPDATE_FEED_URL, core.APP_VERSION)
        if info is None:
            QMessageBox.information(
                parent,
                core.APP_NAME,
                f"Up to date.\n\nCurrent: {core.APP_VERSION}\nLatest: {latest}",
            )
            return

        mb = QMessageBox(parent)
        mb.setWindowTitle(core.APP_NAME)
        mb.setIcon(QMessageBox.Information)
        mb.setText(f"Update available.\n\nCurrent: {core.APP_VERSION}\nNew: {info.version}")
        if (info.notes or "").strip():
            mb.setInformativeText(info.notes.strip())
        btn_now = mb.addButton("Update now", QMessageBox.AcceptRole)
        mb.addButton("Later", QMessageBox.RejectRole)
        mb.exec()
        if mb.clickedButton() is not btn_now:
            return

        dlg = QProgressDialog(
            f"Downloading update…\n\nCurrent: {core.APP_VERSION}  →  New: {info.version}",
            "Cancel",
            0,
            100,
            parent,
        )
        dlg.setWindowTitle(core.APP_NAME)
        dlg.setMinimumDuration(0)
        dlg.setValue(0)
        dlg.setAutoClose(True)
        dlg.setAutoReset(True)

        cancelled = {"v": False}

        def cb(done: int, total: int):
            if dlg.wasCanceled():
                cancelled["v"] = True
                return
            if total > 0:
                pct = int((done / total) * 100)
                dlg.setValue(max(0, min(100, pct)))
                dlg.setLabelText(f"Downloading update… {pct}%")
            else:
                dlg.setLabelText(f"Downloading update… {done // (1024*1024)} MB")
            parent.repaint()

        staged = download_update_with_progress(info, cb)
        if cancelled["v"]:
            try:
                staged.unlink(missing_ok=True)  # type: ignore[arg-type]
            except Exception:
                pass
            return

        ok, msg = apply_update_zip(staged)
        if not ok:
            QMessageBox.critical(parent, core.APP_NAME, f"Could not start updater helper:\n{msg}")
            return

        QMessageBox.information(
            parent,
            core.APP_NAME,
            f"Update ready.\n\nCurrent: {core.APP_VERSION}\nNew: {info.version}\n\nThe app will restart now.",
        )
        on_quit()

    except Exception as e:
        QMessageBox.critical(parent, core.APP_NAME, f"Update failed:\n{e}\n\nFEED: {core.UPDATE_FEED_URL}")
